# @0xbow/anon-rpc-rs-browser-harness

A browser harness for [anon-rpc](https://github.com/ethereum/anon-rpc),
a standard that lets a wallet or application make **anonymized RPC requests**
by running hash-pinned anon-client code inside a sandboxed worker.

Implements the [anon-rpc specification](../../SPEC.md)
version **0.3.5**. (The package version is kept `>=` the implemented spec
version; a package release without a spec change bumps past it.)

The harness:

- resolves the anon-client bundle from an onchain specifier contract, over
  `https:` or over KPS itself through `kps:` resolver entries (SPEC §4.1–4.2),
  and verifies `keccak256(bytes) == workerHash()` before executing a single
  byte (trust the hash, not the URL);
- runs it in a **Web Worker inside a null-origin sandboxed iframe**, with no
  ambient access to your DOM, storage, cookies, or keys;
- grants it a small, explicit capability API: inbound fetch calls, a
  [KPS](https://ethereum.github.io/kps/) key-pinned transport
  (bridged so the worker never touches WebRTC), persistent storage
  (IndexedDB on the host origin, namespaced per specifier), and logging;
- hands you back one thing: an anonymized `fetch`.

## Install

The package is an asset of this repository's GitHub releases. The repository is private, so downloading it with [`gh`](https://cli.github.com/) needs an account with read access to it. Download it into `vendor/`:

```sh
gh release download v0.4.0-alpha.6 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.6.tgz'
```

Then depend on the tarball. npm, pnpm, Yarn 4 (with `nodeLinker: node-modules` in `.yarnrc.yml`) and Bun all read the same entry:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.6.tgz"
  }
}
```

## Use

```ts
import { AnonRpcWorker } from "@0xbow/anon-rpc-rs-browser-harness";

const worker = new AnonRpcWorker({
  // The IWorkerSpecifier contract identifying the anon-client by hash.
  address: "0x…",
  // Optional: structured-cloneable value delivered to the worker as
  // `anonRpcWorker.config`. Opaque to the harness; schema is the worker's.
  config: { network: "mainnet" },
  // Bootstrap provider used only to read the specifier (breaks the circular
  // "need the chain to reach the chain" dependency).
  preExisting: { rpcProvider },
});

// Optional: wait for the worker to report that it is ready. Fetch calls
// made before then are buffered.
// await worker.ready;

// A standard fetch, routed through the sandboxed anon-client.
// It is this-bound, so passing it around as a free function is fine.
const res = await worker.fetch("https://rpc.example/", {
  method: "POST",
  body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_blockNumber" }),
});

worker.close(); // tears down the iframe and worker
```

### Tor

`AnonRpcWorker.tor` starts the tor-js worker, a Tor client compiled to
WebAssembly, from its specifier on mainnet:

```ts
const worker = AnonRpcWorker.tor({
  // Required: the KPS gateways that relay Tor traffic, as
  // "<ip>:<port>:<certhash>". There is no default gateway.
  gateways: ["152.236.3.22:12298:uEiCH0VdbhryzJcMtCfB0vLA4sOvHdQ4hq5w7CopcwU59bQ"],
  rpcProvider,
  // iframeUrl: optional, as for the constructor.
});
```

`AnonRpcWorker.tor()` is shorthand for
`new AnonRpcWorker(knownWorkerInit("tor-js", { rpcProvider, config: { gateways }, iframeUrl }))`,
so it also checks that `rpcProvider` is on mainnet (see below). The gateway above is a
demonstration relay of limited capacity; run your own for anything real.
Native platforms run no WebAssembly, so their packages construct Tor
differently: the Rust crate and the Swift, Kotlin, React Native (on iOS and
Android), Flutter, and Node packages use a native Tor client through their own `tor` constructor.

### Nym, Nox, and the other published workers

`KNOWN_WORKERS` lists the workers in
[`adopters.json5`](../../adopters.json5) (passthrough, tor-js, Nym, and Nox)
with each one's specifier and the chain it is published on. `knownWorkerInit`
turns a name into a `WorkerInit`:

```ts
import { AnonRpcWorker, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

// Nym is published on mainnet, Nox on Sepolia. Neither requires config.
const nym = new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider }));
const nox = new AnonRpcWorker(knownWorkerInit("nox", { rpcProvider: sepoliaProvider }));

// Either one carries calls to any chain: the specifier's chain is only where
// the bundle's identity is read.
await nox.fetch("https://ethereum-rpc.publicnode.com", { method: "POST", body });
```

The list is data, not behavior: the harness boots every worker the same way.
`kind` is `"reference"` for passthrough, which does not anonymize. A required
config key has no default (tor-js needs `gateways`), and `knownWorkerInit`
throws a `TypeError` without it. Nym's bundle is about 18 MB and its mixnet
takes several seconds to join; Nox's is about 2 MB. Nym's first call to each
host can take half a minute; see
[Networks and runtimes](../../docs/integrate-wallet.md#networks-and-runtimes)
in the integration guide. A Nym worker can also boot onto a route that carries
nothing (see [Replace a worker whose route fails](#replace-a-worker-whose-route-fails)).

#### The specifier's chain

`WorkerInit.specifierChainId` names the chain the specifier contract is
published on, which is the chain `rpcProvider` must answer for.
`knownWorkerInit` sets it. With it set, the harness asks `rpcProvider` for
`eth_chainId` before the §4 reads and fails `ready` with a
`SpecifierChainError` (`expectedChainId`, `actualChainId`) on any other answer,
without reading the specifier. On another chain the same address may hold no
contract, or one pinning different code. It does not limit the chains the
worker's fetches reach. It is an extension of this harness; SPEC.md §5 does
not define it, and without it the harness asks for no chain id.

Workers of one specifier in one page share this boot work: the chain check
and the specifier reads are made once per `rpcProvider` object, and the
verified bundle is kept by its hash, for the life of the page. A failed read
or download is not kept, and work in flight is stopped only when every worker
waiting on it has closed. A worker started later sees a changed specifier only
through a new provider object or after a reload.

#### The expected bundle hash

`WorkerInit.expectedWorkerHash` (§5) is the bundle hash the host requires, as
`0x` and 64 hex digits in either case. With it set, the harness compares it
with the specifier's `workerHash()` before fetching any bundle and fails
`ready` with a `WorkerHashMismatchError` (`expectedWorkerHash`,
`actualWorkerHash`, code `protocol-error`) when they differ; a malformed value
fails `ready` with a `TypeError` (code `unsupported`) before anything is read.
A specifier owner can change the code it pins at any time; this keeps a change
from reaching a host that has not reviewed it.

### Replace a worker whose route fails

A worker keeps the route it picks when it starts, and it can start on one that
carries nothing: in 79 fresh Nym boots on desktop Chromium and Android Chrome,
7 drew an exit that accepted connections and then failed every call, and the
worker never reported itself failed. `ReplacingWorker` is a `fetch` that starts
a worker on first use and starts a new one when the one in use stops
answering:

```ts
import { AnonRpcWorker, ReplacingWorker, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

const nym = new ReplacingWorker({
  start: () =>
    new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider })),
  // A cold route took up to 35 s; a call still waiting at 90 s counts as failed.
  callTimeoutMs: 90_000,
  readyTimeoutMs: 180_000,
});
const response = await nym.fetch("https://ethereum-rpc.publicnode.com", { method: "POST", body });
```

A worker is replaced when a call has failed with none answering since (the
second such failure, for a worker that has answered before) and no call to
another host is still waiting, since one failing endpoint says nothing about
the route while another may still answer. If that failure is a call that
outlasted its deadline while no call to any host answered, the worker is
replaced even while calls to other hosts wait: the route has carried nothing
for a whole `callTimeoutMs`, and waiting on calls to hosts first tried
meanwhile would put the replacement off by a deadline per new host. A call
that answers with any status shows the route works. One that outlasts
`callTimeoutMs` after the worker is ready fails with code `timeout` and counts
as failed; one its caller aborts counts for nothing. Replacing closes the old
worker, which ends the calls still on it. A worker that fails to start, or is
not ready within `readyTimeoutMs`, is closed, and the next call starts
another. `close()` closes the worker in use, and later calls fail with code
`closed`.

`start` receives a signal that aborts when that worker is closed, for
anything it reads before constructing one. `ready()` starts a worker without a
call and settles when it is ready. `ReplacingWorker` uses only a worker's
`ready`, `fetch`, and `close`, so it takes the React Native and Node packages'
workers too. SPEC §5.1 defines its behaviour.

### Run isolation groups under a worker budget

Traffic that must not be linked goes over separate workers, and each worker
costs memory, CPU, and its own route: on an Android Chrome emulator each added
120 to 250 MB, and tor-js workers slowed past four.
`WorkerPool` runs one `ReplacingWorker` per isolation group and counts every
worker alive against one budget:

```ts
import { AnonRpcWorker, WorkerPool, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

const pool = new WorkerPool({
  start: () => new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider })),
  maxWorkers: 2, // every worker alive, spares included
  spare: 1, // started ahead for the next group that needs a worker
  idleCloseMs: 120_000, // close a group's worker unused this long
  callTimeoutMs: 90_000,
  readyTimeoutMs: 180_000,
});

await pool.group("reads").ready(); // start a long-lived group now
const operation = pool.group(`withdrawal:${id}`); // takes the spare
await operation.fetch(relayerUrl, { method: "POST", body });
operation.close(); // frees its place; the pool starts a new spare
```

Calls in two groups never share a worker. A group that needs a worker when
the budget is spent waits, first come first served, until a group closes, an
idle worker closes, or a worker is retired; the wait counts towards
`readyTimeoutMs`, and a caller's signal ends it for that call. While a group
waits, the least recently used group gives up its worker: its later calls
wait for a place in turn, and its worker closes once the calls already on it
and their response bodies are done, or `callTimeoutMs` after it gave up its
place. With `callTimeoutMs` set, a busy group cannot starve another. Which traffic
shares a group is yours to decide: put fewer groups to the pool when the
budget is tight. A group's `idleCloseMs` can differ from the pool's
(`pool.group(key, { idleCloseMs })`), and a response body still being read
does not keep a group busy. A spare that fails to start frees its place
without starting another until a group needs one. `pool.close()` closes every
group and spare, and later calls fail with code `closed`. SPEC §5.2 defines
its behaviour.

Size a Nym pool by CPU. Each Nym worker runs a full mixnet client whose cover
traffic never stops, so it costs about a quarter of a 4-core Android device
whether or not it carries a call. Four of them held a 4-vCPU emulator at 72 to
96% before the first call, and first calls failed once other load took the
rest. On phones, start from `maxWorkers: Math.max(1,
Math.floor(navigator.hardwareConcurrency / 2))`, and give Nym groups an
`idleCloseMs` of 60 to 120 s, since an idle Nym worker costs as much CPU as a
busy one.

### Pass options a worker defines

A worker can define options of its own for each call. Pass them as further
members of `fetch`'s `init`, and the worker receives them as members of its
`requestInit` (SPEC §9.3):

```ts
await worker.fetch(rpcUrl, { method: "POST", body, isolationKey: account } as RequestInit);
```

Every member that is not a Fetch standard `RequestInit` member crosses when
its value is `null`, a boolean, a finite number, a string, a `Uint8Array`, or
an array or plain object of these; it is copied when `fetch` is called and
never logged. Other values (functions, class instances, `undefined`) stay
behind, and the call is still sent. A `Request` passed as the input carries
none; only `init` does. `ReplacingWorker` and every `WorkerPool` group pass
them on. A worker that does not define a member ignores it, so pass one only
to a worker whose bundle hash you require (`expectedWorkerHash`) and whose
meaning for it you know. The tor-js bundle its specifier pins today (tor-js
0.4.3) defines none, so its calls share circuits whatever `init` holds.

### Collect the worker's logs

A worker's §13 `log` calls go to the console unless you collect them. Pull them
with `acceptLog()` (SPEC §5, §13.1) and they stop being echoed there:

```ts
for (;;) {
  // Resolves with the next entry; waits when there is none. Rejects once the
  // worker has failed or closed AND its retained entries are drained, so the
  // lines explaining a failure arrive before the rejection does.
  const { level, args } = await worker.acceptLog();
  render(level, args);
}
```

Entries are retained from the moment the worker starts, so a line logged
during boot is still there when you first ask. The buffer is bounded (1000
entries) and drops the oldest beyond that; §13.1 makes this the one place a
harness may lose a log call it has already accepted.

### Strict Content Security Policies

By default the harness builds its null-origin iframe with `srcdoc` and an inline
bootstrap script, which needs nothing from you. If your page's CSP omits
`'unsafe-inline'` for `script-src`, that bootstrap will not run: a `srcdoc`
document inherits the embedder's policy, and a policy can only be tightened
from within a document, never relaxed. The symptom is a `ready` that never
settles, plus a CSP violation in the console.

Serve the harness's bootstrap page yourself and point `iframeUrl` (SPEC §5) at
it:

```ts
new AnonRpcWorker({ address, preExisting, iframeUrl: "/anon-rpc-iframe.html" });
```

The page needs only the harness's own bootstrap script, which the package
exports as `@0xbow/anon-rpc-rs-browser-harness/iframe-boot.js`
(`dist/iframe-boot.js`). Serve it from your own origin, here as
`/anon-rpc-iframe.js`:

```html
<!doctype html><meta charset="utf-8"><script src="/anon-rpc-iframe.js"></script>
```

The harness still applies `sandbox="allow-scripts"` itself, so the document is
placed at an opaque origin whichever route it came from, and §6 requires the URL
to be same-origin with your page. A cross-origin bootstrap would hand the
isolation boundary to a third party, so the harness rejects one.

On Firefox, allow `data:` in the bootstrap page's `script-src` wherever a policy
applies there: Firefox refuses `importScripts(blob:)` in an opaque-origin
worker, so the harness loads the verified bundle from a `data:` URL instead (it
detects this; other browsers keep using `blob:`).

For MV3 browser extensions this is not optional and the page must additionally
be declared in the manifest's `sandbox.pages`;
[`@0xbow/anon-rpc-rs-browser-extension-harness`](../browser-extension-harness) packages
all of that.

## Browser support

The harness needs Chrome 100, Firefox 100, or Safari 15.4 (iOS 15.4) or later:
those versions add `AbortSignal.throwIfAborted`, `WritableStream` and
`Object.hasOwn`, the newest platform features it uses. Stream bytes, for KPS
streams and for streamed request and response bodies, cross the sandbox
boundary as messages rather than as transferred streams, so browsers that
cannot transfer a stream (Safari before 27) run every worker.

Tested with Chromium 153, Firefox 155 and WebKit 26.6 (Playwright), Safari
27.0.1 on macOS, and Safari on iOS 26.4 and 26.5 (Simulator): Nym, Nox and
tor-js boot and carry calls in each. Older versions down to the floor are not
tested.

## Notes

- Browser-only: the isolation model is a null-origin iframe and the KPS
  transport runs over WebRTC. Node applications use
  [`@0xbow/anon-rpc-rs-node`](../../packages/node/) instead.
- The worker-facing capability API (`anonRpcWorker`) and all conformance
  requirements are defined in the
  [specification](../../SPEC.md).
  A template anon-client to copy lives in
  [`impl/passthrough-worker`](../passthrough-worker/).
- Status: prototype-grade reference implementation of a draft spec; interfaces
  track the spec and may change.

## License

MIT © Ethereum Foundation
