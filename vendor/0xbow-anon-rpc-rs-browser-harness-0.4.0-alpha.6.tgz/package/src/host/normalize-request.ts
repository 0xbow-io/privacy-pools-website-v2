// Normalizes the host's `fetch(input, init)` arguments (§5: `fetch: typeof
// fetch`) into the wire shape sent to the worker (§9.1), plus the transfer
// list for its byte buffers and the effective abort signal. A stream body
// stays a stream here; it crosses through the stream relay when the worker
// takes the call.

import type { AnonRequestInit, HeaderList } from "../spec-types.js";
import { workerFields, type WorkerValue } from "./worker-fields.js";

export type WireRequestInit = {
  method?: string;
  headers?: HeaderList;
  body?: Uint8Array | ReadableStream<Uint8Array>;
  redirect?: AnonRequestInit["redirect"];
  // The signal itself cannot cross the port; the worker reconstructs one and
  // the host drives it via "call-abort" events.
  hasSignal?: boolean;
  // Worker-defined fields (§9.3), kept apart from the members above so that
  // none can take a wire member's place; the worker spreads them into its
  // requestInit.
  fields?: Record<string, WorkerValue>;
};

export type NormalizedRequest = {
  url: string;
  requestInit?: WireRequestInit;
  transfer?: Transferable[];
  signal?: AbortSignal;
};

export async function normalizeRequest(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<NormalizedRequest> {
  // Read before anything is awaited, as fetch reads init (§9.3). A Request
  // carries no worker-defined fields; only init does.
  const fields = workerFields(init);
  // A Request input carries method/headers/body/redirect/signal itself;
  // materialize it with any init overrides rather than reading init alone.
  if (input instanceof Request) {
    // As fetch does: a body already read, or a stream someone holds, cannot be
    // sent. Caught here, it fails the call; caught at transfer, it would fail
    // only after the worker took the call, leaving it unanswered.
    if (init?.body == null && (input.bodyUsed || input.body?.locked)) {
      throw new TypeError("the Request's body has already been used");
    }
    const needsDuplex = init?.body instanceof ReadableStream;
    const req = init
      ? new Request(input, { ...(needsDuplex ? { duplex: "half" } : {}), ...init } as RequestInit)
      : input;
    const headers: HeaderList = [];
    req.headers.forEach((v, k) => headers.push([k, v]));
    const requestInit: WireRequestInit = {
      method: req.method,
      headers,
      redirect: req.redirect,
      hasSignal: true, // a Request always has a signal
    };
    if (fields) requestInit.fields = fields;
    const transfer: Transferable[] = [];
    if (req.body) {
      requestInit.body = req.body;
    } else if (req.body === undefined && req.method !== "GET" && req.method !== "HEAD") {
      // An engine without Request body streams (Firefox) has no `body` to
      // transfer, so read the bytes instead; `null` means there are none.
      const bytes = new Uint8Array(await req.arrayBuffer());
      if (bytes.byteLength) {
        requestInit.body = bytes;
        transfer.push(bytes.buffer as ArrayBuffer);
      }
    }
    return { url: req.url, requestInit, transfer, signal: req.signal };
  }

  const url = typeof input === "string" ? input : input.href;
  if (!init) return { url };

  const src = init;
  const transfer: Transferable[] = [];
  let body: WireRequestInit["body"];
  // Content-Type that fetch would derive from the body type (e.g. FormData's
  // multipart boundary) — lost when we buffer to bytes unless carried along.
  let autoContentType: string | undefined;
  if (src.body != null) {
    if (src.body instanceof ReadableStream) {
      if (src.body.locked) throw new TypeError("the body stream is locked");
      body = src.body;
    } else if (typeof src.body === "string") {
      body = new TextEncoder().encode(src.body);
      transfer.push(body.buffer as ArrayBuffer); // freshly allocated: transfer, don't clone
    } else if (src.body instanceof Uint8Array || src.body instanceof ArrayBuffer) {
      // Caller-owned bytes: copy them now, as fetch does, so a later write by
      // the caller cannot change what is sent, and transfer the copy.
      body = new Uint8Array(src.body instanceof ArrayBuffer ? src.body.slice(0) : src.body);
      transfer.push(body.buffer as ArrayBuffer);
    } else {
      // Blob/FormData/URLSearchParams…: buffer via a temp Response, keeping
      // the content type it derives (FormData is unparseable without it).
      const tmp = new Response(src.body as BodyInit);
      body = new Uint8Array(await tmp.arrayBuffer());
      autoContentType = tmp.headers.get("content-type") ?? undefined;
      transfer.push(body.buffer as ArrayBuffer);
    }
  }

  const requestInit: WireRequestInit = {};
  if (src.method) requestInit.method = src.method;
  const headers = headersToList(src.headers) ?? [];
  if (autoContentType && !headers.some(([k]) => k.toLowerCase() === "content-type")) {
    headers.push(["content-type", autoContentType]);
  }
  if (headers.length) requestInit.headers = headers;
  if (body !== undefined) requestInit.body = body;
  if (src.redirect) requestInit.redirect = src.redirect;
  if (src.signal) requestInit.hasSignal = true;
  if (fields) requestInit.fields = fields;

  return { url, requestInit, transfer, signal: src.signal ?? undefined };
}

function headersToList(h: HeadersInit | undefined): HeaderList | undefined {
  if (!h) return undefined;
  const out: HeaderList = [];
  if (h instanceof Headers) h.forEach((v, k) => out.push([k, v]));
  // Converted as Headers converts them: a JavaScript caller's tuples are not
  // checked against the type, and one that cannot become a string fails here,
  // as fetch fails, rather than in the worker.
  else if (Array.isArray(h)) for (const [k, v] of h) out.push([String(k), String(v)]);
  else for (const [k, v] of Object.entries(h)) out.push([k, String(v)]);
  return out;
}
