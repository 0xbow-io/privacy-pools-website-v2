// Host side of the KPS bridge.
//
// The harness runs the REAL kps client (WebRTC) on the host, and exposes it to
// the worker over the capability port. This is the whole point of the `kps`
// capability (§10, draft rationale): worker code never touches WebRTC, so it is
// not locked to web. Connections and streams are referenced by opaque ids, and
// a stream's bytes cross through the stream relay (stream-relay.ts), which
// carries backpressure; lifecycle calls cross as RPC.

import { dial, openStream } from "./kps-client/index.js";
import type { Connection, Stream } from "@kpstreams/core";
import type { KpsReason } from "../spec-types.js";
import type { PortRpc, RpcResult } from "../protocol.js";
import { KPS_DIAL_TIMEOUT_MS } from "./kps-http.js";
import { combineSignals } from "./abort.js";
import { streamRelay } from "../stream-relay.js";

/** The KPS client the bridge exposes; tests substitute their own. */
export type KpsClient = { dial: typeof dial; openStream: typeof openStream };

export function registerKpsBridge(rpc: PortRpc, client: KpsClient = { dial, openStream }): () => void {
  const conns = new Map<number, Connection>();
  const streams = new Map<number, Stream>();
  let nextId = 1;
  // Aborted by dispose(): a dial or stream still being opened then is
  // cancelled, and one that completes anyway is closed rather than registered,
  // so nothing outlives the worker it was opened for.
  const lifetime = new AbortController();
  const relay = streamRelay(rpc);
  const disposed = () => new Error("kps bridge closed: the worker is gone");
  // Runs `op` under the handler's signal and the bridge's lifetime, with an
  // optional deadline, detaching from both once `op` settles.
  const live = async <T>(signal: AbortSignal, op: (signal: AbortSignal) => Promise<T>, timeoutMs?: number) => {
    const combined = combineSignals([signal, lifetime.signal], timeoutMs);
    try {
      return await op(combined.signal);
    } finally {
      combined.release();
    }
  };
  // A dial on the worker's behalf. A caller's signal owns a kps dial's
  // deadline, and the handler's signal always exists, so a worker that set no
  // deadline of its own gets the client's default back here.
  const dialing = <T>(signal: AbortSignal, hasSignal: unknown, op: (signal: AbortSignal) => Promise<T>) =>
    live(signal, op, hasSignal === true ? undefined : KPS_DIAL_TIMEOUT_MS);

  const addStream = (s: Stream): RpcResult => {
    if (lifetime.signal.aborted) {
      void s.close({ code: "closed" }).catch(() => {});
      throw disposed();
    }
    const streamId = nextId++;
    streams.set(streamId, s);
    // Close info is PUSHED to the worker (rather than pulled via an RPC): the
    // settlement is also the registry-prune point, so retired streams — half-
    // closed, reset by the peer, or closed explicitly — never pin map entries.
    void s.closed.then((info) => {
      streams.delete(streamId);
      rpc.emit("stream.closed", { streamId, info });
    });
    // The host keeps the Stream: the worker reads and writes its halves
    // through the relay, and its lifecycle calls act on the data channel.
    return { value: { streamId, readable: relay.sendReadable(s.readable), writable: relay.sendWritable(s.writable) } };
  };

  const conn = (id: number): Connection => {
    const c = conns.get(id);
    if (!c) throw new Error(`unknown connId ${id}`);
    return c;
  };
  // Run `op` on stream `id`. A stream settles, and leaves the registry, once
  // both halves are done, which can happen before a lifecycle call the worker
  // already made arrives (a `close()` after reading to EOF, say). Such a call
  // has nothing left to do, so it succeeds; an id never issued still fails.
  const withStream = async (id: number, op: (s: Stream) => Promise<void>): Promise<RpcResult> => {
    const s = streams.get(id);
    if (s) await op(s);
    else if (!(Number.isInteger(id) && id > 0 && id < nextId)) throw new Error(`unknown streamId ${id}`);
    return { value: undefined };
  };

  rpc.on("kps.dial", async ({ addr, hasSignal }, { signal }) => {
    const c = await dialing(signal, hasSignal, (s) => client.dial(addr, { signal: s }));
    if (lifetime.signal.aborted) {
      void c.close({ code: "closed" });
      throw disposed();
    }
    const connId = nextId++;
    conns.set(connId, c);
    void c.closed.then((info) => {
      conns.delete(connId);
      rpc.emit("conn.closed", { connId, info });
    });
    // remoteAddress crosses once, at establishment — a compliant snapshot
    // (§10.1: it reflects the endpoint observed at establishment; on the dial
    // side, the dialed endpoint).
    return { value: { connId, remoteAddress: c.remoteAddress } };
  });

  rpc.on("kps.openStream", async ({ addr, hasSignal }, { signal }) => {
    return addStream(await dialing(signal, hasSignal, (s) => client.openStream(addr, { signal: s })));
  });

  rpc.on("conn.openStream", async ({ connId }, { signal }) => {
    return addStream(await live(signal, (s) => conn(connId).openStream({ signal: s })));
  });

  rpc.on("conn.acceptStream", async ({ connId }, { signal }) => {
    return addStream(await live(signal, (s) => conn(connId).acceptStream({ signal: s })));
  });

  rpc.on("conn.close", async ({ connId, reason }: { connId: number; reason?: KpsReason }) => {
    await conn(connId).close(reason);
    conns.delete(connId); // the closed handler above also deletes; both are safe
    return { value: undefined };
  });

  rpc.on("conn.sendDatagram", async ({ connId, data }, { signal }) => {
    await conn(connId).sendDatagram(data, { signal });
    return { value: undefined };
  });

  rpc.on("conn.receiveDatagram", async ({ connId }, { signal }) => {
    return { value: await conn(connId).receiveDatagram({ signal }) };
  });

  rpc.on("stream.closeWrite", ({ streamId }) => withStream(streamId, (s) => s.closeWrite()));
  rpc.on("stream.cancelRead", ({ streamId, reason }: { streamId: number; reason?: KpsReason }) =>
    withStream(streamId, (s) => s.cancelRead(reason)),
  );
  rpc.on("stream.resetWrite", ({ streamId, reason }: { streamId: number; reason?: KpsReason }) =>
    withStream(streamId, (s) => s.resetWrite(reason)),
  );
  rpc.on("stream.close", ({ streamId, reason }: { streamId: number; reason?: KpsReason }) =>
    withStream(streamId, async (s) => {
      await s.close(reason);
      streams.delete(streamId); // the closed handler above also deletes; both are safe
    }),
  );

  return () => {
    lifetime.abort(disposed());
    // Streams first: a stream from kps.openStream owns a hidden dedicated
    // connection that is only torn down when the stream itself closes — the
    // conns map never saw it.
    for (const s of streams.values()) void s.close({ code: "closed" }).catch(() => {});
    for (const c of conns.values()) void c.close({ code: "closed" });
    streams.clear();
    conns.clear();
  };
}
