// Boot work shared by the workers of one page.
//
// A host that runs several workers of one specifier (one per isolation group)
// would otherwise repeat the same boot for each: the eth_chainId check and the
// two §4 reads through its bootstrap provider, then the bundle download and
// its keccak256. Those requests leave directly, before any worker exists, so
// a worker started on a user action would make them at that moment. Sharing
// them makes the second worker's boot local work only.
//
// - The verified bundle is kept by workerHash for the life of the page. Any
//   bytes matching the hash are equally acceptable (§4), whoever fetched them.
// - Chain checks and specifier reads are kept per provider object, so a host
//   that hands a worker a different provider gets that provider's answers. A
//   specifier changed onchain takes effect for a new provider object or on the
//   next page load.
//
// A failure is never kept: the next boot tries again. Work in flight belongs
// to every boot waiting on it, and is aborted only once all of them have.

import type { RpcProvider } from "../spec-types.js";

type Entry<T> = { promise: Promise<T>; waiters: number; ac: AbortController; settled: boolean };

const bundles = new Map<string, Entry<Uint8Array>>();
const byProvider = new WeakMap<RpcProvider, Map<string, Entry<unknown>>>();

/** `run`'s result for `key`, started once and shared until it fails. */
function shared<T>(
  entries: Map<string, Entry<T>>,
  key: string,
  run: (signal: AbortSignal) => Promise<T>,
  signal: AbortSignal,
): Promise<T> {
  signal.throwIfAborted();
  let entry = entries.get(key);
  if (!entry) {
    const ac = new AbortController();
    // Async, so a run that throws synchronously still settles the entry.
    const created: Entry<T> = { promise: (async () => run(ac.signal))(), waiters: 0, ac, settled: false };
    created.promise.then(
      () => {
        created.settled = true;
      },
      () => {
        created.settled = true;
        if (entries.get(key) === created) entries.delete(key);
      },
    );
    entries.set(key, created);
    entry = created;
  }
  const held = entry;
  held.waiters++;
  return new Promise<T>((resolve, reject) => {
    const leave = () => {
      signal.removeEventListener("abort", onAbort);
      held.waiters--;
    };
    const onAbort = () => {
      leave();
      if (held.waiters === 0 && !held.settled) {
        if (entries.get(key) === held) entries.delete(key);
        held.ac.abort(signal.reason);
      }
      reject(signal.reason);
    };
    signal.addEventListener("abort", onAbort, { once: true });
    held.promise.then(
      (v) => {
        if (signal.aborted) return;
        leave();
        resolve(v);
      },
      (e) => {
        if (signal.aborted) return;
        leave();
        reject(e);
      },
    );
  });
}

/** The verified bundle for `workerHash`, fetched by `run` at most once at a time. */
export function sharedBundle(
  workerHash: string,
  run: (signal: AbortSignal) => Promise<Uint8Array>,
  signal: AbortSignal,
): Promise<Uint8Array> {
  return shared(bundles, workerHash.toLowerCase(), run, signal);
}

/** A boot read through `provider`, made once per provider and `key`. */
export function sharedRead<T>(
  provider: RpcProvider,
  key: string,
  run: (signal: AbortSignal) => Promise<T>,
  signal: AbortSignal,
): Promise<T> {
  let entries = byProvider.get(provider);
  if (!entries) byProvider.set(provider, (entries = new Map()));
  return shared(entries as Map<string, Entry<T>>, key, run, signal);
}

/** Forget every kept bundle. For tests: a page never needs to. */
export function clearBootCache(): void {
  bundles.clear();
}
