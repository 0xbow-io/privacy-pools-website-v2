// Waiting on work that may not honour cancellation.

/**
 * `p`, or a rejection with `signal`'s reason as soon as it aborts.
 *
 * Whatever `p` does after the abort is ignored. That is the point: a provider
 * call, a fetch, or a dial that ignores its signal and completes late cannot
 * resume a caller that has already been told to stop.
 */
export function untilAborted<T>(p: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return p;
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    if (signal.aborted) {
      // Still observe `p`, so its eventual rejection is never "unhandled".
      p.catch(() => {});
      onAbort();
      return;
    }
    signal.addEventListener("abort", onAbort, { once: true });
    p.then(
      (v) => {
        signal.removeEventListener("abort", onAbort);
        resolve(v);
      },
      (e) => {
        signal.removeEventListener("abort", onAbort);
        reject(e);
      },
    );
  });
}

/**
 * A signal that aborts with the reason of the first of `signals` to abort, or
 * with a TimeoutError after `timeoutMs`.
 *
 * `AbortSignal.any` and `AbortSignal.timeout` would do this, but need Chrome
 * 116, Firefox 124 and Safari 17.4, above the harness's floor of Chrome 100,
 * Firefox 100 and Safari 15.4 (README). `release` detaches the combined
 * signal from its inputs and stops the timer; call it once the work it guards
 * has settled, so a long-lived input (a worker's lifetime) does not collect
 * one listener per call.
 */
export function combineSignals(
  signals: AbortSignal[],
  timeoutMs?: number,
): { signal: AbortSignal; release: () => void } {
  const ac = new AbortController();
  const detach: (() => void)[] = [];
  const release = () => {
    for (const d of detach.splice(0)) d();
  };
  const abort = (reason: unknown) => {
    release();
    ac.abort(reason);
  };
  for (const s of signals) {
    if (s.aborted) {
      abort(s.reason);
      return { signal: ac.signal, release };
    }
    const onAbort = () => abort(s.reason);
    s.addEventListener("abort", onAbort, { once: true });
    detach.push(() => s.removeEventListener("abort", onAbort));
  }
  if (timeoutMs !== undefined) {
    const timer = setTimeout(() => abort(new DOMException("signal timed out", "TimeoutError")), timeoutMs);
    detach.push(() => clearTimeout(timer));
  }
  return { signal: ac.signal, release };
}
