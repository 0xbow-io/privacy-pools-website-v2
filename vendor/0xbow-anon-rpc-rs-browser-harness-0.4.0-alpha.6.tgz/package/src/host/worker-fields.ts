// Worker-defined fields (SPEC §9.3): the members of a host's fetch `init`
// that the specification does not define, delivered to the worker as
// members of its `requestInit`. Every JavaScript host API applies these
// rules; `cargo xtask generate` copies this file into the packages that have
// one, so the rules cannot drift between them.

/** A value a worker-defined field may hold (§9.3's worker values). */
export type WorkerValue =
  | null
  | boolean
  | number
  | string
  | Uint8Array
  | WorkerValue[]
  | { [key: string]: WorkerValue };

/**
 * The Fetch standard's `RequestInit` members, which never cross as fields:
 * they have a meaning in §9.1 or describe the host's own fetch.
 */
const FETCH_MEMBERS: ReadonlySet<string> = new Set([
  "body",
  "cache",
  "credentials",
  "duplex",
  "headers",
  "integrity",
  "keepalive",
  "method",
  "mode",
  "priority",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "window",
]);

/**
 * The worker-defined fields of a host's `init`, as a copy taken now, or
 * `undefined` when it has none. A member whose value is not a worker value
 * is left out; the call is still sent.
 */
export function workerFields(init: unknown): Record<string, WorkerValue> | undefined {
  if (init === null || typeof init !== "object") return undefined;
  const fields: [string, WorkerValue][] = [];
  for (const [name, value] of Object.entries(init)) {
    if (FETCH_MEMBERS.has(name) || value === undefined) continue;
    const copy = workerValue(value, new Set());
    if (copy !== undefined) fields.push([name, copy]);
  }
  // fromEntries defines each member, so a field named `__proto__` stays a
  // member and never becomes the object's prototype.
  return fields.length ? Object.fromEntries(fields) : undefined;
}

/**
 * `init` as it is now, each member read once: its Fetch members as they are,
 * copies of its worker-defined fields, and none of the members that cannot
 * cross. A wrapper that holds a call until its worker is ready keeps this.
 */
export function initNow(init: RequestInit): RequestInit {
  const members: [string, unknown][] = [];
  for (const [name, value] of Object.entries(init)) {
    if (FETCH_MEMBERS.has(name)) members.push([name, value]);
    else if (value !== undefined) {
      const copy = workerValue(value, new Set());
      if (copy !== undefined) members.push([name, copy]);
    }
  }
  return Object.fromEntries(members) as RequestInit;
}

// The name in a typed array's internal slot: unlike Object.prototype.toString,
// a Symbol.toStringTag of the array's own cannot change it, and it holds for
// another realm's arrays.
const typedArrayName = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), Symbol.toStringTag)!
  .get as (this: unknown) => string | undefined;

// A copy of `value` when it is a worker value, else undefined. Each value is
// read once, so a getter cannot show the check one value and the copy
// another. Bytes and plain objects are recognised in a way that holds for
// values from another realm, such as an iframe's. The copy is made by hand:
// React Native has no structuredClone.
function workerValue(value: unknown, path: Set<object>): WorkerValue | undefined {
  switch (typeof value) {
    case "boolean":
    case "string":
      return value;
    case "number":
      return Number.isFinite(value) ? value : undefined;
    case "object":
      break;
    default:
      return undefined;
  }
  if (value === null) return null;
  // A new array, not slice(): a Node Buffer's slice shares its memory.
  if (ArrayBuffer.isView(value)) {
    return typedArrayName.call(value) === "Uint8Array" ? new Uint8Array(value as Uint8Array) : undefined;
  }
  // A value that contains itself has no JSON form.
  if (path.has(value)) return undefined;
  path.add(value);
  try {
    if (Array.isArray(value)) {
      const items: WorkerValue[] = [];
      // By index, so that a hole (an undefined element) fails the value.
      for (let i = 0; i < value.length; i++) {
        const item = workerValue(value[i], path);
        if (item === undefined) return undefined;
        items.push(item);
      }
      return items;
    }
    // A plain object's prototype is null or a realm's Object.prototype, whose
    // own prototype is null; a class instance's chain is longer.
    const proto = Object.getPrototypeOf(value);
    if (proto !== null && Object.getPrototypeOf(proto) !== null) return undefined;
    const entries: [string, WorkerValue][] = [];
    for (const [key, member] of Object.entries(value)) {
      const item = workerValue(member, path);
      if (item === undefined) return undefined;
      entries.push([key, item]);
    }
    return Object.fromEntries(entries);
  } finally {
    path.delete(value);
  }
}
