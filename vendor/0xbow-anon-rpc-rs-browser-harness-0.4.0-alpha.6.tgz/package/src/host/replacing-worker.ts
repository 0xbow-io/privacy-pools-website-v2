// A fetch that keeps a worker whose route still carries calls, starting a new
// worker when the one in use stops answering.
//
// A worker keeps the route it picks when it starts. A Nym worker keeps its
// gateway and exit for its whole life, and 7 of 79 fresh boots on desktop
// Chromium and Android Chrome drew an exit that accepted the connection and
// then carried nothing; the worker never reported itself failed, so every
// call on it failed or timed out. A worker that has failed stays failed too
// (§5, §7). Either way the only recovery is a new worker, which picks its
// route again.
//
// SPEC.md §5.1 and §5.2 define ReplacingWorker and WorkerPool, which the
// anon-rpc crate implements for the native lanes. They use nothing but a
// worker's `ready`, `fetch`, and `close`, and avoid AbortSignal.any,
// AbortSignal.timeout, and URL, which React Native lacks or only partly
// implements.

import { RpcError } from "../protocol-wire.js";
import { initNow } from "./worker-fields.js";

/** The class of this module's own `timeout` and `closed` failures. */
export { RpcError };

/** What ReplacingWorker uses of a worker. */
export type ReplaceableWorker = {
  ready: Promise<void>;
  fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
  close(): void;
};

export type ReplacingWorkerOptions<W extends ReplaceableWorker> = {
  /**
   * Starts a worker: at the first call, and at the first call after the
   * worker in use was replaced or failed to start. `signal` aborts when that
   * worker is closed, for anything the start itself reads.
   */
  start: (signal: AbortSignal) => W | Promise<W>;
  /**
   * How long a call may wait for its response once the worker is ready. A
   * call still waiting then fails with code `timeout` and counts against the
   * route, as a failed call does. Allow for a cold route: the first call to
   * each new host over Nym took 16 to 35 s on Android Chrome. Without it,
   * only calls that fail count, and a route that hangs is never replaced.
   */
  callTimeoutMs?: number;
  /**
   * How long `start` and the worker's `ready` together may take before the
   * worker is closed and the calls waiting on it fail; the next call starts
   * another. Without it, a start that never finishes holds every call until
   * the caller aborts it.
   */
  readyTimeoutMs?: number;
};

type Outcome = "answered" | "failed" | "timeout" | "abandoned";

/**
 * Whether a worker's route has stopped carrying calls: a call has failed with
 * none answering since (the second such failure, for a worker that has
 * answered before), and either no call to another host is still waiting or
 * the failure is a timeout during which no call to any host answered. A host
 * that fails while another may still answer is that endpoint's problem, not
 * the route's, and replacing the worker would cut off the calls that work. A
 * route that answered nothing for a whole call deadline has shown that no
 * host still answers; waiting on calls to hosts first tried during it would
 * only put the replacement off by a deadline per new host.
 */
export function routeHealth() {
  const waiting = new Map<string, number>();
  const failedHosts = new Set<string>();
  let failures = 0;
  let answers = 0;
  return {
    /** One call has been sent; pass the result to `settled`. */
    sent(host: string): number {
      waiting.set(host, (waiting.get(host) ?? 0) + 1);
      return answers;
    },
    /** One call has finished; true when the route should be replaced. */
    settled(host: string, outcome: Outcome, answersAtSend: number): boolean {
      const left = (waiting.get(host) ?? 1) - 1;
      if (left > 0) waiting.set(host, left);
      else waiting.delete(host);
      if (outcome === "abandoned") return false;
      if (outcome === "answered") {
        answers++;
        failures = 0;
        failedHosts.clear();
        return false;
      }
      failures++;
      failedHosts.add(host);
      if (failures < (answers > 0 ? 2 : 1)) return false;
      if (outcome === "timeout" && answers === answersAtSend) return true;
      return [...waiting.keys()].every((other) => failedHosts.has(other));
    },
  };
}

type Slot<W> = {
  worker: Promise<W>;
  health: ReturnType<typeof routeHealth>;
  lifetime: AbortController;
};

/**
 * A `fetch` over a worker it starts on first use and replaces when the
 * worker's route stops carrying calls (see routeHealth). A call that answers
 * with any status shows the route works; one that fails, or outlasts
 * `callTimeoutMs`, counts against it; one its caller aborts counts for
 * nothing. Replacing closes the old worker, which ends the calls still on it.
 * A worker that fails to start is dropped, so a later call tries again rather
 * than every call failing for the rest of the session.
 */
export class ReplacingWorker<W extends ReplaceableWorker = ReplaceableWorker> {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

  #options: ReplacingWorkerOptions<W>;
  #current?: Slot<W>;
  #closed = false;

  constructor(options: ReplacingWorkerOptions<W>) {
    this.#options = options;
    this.fetch = this.#fetch.bind(this);
  }

  /** The worker in use, once a call has started one; it may not be ready yet. */
  get worker(): Promise<W> | undefined {
    return this.#current?.worker;
  }

  /**
   * Start a worker if none is in use, without a call, and settle when it is
   * ready; it rejects as a call waiting for that worker would.
   */
  async ready(): Promise<void> {
    if (this.#closed) throw closedError();
    await (this.#current ??= this.#startSlot()).worker;
  }

  /** Close the worker in use; pending and later calls fail with code `closed`. */
  close(): void {
    this.#closed = true;
    this.#retire(this.#current);
  }

  async #fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    if (this.#closed) throw closedError();
    const signal = init?.signal ?? (typeof input === "object" && "signal" in input ? input.signal : undefined);
    // The worker takes the call only once it is ready, and a host may reuse
    // init meanwhile.
    init = init && initNow(init);
    const slot = (this.#current ??= this.#startSlot());
    const worker = await untilAborted(slot.worker, signal);
    // The deadline runs from here: waiting for a worker to start is not the
    // route's fault, and counting it would replace a worker still starting.
    // It ends at the response; the caller's signal still ends the body.
    const call = new AbortController();
    let timedOut = false;
    const onAbort = () => call.abort(signal?.reason);
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) onAbort();
    const timer =
      this.#options.callTimeoutMs === undefined
        ? undefined
        : setTimeout(() => {
            timedOut = true;
            call.abort();
          }, this.#options.callTimeoutMs);
    const host = hostOf(input);
    const answersAtSend = slot.health.sent(host);
    try {
      const response = await untilAborted(worker.fetch(input, { ...init, signal: call.signal }), call.signal);
      slot.health.settled(host, "answered", answersAtSend);
      return response;
    } catch (error) {
      signal?.removeEventListener("abort", onAbort);
      const outcome = timedOut ? "timeout" : signal?.aborted ? "abandoned" : "failed";
      if (slot.health.settled(host, outcome, answersAtSend)) this.#retire(slot);
      if (timedOut) {
        throw new RpcError({ name: "TimeoutError", message: "the worker did not answer in time", code: "timeout" });
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  #startSlot(): Slot<W> {
    const lifetime = new AbortController();
    const slot: Slot<W> = { lifetime, health: routeHealth(), worker: undefined as unknown as Promise<W> };
    slot.worker = (async () => {
      // Retiring the slot fails whatever it is still waiting for.
      const retired = new Promise<never>((_, reject) =>
        lifetime.signal.addEventListener("abort", () => reject(closedError()), { once: true }),
      );
      retired.catch(() => {});
      const started = Promise.resolve().then(() => this.#options.start(lifetime.signal));
      started.then(
        (worker) => {
          if (lifetime.signal.aborted) worker.close();
          else lifetime.signal.addEventListener("abort", () => worker.close(), { once: true });
        },
        () => {},
      );
      // The deadline covers `start` as well as `ready`: either may wait on I/O.
      const { readyTimeoutMs } = this.#options;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const late = new Promise<never>((_, reject) => {
        if (readyTimeoutMs === undefined) return;
        timer = setTimeout(
          () => reject(new RpcError({ name: "TimeoutError", message: "the worker did not start in time", code: "timeout" })),
          readyTimeoutMs,
        );
      });
      try {
        const worker = await Promise.race([started, retired, late]);
        await Promise.race([worker.ready, retired, late]);
        return worker;
      } finally {
        clearTimeout(timer);
      }
    })();
    slot.worker.catch(() => this.#retire(slot));
    return slot;
  }

  #retire(slot: Slot<W> | undefined): void {
    if (!slot) return;
    if (this.#current === slot) this.#current = undefined;
    slot.lifetime.abort();
  }
}

export type WorkerPoolOptions<W extends ReplaceableWorker> = ReplacingWorkerOptions<W> & {
  /** The most workers alive at once, over every group and every spare. */
  maxWorkers: number;
  /**
   * How many workers to keep started for groups that have none, from the
   * first `group()` call on. The next group to start a worker takes one, and
   * the pool starts another while the budget allows. Defaults to 0.
   */
  spare?: number;
  /**
   * How long a group's worker may go with no call waiting before it is
   * closed; the group's next call starts another. Without it, a group keeps
   * its worker until it is closed. A response body still being read does not
   * count as a call waiting.
   */
  idleCloseMs?: number;
};

/** One isolation group of a WorkerPool: a `fetch` over a worker of its own. */
export type WorkerGroup = {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
  /** Start the group's worker without a call, and settle when it is ready. */
  ready(): Promise<void>;
  /** Close the group's worker and free its place; later calls fail with code `closed`. */
  close(): void;
};

type Spare<W> = { worker: Promise<W>; lifetime: AbortController; claim(signal: AbortSignal): void };
type Waiter = { grant(): void };
// One worker's use by a group: the calls pending on it, the response bodies
// still being read from it, and when the last call began. A drained use takes
// no new calls, and closes once nothing is pending or callTimeoutMs after it
// was drained.
type Use<W extends ReplaceableWorker> = {
  group: WorkerGroup;
  replacing: ReplacingWorker<W>;
  busy: number;
  reading: number;
  lastUse: number;
  draining: boolean;
  drain(): void;
  settle(): void;
  close(): void;
};

/**
 * Workers for isolation groups under one budget. Each group is a
 * ReplacingWorker of its own, so calls in two groups never share a worker,
 * and the pool counts every worker alive, spares included, against
 * `maxWorkers`. A group whose worker would pass the budget waits, first come
 * first served, until a group closes, idles out or retires a worker; the wait
 * counts towards `readyTimeoutMs`, and a caller's signal ends it for that
 * call. While groups wait, the least recently used groups holding a worker
 * are drained: their later calls start a new worker, which waits like any
 * other, and their worker closes once no call or response body is pending on
 * it, or at the call deadline. Which traffic shares a group is the host's
 * policy.
 */
export class WorkerPool<W extends ReplaceableWorker = ReplaceableWorker> {
  #options: WorkerPoolOptions<W>;
  #groups = new Map<string, WorkerGroup>();
  #spares: Spare<W>[] = [];
  #waiting: Waiter[] = [];
  // The use each worker holding a place serves, by the worker's lifetime.
  #holders = new Map<AbortSignal, Use<W>>();
  #uses = 0;
  #live = 0;
  #closed = false;

  constructor(options: WorkerPoolOptions<W>) {
    const { maxWorkers, spare = 0, idleCloseMs } = options;
    if (!Number.isInteger(maxWorkers) || maxWorkers < 1) throw unsupported("maxWorkers must be a positive integer");
    if (!Number.isInteger(spare) || spare < 0 || spare > maxWorkers) {
      throw unsupported("spare must be an integer from 0 to maxWorkers");
    }
    checkIdleClose(idleCloseMs);
    this.#options = options;
  }

  /**
   * The group named `key`, made on first use; the same object until it is
   * closed. `idleCloseMs` overrides the pool's for a group this call makes.
   */
  group(key: string, options: { idleCloseMs?: number } = {}): WorkerGroup {
    if (this.#closed) throw closedError();
    let group = this.#groups.get(key);
    if (!group) {
      checkIdleClose(options.idleCloseMs);
      group = this.#makeGroup(key, options.idleCloseMs ?? this.#options.idleCloseMs);
      this.#groups.set(key, group);
      this.#refill();
    }
    return group;
  }

  /** Close every group and spare; waiting and later calls fail with code `closed`. */
  close(): void {
    if (this.#closed) return;
    this.#closed = true;
    for (const waiter of this.#waiting.splice(0)) waiter.grant();
    for (const group of [...this.#groups.values()]) group.close();
    for (const spare of this.#spares.splice(0)) closeSpare(spare);
  }

  #makeGroup(key: string, idleCloseMs: number | undefined): WorkerGroup {
    const { callTimeoutMs, readyTimeoutMs } = this.#options;
    let use: Use<W> | undefined;
    let closed = false;
    let idle: ReturnType<typeof setTimeout> | undefined;
    const current = (): Use<W> => {
      if (use) return use;
      let bound: ReturnType<typeof setTimeout> | undefined;
      const made: Use<W> = {
        group,
        replacing: new ReplacingWorker<W>({ start: (signal) => this.#start(signal, made), callTimeoutMs, readyTimeoutMs }),
        busy: 0,
        reading: 0,
        lastUse: 0,
        draining: false,
        drain: () => {
          if (made.draining) return;
          made.draining = true;
          if (use === made) {
            use = undefined;
            clearTimeout(idle);
          }
          if (made.busy === 0 && made.reading === 0) made.close();
          else if (callTimeoutMs !== undefined) bound = setTimeout(made.close, callTimeoutMs);
        },
        settle: () => {
          if (made.draining && made.busy === 0 && made.reading === 0) made.close();
        },
        close: () => {
          clearTimeout(bound);
          made.replacing.close();
        },
      };
      return (use = made);
    };
    const using = async <T>(run: (worker: ReplacingWorker<W>) => Promise<T>, held = current()): Promise<T> => {
      held.busy++;
      held.lastUse = ++this.#uses;
      clearTimeout(idle);
      try {
        return await run(held.replacing);
      } finally {
        if (--held.busy === 0) {
          if (held.draining) held.settle();
          else if (idleCloseMs !== undefined && !closed) {
            idle = setTimeout(() => {
              if (use !== held) return;
              use = undefined;
              held.close();
            }, idleCloseMs);
          }
        }
      }
    };
    const group: WorkerGroup = {
      fetch: (input, init) => {
        // As ReplacingWorker takes it, keeping a signal init inherits.
        const now = init && { ...initNow(init), signal: init.signal };
        if (closed) return Promise.reject(closedError());
        const held = current();
        return using(async (worker) => {
          const response = await worker.fetch(input, now);
          // Counted before the call stops being pending, so a drained worker
          // never closes between the two.
          held.reading++;
          return readTracked(response, () => {
            held.reading--;
            held.settle();
          });
        }, held);
      },
      ready: () => (closed ? Promise.reject(closedError()) : using((worker) => worker.ready())),
      close: () => {
        if (closed) return;
        closed = true;
        clearTimeout(idle);
        use?.close();
        use = undefined;
        // A drained worker of the group closes with it.
        for (const held of this.#holders.values()) if (held.group === group) held.close();
        if (this.#groups.get(key) === group) this.#groups.delete(key);
      },
    };
    return group;
  }

  // A group's ReplacingWorker starts each worker here. The worker holds its
  // place in the budget until `signal`, its lifetime, aborts.
  async #start(signal: AbortSignal, use: Use<W>): Promise<W> {
    // A group closed before its start ran takes nothing: a spare claimed
    // with a signal already aborted would never free its place.
    if (this.#closed || signal.aborted) throw closedError();
    const spare = this.#spares.shift();
    if (spare) {
      spare.claim(signal);
      this.#hold(signal, use);
      this.#refill();
      return spare.worker;
    }
    await this.#acquire(signal);
    if (this.#closed || signal.aborted) {
      this.#release();
      throw closedError();
    }
    signal.addEventListener("abort", () => this.#release(), { once: true });
    this.#hold(signal, use);
    // Drained at once, with nothing pending: start no worker for it.
    if (signal.aborted) throw closedError();
    return this.#options.start(signal);
  }

  // The worker of `signal` holds a place for `use` until it closes. A group
  // that took a place while others still wait may itself be drained, so the
  // place is released on `signal` before this runs.
  #hold(signal: AbortSignal, use: Use<W>): void {
    this.#holders.set(signal, use);
    signal.addEventListener("abort", () => this.#holders.delete(signal), { once: true });
    this.#turnover();
  }

  // Drain as many holders as there are waiting groups no drained holder will
  // free a place for, least recently used first.
  #turnover(): void {
    const holders = [...this.#holders.values()];
    let needed = this.#waiting.length - holders.filter((use) => use.draining).length;
    for (const use of holders.filter((use) => !use.draining).sort((a, b) => a.lastUse - b.lastUse)) {
      if (needed-- <= 0) return;
      use.drain();
    }
  }

  #acquire(signal: AbortSignal): Promise<void> {
    if (this.#live < this.#options.maxWorkers) {
      this.#live++;
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => {
      const waiter: Waiter = {
        grant: () => {
          signal.removeEventListener("abort", onAbort);
          this.#live++;
          resolve();
        },
      };
      const onAbort = () => {
        this.#waiting.splice(this.#waiting.indexOf(waiter), 1);
        reject(closedError());
      };
      signal.addEventListener("abort", onAbort, { once: true });
      this.#waiting.push(waiter);
      this.#turnover();
    });
  }

  // A place in the budget is free: it goes to the longest waiting group, or
  // else to a new spare. A spare that failed before any group took it frees
  // its place without starting another, so a start that keeps failing does
  // not loop.
  #release(refill = true): void {
    this.#live--;
    const next = this.#waiting.shift();
    if (next) next.grant();
    else if (refill) this.#refill();
  }

  #refill(): void {
    const { spare: wanted = 0, maxWorkers, readyTimeoutMs } = this.#options;
    while (!this.#closed && this.#spares.length < wanted && this.#live < maxWorkers && this.#waiting.length === 0) {
      this.#live++;
      const lifetime = new AbortController();
      let claimed = false;
      const worker = Promise.resolve().then(() => this.#options.start(lifetime.signal));
      const spare: Spare<W> = {
        worker,
        lifetime,
        claim: (signal) => {
          claimed = true;
          signal.addEventListener("abort", () => closeSpare(spare, () => this.#release()), { once: true });
        },
      };
      let timer: ReturnType<typeof setTimeout> | undefined;
      const late = new Promise<never>((_, reject) => {
        if (readyTimeoutMs !== undefined) timer = setTimeout(() => reject(new Error("spare not ready in time")), readyTimeoutMs);
      });
      Promise.race([worker.then((w) => w.ready), late])
        .catch(() => {
          if (claimed || this.#closed) return;
          this.#spares.splice(this.#spares.indexOf(spare), 1);
          closeSpare(spare, () => this.#release(false));
        })
        .finally(() => clearTimeout(timer));
      this.#spares.push(spare);
    }
  }
}

// `response`, calling `done` once its body has been read, has failed, or was
// cancelled, or at once when it has none: closing a worker would end a body
// still arriving (§9.2).
function readTracked(response: Response, done: () => void): Response {
  const source = response.body;
  if (!source) {
    done();
    return response;
  }
  const reader = source.getReader();
  let open = true;
  const finish = () => {
    if (open) {
      open = false;
      done();
    }
  };
  const body = new ReadableStream<Uint8Array>({
    pull: async (controller) => {
      try {
        const chunk = await reader.read();
        if (chunk.done) {
          finish();
          controller.close();
        } else controller.enqueue(chunk.value);
      } catch (e) {
        finish();
        controller.error(e);
      }
    },
    cancel: (reason) => {
      finish();
      return reader.cancel(reason);
    },
  });
  const tracked = new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers });
  if (response.url) Object.defineProperty(tracked, "url", { value: response.url });
  return tracked;
}

function closeSpare<W extends ReplaceableWorker>(spare: Spare<W>, after?: () => void): void {
  spare.lifetime.abort();
  spare.worker.then(
    (worker) => worker.close(),
    () => {},
  );
  after?.();
}

function checkIdleClose(idleCloseMs: number | undefined): void {
  if (idleCloseMs !== undefined && !(idleCloseMs >= 0)) throw unsupported("idleCloseMs must not be negative");
}

function unsupported(message: string): RpcError {
  return new RpcError({ name: "RpcError", message, code: "unsupported" });
}

function closedError(): RpcError {
  return new RpcError({ name: "Error", message: "worker closed", code: "closed" });
}

// The value, or the signal's reason as soon as it aborts, as AnonRpcWorker.fetch
// rejects: a call stops waiting for a worker or a response that other calls
// share. An AbortError stands in where the platform gives no reason (React
// Native's AbortController).
function untilAborted<T>(value: Promise<T>, signal?: AbortSignal | null): Promise<T> {
  if (!signal) return value;
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(signal.reason === undefined ? abortError() : signal.reason);
    signal.addEventListener("abort", onAbort);
    // Settling after an abort is a no-op, and handles a rejection nothing else awaits.
    value.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
    if (signal.aborted) onAbort();
  });
}

function abortError(): Error {
  const error = new Error("The operation was aborted.");
  error.name = "AbortError";
  return error;
}

// The authority of an absolute URL, without its userinfo: what calls to one
// endpoint share. Parsed by hand, since React Native's URL lacks `host`.
function hostOf(input: RequestInfo | URL): string {
  const url = typeof input === "string" ? input : "href" in input ? input.href : input.url;
  const authority = /^[a-z][a-z0-9+.-]*:\/\/([^/?#]*)/i.exec(url)?.[1] ?? url;
  return authority.slice(authority.lastIndexOf("@") + 1).toLowerCase();
}
