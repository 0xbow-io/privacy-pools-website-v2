// Workarounds for defects in specific published worker bundles, keyed by the
// bundle hash a specifier pins. A quirk applies to those exact bytes and
// nothing else: a fixed release has a new hash and runs without it, so an
// entry needs no removal date to stop applying. Each entry names the defect
// and what it does to calls; drop it once no specifier still pins the hash.
//
// The harness otherwise treats every worker alike (§5). These entries exist
// because a worker is fixed code: when a published bundle mishandles a call
// the spec defines, the host has no other way to keep using that worker
// until its publisher ships a new one.

import type { HeaderList } from "../spec-types.js";

export type WorkerQuirks = {
  /**
   * Also give each request's `headers` its fields as named properties (see
   * `headersWithFields`). For a worker that hands `headers` to a reader of
   * `{ name: value }` objects, which drops a `HeaderList` entirely.
   */
  readonly headerFields?: true;
};

const NONE: WorkerQuirks = Object.freeze({});

const BY_HASH: ReadonlyMap<string, WorkerQuirks> = new Map([
  // Nym's anon-rpc-worker 0.1.0, as its specifier pinned it on 2026-10-15.
  // It passes `requestInit.headers` unchanged to @nymproject/mix-fetch, and
  // smolmix's `extract_headers` reads `headers` with `Object.keys`, keeping
  // string values only. A `HeaderList`'s keys are indices whose values are
  // arrays, so every header was dropped: a JSON-RPC POST arrived without
  // `Content-Type`, and endpoints that require it answered 415.
  ["0xf13a448a8721b9d0b20da3d5b80ffe00bf4c5bb3aae812a38d3d1e3bc81fceb8", Object.freeze({ headerFields: true as const })],
]);

/** The quirks for a verified bundle hash; none for any hash not listed. */
export function workerQuirks(workerHash: string): WorkerQuirks {
  return BY_HASH.get(workerHash.toLowerCase()) ?? NONE;
}

/** The request as `quirks` says to deliver it; the same object when none apply. */
export function applyRequestQuirks<T extends { headers?: HeaderList }>(requestInit: T | undefined, quirks: WorkerQuirks): T | undefined {
  if (!quirks.headerFields || !requestInit?.headers) return requestInit;
  return { ...requestInit, headers: headersWithFields(requestInit.headers) };
}

// An array index or `length`: names an Array's own data already claims.
// Defining either would corrupt the list rather than add a field.
function isArrayOwnKey(key: string): boolean {
  return key === "length" || (/^(?:0|[1-9]\d*)$/.test(key) && Number(key) < 2 ** 32 - 1);
}

/**
 * A copy of `headers` that is still the same `HeaderList`, plus one
 * enumerable property per field name holding its value: `headers["content-type"]`
 * reads `"application/json"`. Iteration, indexing, `length`, `JSON.stringify`
 * and `new Headers(headers)` see only the pairs, so a worker that follows
 * §9.1 is unaffected. Structured clone carries the properties, so they reach
 * a worker's own nested workers too.
 *
 * Names are lower-cased, as fetch's `Headers` reports them, and repeated
 * fields are joined with ", " (RFC 9110 §5.3). A name that is an array index
 * or `length` keeps its pair but gets no property.
 */
export function headersWithFields(headers: HeaderList): HeaderList {
  const out: HeaderList = headers.map(([name, value]) => [name, value]);
  const fields = new Map<string, string>();
  for (const [name, value] of headers) {
    const key = name.toLowerCase();
    if (isArrayOwnKey(key)) continue;
    const prior = fields.get(key);
    fields.set(key, prior === undefined ? value : `${prior}, ${value}`);
  }
  for (const [key, value] of fields) {
    // defineProperty, not assignment: a name like `__proto__` must become a
    // field rather than replace the array's prototype.
    Object.defineProperty(out, key, { value, enumerable: true, writable: true, configurable: true });
  }
  return out;
}
