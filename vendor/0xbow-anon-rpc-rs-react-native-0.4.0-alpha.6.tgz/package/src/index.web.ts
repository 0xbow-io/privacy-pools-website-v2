// The web entry: the browser harness itself, whose `AnonRpcWorker.tor` takes
// `{gateways, rpcProvider, iframeUrl?}` and runs tor-js.
export { AnonRpcWorker, RpcError } from "@0xbow/anon-rpc-rs-browser-harness";
export type { LogArg, LogEntry, RpcProvider, WorkerGroup, WorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";
export { ReplacingWorker, WorkerPool } from "./ReplacingWorker.web";
export type { ReplacingWorkerOptions, WorkerPoolOptions, WorkerStart } from "./ReplacingWorker.web";
export { ErrorCode } from "./error-code.g";
