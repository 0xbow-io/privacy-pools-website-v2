import type { CodegenTypes, TurboModule } from "react-native";
import { TurboModuleRegistry } from "react-native";

/** A worker's request to read its specifier through the JavaScript provider. */
export type ProviderRequest = {
  workerId: number;
  requestId: number;
  method: string;
  /** The JSON-RPC params, as JSON. */
  params: string;
};

/**
 * The native module over the Swift and Kotlin SDKs. Workers and calls are
 * numbered by the JavaScript side; bytes cross as base64 and values as JSON.
 * A failed promise rejects with the error's code (or the worker's own code)
 * as its `code`. The `create` calls, `poolGroup`, `close` and `closePool`
 * are synchronous, so they run in the order JavaScript makes them: each
 * returns `null`, or its failure as `Failure` JSON.
 */
export interface Spec extends TurboModule {
  /** A Tor worker from `TorInit` JSON. */
  createTor(workerId: number, initJson: string): string | null;
  /** A worker from `SpecifierInit` JSON, which reads through the worker's provider requests. */
  createFromAddress(workerId: number, initJson: string): string | null;
  /** A worker from bundle bytes as base64 and `WorkerSettings` JSON. */
  createFromBundle(workerId: number, bundleBase64: string, settingsJson: string): string | null;
  /**
   * A replacing worker (SPEC §5.1) from `ReplacingInit` JSON, with a bundle
   * start's bytes as base64. A specifier start reads through the worker's
   * provider requests.
   */
  createReplacing(workerId: number, initJson: string, bundleBase64: string | null): string | null;
  /**
   * A worker pool (SPEC §5.2) from `PoolInit` JSON, with a bundle start's
   * bytes as base64. A specifier start reads through the pool's provider
   * requests.
   */
  createPool(poolId: number, initJson: string, bundleBase64: string | null): string | null;
  /** Register the pool's group that `PoolGroup` JSON names as worker `workerId`. */
  poolGroup(poolId: number, workerId: number, groupJson: string): string | null;
  closePool(poolId: number): string | null;
  ready(workerId: number): Promise<void>;
  /**
   * Resolves with `{"status", "headers", "url", "body"}` JSON, the body as
   * base64, once the whole body has arrived.
   */
  fetch(
    workerId: number,
    callId: number,
    headJson: string,
    bodyBase64: string | null,
  ): Promise<string>;
  /** Resolves with `{"level", "args"}` JSON, args tagged as in the C ABI. */
  acceptLog(workerId: number, callId: number): Promise<string>;
  /** Cancel a pending `fetch` or `acceptLog`, which then rejects with `cancelled`. */
  cancel(callId: number): void;
  close(workerId: number): string | null;
  /** Answer a provider request with `{"result"}` or `{"error"}` JSON. */
  respondProvider(workerId: number, requestId: number, responseJson: string): void;

  readonly onProviderRequest: CodegenTypes.EventEmitter<ProviderRequest>;
}

export default TurboModuleRegistry.getEnforcing<Spec>("AnonRpc");
