// ReplacingWorker and WorkerPool over the Swift and Kotlin SDKs, whose
// anon-rpc crate runs the replacement rule and the budget (SPEC §5.1, §5.2).

import native from "./NativeAnonRpc";
import {
  created,
  fetchThrough,
  forgetProvider,
  nextNativeId,
  rpcError,
  serveProvider,
  startParts,
  type RpcProvider,
  type WorkerStart,
} from "./AnonRpcWorker";
import { encodePoolGroup, encodePoolInit, encodeReplacingInit } from "./wire.g";

export type ReplacingWorkerOptions = {
  /** How each worker starts. */
  start: WorkerStart;
  /**
   * How long a call may wait for its response head once the worker is ready.
   * A call still waiting then fails with code `timeout` and counts against
   * the route. Without it, a route that hangs is never replaced.
   */
  callTimeoutMs?: number;
  /** How long starting a worker and its `ready` together may take. */
  readyTimeoutMs?: number;
};

export type WorkerPoolOptions = ReplacingWorkerOptions & {
  /** The most workers alive at once, over every group and every spare. */
  maxWorkers: number;
  /** How many workers to keep started for groups that have none. Defaults to 0. */
  spare?: number;
  /** How long a group's worker may go with no call pending before it closes. */
  idleCloseMs?: number;
};

/** One isolation group of a WorkerPool: a `fetch` over a worker of its own. */
export type WorkerGroup = {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: typeof fetch;
  /** Start the group's worker without a call, and settle when it is ready. */
  ready(): Promise<void>;
  /** Close the group's worker and free its place; later calls fail with code `closed`. */
  close(): void;
};

/** Create native worker or pool `id`, serving `provider` to it; the creation's failure is thrown. */
function create(id: number, provider: RpcProvider | undefined, make: () => string | null): void {
  if (provider) serveProvider(id, provider);
  try {
    created(make());
  } catch (error) {
    forgetProvider(id);
    throw error;
  }
}

/** Wait for native worker `id` to be ready. */
async function ready(id: number): Promise<void> {
  await native.ready(id).catch((error) => {
    throw rpcError(error);
  });
}

/** A `fetch` over a worker it starts on first use and replaces when the worker's route stops carrying calls. */
export class ReplacingWorker {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: typeof fetch;

  #id = nextNativeId();

  constructor(options: ReplacingWorkerOptions) {
    const [start, bundle, provider] = startParts(options.start);
    const init = JSON.stringify(
      encodeReplacingInit({ start, call_timeout_ms: options.callTimeoutMs, ready_timeout_ms: options.readyTimeoutMs }),
    );
    create(this.#id, provider, () => native.createReplacing(this.#id, init, bundle));
    this.fetch = (input, init) => fetchThrough(this.#id, input, init);
  }

  /** Start a worker if none is in use, without a call, and settle when it is ready. */
  ready(): Promise<void> {
    return ready(this.#id);
  }

  /** Close the worker in use; pending and later calls fail with code `closed`. */
  close(): void {
    forgetProvider(this.#id);
    native.close(this.#id);
  }
}

/**
 * Workers for isolation groups under one budget. Each group is a replacing
 * worker of its own, and the pool counts every worker alive, spares
 * included, against `maxWorkers`. Which traffic shares a group is the host's
 * policy.
 */
export class WorkerPool {
  #id = nextNativeId();
  #groups = new Map<string, WorkerGroup>();

  constructor(options: WorkerPoolOptions) {
    const [start, bundle, provider] = startParts(options.start);
    const init = JSON.stringify(
      encodePoolInit({
        start,
        max_workers: options.maxWorkers,
        spare: options.spare,
        idle_close_ms: options.idleCloseMs,
        call_timeout_ms: options.callTimeoutMs,
        ready_timeout_ms: options.readyTimeoutMs,
      }),
    );
    create(this.#id, provider, () => native.createPool(this.#id, init, bundle));
  }

  /**
   * The group named `key`, made on first use; the same object until it is
   * closed. `idleCloseMs` replaces the pool's for a group this call makes.
   */
  group(key: string, options: { idleCloseMs?: number } = {}): WorkerGroup {
    const existing = this.#groups.get(key);
    if (existing) return existing;
    const id = nextNativeId();
    const request = JSON.stringify(encodePoolGroup({ key, idle_close_ms: options.idleCloseMs }));
    created(native.poolGroup(this.#id, id, request));
    const groups = this.#groups;
    const group: WorkerGroup = {
      fetch: (input, init) => fetchThrough(id, input, init),
      ready: () => ready(id),
      close: () => {
        native.close(id);
        if (groups.get(key) === group) groups.delete(key);
      },
    };
    groups.set(key, group);
    return group;
  }

  /** Close every group and spare; waiting and later calls fail with code `closed`. */
  close(): void {
    this.#groups.clear();
    forgetProvider(this.#id);
    native.closePool(this.#id);
  }
}
