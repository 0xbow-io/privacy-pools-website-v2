// The browser harness's ReplacingWorker and WorkerPool, taking a `start`
// description as the native entry does: each worker is the harness's own
// AnonRpcWorker.

import {
  AnonRpcWorker,
  ReplacingWorker as HarnessReplacingWorker,
  RpcError,
  WorkerPool as HarnessWorkerPool,
  type TorInit,
  type WorkerInit,
} from "@0xbow/anon-rpc-rs-browser-harness";

/**
 * How a replacing worker or a pool starts each worker on the web: the
 * options of one of the harness's `AnonRpcWorker` constructors. A `tor`
 * start takes `{gateways, rpcProvider, iframeUrl?}` and runs tor-js.
 */
export type WorkerStart = { tor: TorInit } | { specifier: WorkerInit };

export type ReplacingWorkerOptions = {
  /** How each worker starts. */
  start: WorkerStart;
  /** How long a call may wait for its response head once the worker is ready. */
  callTimeoutMs?: number;
  /** How long starting a worker and its `ready` together may take. */
  readyTimeoutMs?: number;
};

export type WorkerPoolOptions = ReplacingWorkerOptions & {
  /** The most workers alive at once, over every group and every spare. */
  maxWorkers: number;
  /** How many workers to keep started for groups that have none. Defaults to 0. */
  spare?: number;
  /** How long a group's worker may go with no call pending before it closes. */
  idleCloseMs?: number;
};

/** The harness worker each `start` makes; a start must name exactly one form, as on native. */
function starter(start: WorkerStart): () => AnonRpcWorker {
  const forms = ["tor", "specifier", "bundle"].filter((form) => form in start);
  if (forms.length !== 1) throw unsupported("start names exactly one of tor, specifier and bundle");
  if ("specifier" in start) return () => new AnonRpcWorker(start.specifier);
  if ("tor" in start) return () => AnonRpcWorker.tor(start.tor);
  throw unsupported("a bundle start needs the native module");
}

function unsupported(message: string): RpcError {
  return new RpcError({ name: "RpcError", message, code: "unsupported" });
}

export class ReplacingWorker extends HarnessReplacingWorker<AnonRpcWorker> {
  constructor(options: ReplacingWorkerOptions) {
    super({ ...options, start: starter(options.start) });
  }
}

export class WorkerPool extends HarnessWorkerPool<AnonRpcWorker> {
  constructor(options: WorkerPoolOptions) {
    super({ ...options, start: starter(options.start) });
  }
}
