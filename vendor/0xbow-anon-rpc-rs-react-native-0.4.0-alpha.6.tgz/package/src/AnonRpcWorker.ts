// The browser harness's `AnonRpcWorker` API over the Swift and Kotlin SDKs.

import { NativeEventEmitter, Platform, type EventSubscription } from "react-native";

import native, { type ProviderRequest } from "./NativeAnonRpc";
import {
  NULL_BODY_STATUSES,
  RpcError,
  decodeBase64,
  decodeBufferedResponse,
  decodeFailure,
  decodeLogEntry,
  encodeBase64,
  encodeProviderResponse,
  encodeRequestHead,
  encodeSpecifierInit,
  encodeTorInit,
  encodeWorkerSettings,
  failureError,
  type AnonRpcValue,
  type LogEntry,
  type ProviderResponse,
  type WorkerStart as WireWorkerStart,
} from "./wire.g";
import { workerFields } from "./worker-fields";

export { RpcError, type AnonRpcValue, type LogArg, type LogEntry, type LogLevel } from "./wire.g";

/** Minimal EIP-1193 provider: enough to read a specifier contract. */
export type RpcProvider = {
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
};

/**
 * A worker config: `null`, booleans, finite numbers, strings,
 * `Uint8Array`s, arrays, and plain objects of these.
 */
export type Value = AnonRpcValue;

/** Where a worker keeps its storage, and what its `fetch` may reach. */
export type HostOptions = {
  /** The directory the worker's storage lives in; defaults to the app's own. */
  storageDir?: string;
  /** Let the worker's `fetch` reach loopback and private networks. */
  allowPrivateNetworks?: boolean;
};

export type WorkerInit = HostOptions & {
  /** The specifier contract address. */
  address: string;
  /** Delivered to the worker as `anonRpcWorker.config`. */
  config?: Value;
  /**
   * The chain the specifier contract is published on, which is the chain
   * `rpcProvider` must answer for. When set, the worker asks the provider for
   * `eth_chainId` before reading the specifier, and `ready` fails with
   * `protocol-error` on any other chain. It does not limit the chains the
   * worker's fetches reach.
   */
  specifierChainId?: number;
  /**
   * The bundle hash this host requires, as `0x` and 64 hex digits. When set,
   * the worker compares it with the specifier's `workerHash()` before
   * fetching any bundle, and `ready` fails with `protocol-error` when they
   * differ.
   */
  expectedWorkerHash?: string;
  preExisting?: {
    /** Reads the specifier contract. */
    rpcProvider?: RpcProvider;
  };
};

export type BundleInit = HostOptions & {
  /** Delivered to the worker as `anonRpcWorker.config`. */
  config?: Value;
};

/** Where the Tor client keeps its state and directory cache; both default to the app's own directories. */
export type TorConfig = {
  stateDir?: string;
  cacheDir?: string;
};

/**
 * How a replacing worker or a pool starts each worker: the options of one of
 * `AnonRpcWorker`'s constructors.
 */
export type WorkerStart = { tor: TorConfig } | { specifier: WorkerInit } | { bundle: Uint8Array; init?: BundleInit };

/**
 * The wire form of `start`, its bundle as base64, and the provider a
 * specifier start reads through. Every form `start` names crosses, so the
 * crate refuses a start that names more than one.
 */
export function startParts(start: WorkerStart): [WireWorkerStart, string | null, RpcProvider | undefined] {
  const wire: WireWorkerStart = {};
  let bundle: string | null = null;
  let provider: RpcProvider | undefined;
  if ("tor" in start) wire.tor = { state_dir: start.tor.stateDir, cache_dir: start.tor.cacheDir };
  if ("bundle" in start) {
    const init = start.init ?? {};
    wire.bundle = { config: init.config, storage_dir: init.storageDir, allow_private_networks: init.allowPrivateNetworks };
    bundle = encodeBase64(start.bundle);
  }
  if ("specifier" in start) {
    const init = start.specifier;
    provider = init.preExisting?.rpcProvider;
    if (!provider) throw new TypeError("preExisting.rpcProvider is required to read the specifier");
    wire.specifier = {
      address: init.address,
      config: init.config,
      specifier_chain_id: init.specifierChainId,
      expected_worker_hash: init.expectedWorkerHash,
      storage_dir: init.storageDir,
      allow_private_networks: init.allowPrivateNetworks,
    };
  }
  return [wire, bundle, provider];
}

/** Throw the failure a synchronous native call returned, if it returned one. */
export function created(failure: string | null): void {
  if (failure !== null) throw failureError(decodeFailure(JSON.parse(failure)));
}

export function rpcError(error: unknown): unknown {
  const code = (error as { code?: unknown } | null)?.code;
  if (!(error instanceof Error) || typeof code !== "string") return error;
  return new RpcError({ name: "RpcError", message: error.message, code });
}

function abortReason(signal: AbortSignal): unknown {
  return signal.reason === undefined ? Object.assign(new Error("aborted"), { name: "AbortError" }) : signal.reason;
}

let nextId = 1;
const providers = new Map<number, RpcProvider>();

/** A new number for a native worker, pool or call. */
export function nextNativeId(): number {
  return nextId++;
}

/** Answer the provider requests of native worker or pool `id` with `provider`. */
export function serveProvider(id: number, provider: RpcProvider): void {
  providers.set(id, provider);
  serveProviders();
}

/** Stop answering the provider requests of native worker or pool `id`. */
export function forgetProvider(id: number): void {
  providers.delete(id);
}
let subscription: EventSubscription | undefined;

/**
 * Subscribe to the native provider requests. Only the New Architecture
 * gives the module its codegen event emitter; on the legacy architecture
 * the module sends them as device events, which iOS counts the listeners of
 * through the module itself.
 */
function onProviderRequest(listener: (request: ProviderRequest) => void): EventSubscription {
  if (typeof native.onProviderRequest === "function") return native.onProviderRequest(listener);
  type EmitterModule = ConstructorParameters<typeof NativeEventEmitter>[0];
  const emitter = new NativeEventEmitter(Platform.OS === "ios" ? (native as unknown as EmitterModule) : undefined);
  return emitter.addListener("onProviderRequest", listener);
}

/** Answer the native provider requests with each worker's JavaScript provider. */
function serveProviders(): void {
  subscription ??= onProviderRequest(async ({ workerId, requestId, method, params }) => {
    let response: ProviderResponse;
    try {
      const provider = providers.get(workerId);
      if (!provider) throw new Error("the worker has no provider");
      response = { result: (await provider.request({ method, params: JSON.parse(params) })) ?? null };
    } catch (error) {
      response = { error: error instanceof Error ? error.message : String(error) };
    }
    native.respondProvider(workerId, requestId, JSON.stringify(encodeProviderResponse(response)));
  });
}

/**
 * The bytes of a request's body, or `null` without one. React Native's
 * `Request` has no `body` stream, and reads every body, an empty one
 * included, through a native `Blob` whose data can be released before the
 * read completes, so string and byte bodies are copied directly.
 */
async function requestBody(
  input: RequestInfo | URL,
  init: RequestInit | undefined,
  request: Request,
): Promise<Uint8Array | null> {
  const body = init?.body;
  if (body == null) return input instanceof Request ? new Uint8Array(await request.arrayBuffer()) : null;
  if (typeof body === "string") return new TextEncoder().encode(body);
  if (body instanceof ArrayBuffer) return new Uint8Array(body.slice(0));
  if (ArrayBuffer.isView(body)) return new Uint8Array(body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength));
  return new Uint8Array(await request.arrayBuffer());
}

/**
 * Run a native call numbered `callId`. When `signal` aborts, the call is
 * cancelled and the promise rejects at once with the abort reason.
 */
function cancellable<T>(callId: number, signal: AbortSignal | null | undefined, call: Promise<T>): Promise<T> {
  if (signal?.aborted) {
    native.cancel(callId);
    return Promise.reject(abortReason(signal));
  }
  return new Promise<T>((resolve, reject) => {
    const cancel = () => {
      native.cancel(callId);
      reject(abortReason(signal!));
    };
    signal?.addEventListener("abort", cancel);
    call
      .then(resolve, (error: unknown) => reject(rpcError(error)))
      .finally(() => signal?.removeEventListener("abort", cancel));
  });
}

/** Send a standard fetch through native worker `id`. */
export async function fetchThrough(
  id: number,
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  // Read before anything is awaited, as fetch reads init; a Request carries
  // no worker-defined fields (§9.3).
  const fields = workerFields(init);
  const request = new Request(input as RequestInfo, init);
  const signal = init?.signal ?? request.signal;
  if (signal?.aborted) throw abortReason(signal);
  const body = await requestBody(input, init, request);
  const head = JSON.stringify(
    encodeRequestHead({
      method: request.method,
      url: request.url,
      headers: [...(request.headers as unknown as Iterable<[string, string]>)],
      redirect: init?.redirect ?? (input instanceof Request ? input.redirect : undefined) ?? "follow",
      fields,
    }),
  );
  const callId = nextId++;
  const response = decodeBufferedResponse(
    JSON.parse(
      await cancellable(
        callId,
        signal,
        native.fetch(id, callId, head, body && body.byteLength > 0 ? encodeBase64(body) : null),
      ),
    ),
  );
  const bytes = NULL_BODY_STATUSES.includes(response.status) ? null : decodeBase64(response.body);
  const url = response.url ?? request.url;
  // React Native's `Response` takes its `url` as an option.
  const result = new Response(bytes, { status: response.status, headers: response.headers, url } as ResponseInit);
  if (result.url !== url) Object.defineProperty(result, "url", { value: url });
  return result;
}

// The native creation a factory hands to the constructor.
let adopting: ((id: number) => string | null) | undefined;

function adopt(create: (id: number) => string | null): AnonRpcWorker {
  adopting = create;
  try {
    return new AnonRpcWorker(undefined as never);
  } finally {
    adopting = undefined;
  }
}

export class AnonRpcWorker {
  ready: Promise<void>;
  /** A standard `fetch`, bound so that it works as a free function. */
  fetch: typeof fetch;

  #id = nextId++;

  /** A worker that sends its traffic over the native Tor client. */
  static tor(config: TorConfig = {}): AnonRpcWorker {
    const [start] = startParts({ tor: config });
    const json = JSON.stringify(encodeTorInit(start.tor!));
    return adopt((id) => native.createTor(id, json));
  }

  /** A worker from bundle bytes already in hand. */
  static bundle(bundle: Uint8Array, init: BundleInit = {}): AnonRpcWorker {
    const [start, bytes] = startParts({ bundle, init });
    const json = JSON.stringify(encodeWorkerSettings(start.bundle!));
    return adopt((id) => native.createFromBundle(id, bytes!, json));
  }

  constructor(init: WorkerInit) {
    let create = adopting;
    let provider: RpcProvider | undefined;
    if (!create) {
      const [start, , rpcProvider] = startParts({ specifier: init });
      const json = JSON.stringify(encodeSpecifierInit(start.specifier!));
      provider = rpcProvider;
      create = (id) => native.createFromAddress(id, json);
    }
    if (provider) serveProvider(this.#id, provider);
    try {
      created(create(this.#id));
    } catch (error) {
      forgetProvider(this.#id);
      throw error;
    }
    this.ready = native.ready(this.#id).catch((error) => {
      throw rpcError(error);
    });
    // A caller need not await `ready`; awaiting callers still observe a
    // rejection.
    this.ready.catch(() => {});
    this.fetch = this.#fetch.bind(this);
  }

  #fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    return fetchThrough(this.#id, input, init);
  }

  /**
   * The next log entry the worker produced, waiting for one if none is
   * retained. An abort consumes no entry: it cancels the native take, and an
   * entry the take already had is returned rather than lost.
   */
  async acceptLog(opts?: { signal?: AbortSignal }): Promise<LogEntry> {
    const signal = opts?.signal;
    if (signal?.aborted) throw abortReason(signal);
    const callId = nextId++;
    const cancel = () => native.cancel(callId);
    signal?.addEventListener("abort", cancel);
    try {
      return decodeLogEntry(JSON.parse(await native.acceptLog(this.#id, callId)));
    } catch (error) {
      throw signal?.aborted ? abortReason(signal) : rpcError(error);
    } finally {
      signal?.removeEventListener("abort", cancel);
    }
  }

  /** Stop the worker; pending and later calls fail with `closed`. */
  close(): void {
    forgetProvider(this.#id);
    native.close(this.#id);
  }
}
