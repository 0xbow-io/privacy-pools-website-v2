# The AnonRpc Swift package as a CocoaPod, for apps that link it through
# CocoaPods, such as React Native apps. Build Artifacts/AnonRpcC.xcframework
# with build-xcframework.sh first.
Pod::Spec.new do |s|
  s.name = "AnonRpc"
  s.version = "0.4.0-alpha.6"
  s.summary = "Anonymized HTTP for iOS over the anon-rpc native library."
  s.homepage = "https://github.com/0xbow-io/anon-rpc-rs"
  s.license = "MIT"
  s.authors = "anon-rpc contributors"
  s.source = { :git => "https://github.com/0xbow-io/anon-rpc-rs.git" }
  s.platform = :ios, "15.0"
  s.swift_version = "6.0"
  s.source_files = "Sources/AnonRpc/**/*.swift"
  s.vendored_frameworks = "Artifacts/AnonRpcC.xcframework"
end
