@_spi(AnonRpcWire) import AnonRpc
import Foundation

/// The React Native module's calls, over the AnonRpc Swift SDK and its wire
/// codec. Workers and calls are numbered by JavaScript; bytes cross as base64.
@objc(AnonRpcBridge)
public final class AnonRpcBridge: NSObject, @unchecked Sendable {
    public typealias Resolve = (Any?) -> Void
    /// Rejects with a code: the error's code, or the worker's own code.
    public typealias Reject = (String, String) -> Void

    /// Emits a provider request to JavaScript.
    @objc public var emitProviderRequest: ((NSDictionary) -> Void)?

    private let lock = NSLock()
    private var workers: [Int: AnonRpcWorker] = [:]
    private var pools: [Int: WorkerPool] = [:]
    private var calls: [Int: Task<Void, Never>] = [:]
    /// Provider requests awaiting JavaScript, with the worker each belongs to.
    private var providerRequests: [Int: (workerId: Int, continuation: CheckedContinuation<Data, any Error>)] = [:]
    private var nextRequest = 1

    private func locked<T>(_ body: () -> T) -> T {
        lock.lock()
        defer { lock.unlock() }
        return body()
    }

    private func worker(_ id: Int) throws -> AnonRpcWorker {
        guard let worker = locked({ workers[id] }) else {
            throw AnonRpcError(code: .closed, message: "no such worker")
        }
        return worker
    }

    private static func fail(_ error: any Error, _ reject: Reject) {
        if let error = error as? AnonRpcError {
            reject(error.workerCode ?? error.code.rawValue, error.message)
        } else if error is CancellationError {
            reject(ErrorCode.cancelled.rawValue, "operation cancelled")
        } else {
            reject(ErrorCode.internalError.rawValue, "\(error)")
        }
    }

    /// `error` as `Failure` JSON, which a synchronous call returns.
    private static func failure(_ error: any Error) -> String {
        let failure = if let error = error as? AnonRpcError {
            Failure(code: error.code.rawValue, message: error.message, workerCode: error.workerCode)
        } else {
            Failure(code: ErrorCode.internalError.rawValue, message: "\(error)")
        }
        return String(decoding: (try? failure.wire()) ?? Data(), as: UTF8.self)
    }

    /// Register the worker `make` returns as `id`: `nil`, or its failure.
    private func create(_ id: Int, _ make: () throws -> AnonRpcWorker) -> String? {
        do {
            let worker = try make()
            locked { workers[id] = worker }
            return nil
        } catch {
            return Self.failure(error)
        }
    }

    /// Run `body` as the call numbered `callId`, which `cancel` cancels.
    private func call(_ callId: Int, _ resolve: @escaping Resolve, _ reject: @escaping Reject,
                      _ body: @escaping @Sendable () async throws -> Any?) {
        let task = Task {
            do {
                let result = try await body()
                resolve(result)
            } catch {
                Self.fail(error, reject)
            }
            _ = self.locked { self.calls.removeValue(forKey: callId) }
        }
        locked { calls[callId] = task }
    }

    @objc public func createTor(_ id: Int, initJson: String) -> String? {
        create(id) { try .tor(wire: TorInit(wire: Data(initJson.utf8))) }
    }

    @objc public func createFromAddress(_ id: Int, initJson: String) -> String? {
        create(id) {
            try AnonRpcWorker(
                wire: SpecifierInit(wire: Data(initJson.utf8)),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
        }
    }

    @objc public func createFromBundle(_ id: Int, bundleBase64: String, settingsJson: String) -> String? {
        create(id) {
            try AnonRpcWorker(
                wire: WorkerSettings(wire: Data(settingsJson.utf8)), bundle: try Self.bundle(bundleBase64))
        }
    }

    @objc public func createReplacing(_ id: Int, initJson: String, bundleBase64: String?) -> String? {
        create(id) {
            try AnonRpcWorker.replacing(
                wire: ReplacingInit(wire: Data(initJson.utf8)), bundle: try Self.bundle(bundleBase64),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
        }
    }

    @objc public func createPool(_ id: Int, initJson: String, bundleBase64: String?) -> String? {
        do {
            let pool = try WorkerPool(
                wire: PoolInit(wire: Data(initJson.utf8)), bundle: try Self.bundle(bundleBase64),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
            locked { pools[id] = pool }
            return nil
        } catch {
            return Self.failure(error)
        }
    }

    @objc public func poolGroup(_ poolId: Int, workerId: Int, groupJson: String) -> String? {
        create(workerId) {
            guard let pool = locked({ pools[poolId] }) else {
                throw AnonRpcError(code: .closed, message: "no such pool")
            }
            return try pool.group(wire: PoolGroup(wire: Data(groupJson.utf8)))
        }
    }

    @objc public func closePool(_ id: Int) -> String? {
        locked { pools.removeValue(forKey: id) }?.close()
        failProviderRequests(of: id)
        return nil
    }

    @objc public func ready(_ id: Int, resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            call(-id, resolve, reject) {
                try await worker.ready()
                return nil
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    @objc public func fetch(_ id: Int, callId: Int, headJson: String, bodyBase64: String?,
                            resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            let head = try RequestHead(wire: Data(headJson.utf8))
            guard let url = URL(string: head.url) else {
                throw AnonRpcError(code: .unsupported, message: "invalid request URL")
            }
            let body = try bodyBase64.map { encoded in
                guard let data = Data(base64Encoded: encoded) else {
                    throw AnonRpcError(code: .unsupported, message: "the request body is not base64")
                }
                return AnonRpcRequest.Body.bytes(data)
            }
            let request = AnonRpcRequest(
                url: url, method: head.method ?? "GET", headers: head.headers ?? [], body: body)
            call(callId, resolve, reject) {
                let (data, response) = try await worker.data(for: request, redirect: head.redirect ?? .follow)
                let buffered = BufferedResponse(
                    status: UInt16(response.statusCode), headers: response.headerFieldList,
                    url: response.url?.absoluteString, body: data.base64EncodedString())
                return String(decoding: try buffered.wire(), as: UTF8.self)
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    @objc public func acceptLog(_ id: Int, callId: Int, resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            call(callId, resolve, reject) {
                String(decoding: try await worker.acceptLog().wire(), as: UTF8.self)
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    @objc public func cancel(_ callId: Int) {
        locked { calls[callId] }?.cancel()
    }

    @objc public func close(_ id: Int) -> String? {
        locked { workers[id] }?.close()
        failProviderRequests(of: id)
        return nil
    }

    /// Fail the provider requests of the worker or pool `id`.
    private func failProviderRequests(of id: Int) {
        let pending = locked {
            let pending = providerRequests.filter { $0.value.workerId == id }
            pending.keys.forEach { providerRequests.removeValue(forKey: $0) }
            return pending.values.map(\.continuation)
        }
        pending.forEach { $0.resume(throwing: AnonRpcError(code: .closed, message: "worker closed")) }
    }

    /// Ask JavaScript, and wait for `respondProvider`.
    fileprivate func request(workerId: Int, method: String, params: Data) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            let requestId = locked {
                defer { nextRequest += 1 }
                providerRequests[nextRequest] = (workerId, continuation)
                return nextRequest
            }
            emitProviderRequest?([
                "workerId": workerId, "requestId": requestId, "method": method,
                "params": String(decoding: params, as: UTF8.self),
            ])
        }
    }

    @objc public func respondProvider(_ workerId: Int, requestId: Int, responseJson: String) {
        guard let continuation = locked({ providerRequests.removeValue(forKey: requestId)?.continuation }) else { return }
        switch try? ProviderResponse(wire: Data(responseJson.utf8)) {
        case .result(let result):
            if let data = try? JSONSerialization.data(withJSONObject: result, options: .fragmentsAllowed) {
                continuation.resume(returning: data)
            } else {
                continuation.resume(throwing: AnonRpcError(code: .networkError, message: "invalid provider result"))
            }
        case .error(let message):
            continuation.resume(throwing: AnonRpcError(code: .networkError, message: message))
        case nil:
            continuation.resume(throwing: AnonRpcError(code: .networkError, message: "invalid provider response"))
        }
    }

    /// Bundle bytes from base64; empty for none.
    private static func bundle(_ base64: String?) throws -> Data {
        guard let base64 else { return Data() }
        guard let bundle = Data(base64Encoded: base64) else {
            throw AnonRpcError(code: .unsupported, message: "the bundle is not base64")
        }
        return bundle
    }
}

/// Reads the specifier through the JavaScript provider of the worker.
private struct JavaScriptProvider: RpcProvider, @unchecked Sendable {
    weak var bridge: AnonRpcBridge?
    let workerId: Int

    func request(method: String, params: Data) async throws -> Data {
        guard let bridge else { throw AnonRpcError(code: .closed, message: "the module is gone") }
        return try await bridge.request(workerId: workerId, method: method, params: params)
    }
}
