package anonrpc.reactnative

import android.util.Base64
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import anonrpc.AnonRpcException
import anonrpc.AnonRpcRequest
import anonrpc.AnonRpcWireApi
import anonrpc.AnonRpcWorker
import anonrpc.BufferedResponse
import anonrpc.Failure
import anonrpc.PoolGroup
import anonrpc.PoolInit
import anonrpc.ProviderResponse
import anonrpc.Redirect
import anonrpc.ReplacingInit
import anonrpc.RequestHead
import anonrpc.RpcProvider
import anonrpc.SpecifierInit
import anonrpc.TorConfig
import anonrpc.TorInit
import anonrpc.WorkerPool
import anonrpc.WorkerSettings
import anonrpc.WorkerStart
import anonrpc.fromWire
import anonrpc.generated.ErrorCode
import anonrpc.toWire
import java.io.File
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONArray

/**
 * The React Native module's calls, over the anon-rpc Kotlin SDK and its wire
 * codec. Workers and calls are numbered by JavaScript; bytes cross as base64.
 */
@OptIn(AnonRpcWireApi::class)
class AnonRpcModule(private val context: ReactApplicationContext) : NativeAnonRpcSpec(context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val workers = ConcurrentHashMap<Int, AnonRpcWorker>()
    private val pools = ConcurrentHashMap<Int, WorkerPool>()
    private val calls = ConcurrentHashMap<Int, Job>()
    /** Provider requests awaiting JavaScript, with the worker each belongs to. */
    private val providerRequests = ConcurrentHashMap<Int, Pair<Int, CompletableFuture<String>>>()
    private val nextRequest = AtomicInteger(1)

    override fun getName() = NAME

    override fun invalidate() {
        scope.cancel()
        workers.values.forEach { it.close() }
        pools.values.forEach { it.close() }
        super.invalidate()
    }

    /**
     * Send a provider request to JavaScript: through the codegen event
     * emitter, which only the New Architecture wires up, or else as a device
     * event, as the legacy architecture delivers module events.
     */
    private fun emitProviderRequest(request: WritableMap) {
        if (mEventEmitterCallback != null) {
            emitOnProviderRequest(request)
        } else {
            context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit("onProviderRequest", request)
        }
    }

    private fun Promise.fail(error: Throwable) = when (error) {
        is AnonRpcException -> reject(error.workerCode ?: error.code.code, error.message, error)
        is CancellationException -> reject(ErrorCode.CANCELLED.code, "operation cancelled", error)
        else -> reject(ErrorCode.INTERNAL_ERROR.code, error.toString(), error)
    }

    /** [error] as `Failure` JSON, which a synchronous call returns. */
    private fun failure(error: Throwable): String {
        val failure = when (error) {
            is AnonRpcException -> Failure(error.code.code, error.message.orEmpty(), error.workerCode)
            else -> Failure(ErrorCode.INTERNAL_ERROR.code, error.toString())
        }
        return String(failure.toWire())
    }

    /** Register the worker [make] returns as [id]: `null`, or its failure. */
    private fun create(id: Double, make: () -> AnonRpcWorker): String? =
        try {
            workers[id.toInt()] = make()
            null
        } catch (error: Throwable) {
            failure(error)
        }

    private fun worker(id: Double): AnonRpcWorker =
        workers[id.toInt()] ?: throw AnonRpcException(ErrorCode.CLOSED, "no such worker")

    /** Run [body] as the call numbered [callId], which `cancel` cancels. */
    private fun call(callId: Int, promise: Promise, body: suspend () -> Any?) {
        val job = scope.launch {
            try {
                promise.resolve(body())
            } catch (error: Throwable) {
                promise.fail(error)
            } finally {
                calls.remove(callId)
            }
        }
        calls[callId] = job
    }

    private fun storage(dir: String?) = dir?.let(::File) ?: File(context.noBackupFilesDir, "anon-rpc/worker-storage")

    /** [start] with this app's directories where it names none. */
    private fun withDefaults(start: WorkerStart): WorkerStart {
        val tor = TorConfig.default(context)
        return start.copy(
            tor = start.tor?.let { it.copy(stateDir = it.stateDir ?: tor.stateDir.path, cacheDir = it.cacheDir ?: tor.cacheDir.path) },
            specifier = start.specifier?.let { it.copy(storageDir = storage(it.storageDir).path) },
            bundle = start.bundle?.let { it.copy(storageDir = storage(it.storageDir).path) },
        )
    }

    private fun bundle(base64: String?) = base64?.let { Base64.decode(it, Base64.DEFAULT) }

    override fun createTor(workerId: Double, initJson: String): String? =
        create(workerId) {
            val init = TorInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.tor(withDefaults(WorkerStart(tor = init)).tor!!)
        }

    override fun createFromAddress(workerId: Double, initJson: String): String? =
        create(workerId) {
            val init = SpecifierInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.specifier(withDefaults(WorkerStart(specifier = init)).specifier!!, JavaScriptProvider(workerId.toInt()))
        }

    override fun createFromBundle(workerId: Double, bundleBase64: String, settingsJson: String): String? =
        create(workerId) {
            val init = WorkerSettings.fromWire(settingsJson.toByteArray())
            AnonRpcWorker.bundle(withDefaults(WorkerStart(bundle = init)).bundle!!, bundle(bundleBase64)!!)
        }

    override fun createReplacing(workerId: Double, initJson: String, bundleBase64: String?): String? =
        create(workerId) {
            val init = ReplacingInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.replacing(init.copy(start = withDefaults(init.start)), bundle(bundleBase64), JavaScriptProvider(workerId.toInt()))
        }

    override fun createPool(poolId: Double, initJson: String, bundleBase64: String?): String? =
        try {
            val init = PoolInit.fromWire(initJson.toByteArray())
            pools[poolId.toInt()] =
                WorkerPool.fromWire(init.copy(start = withDefaults(init.start)), bundle(bundleBase64), JavaScriptProvider(poolId.toInt()))
            null
        } catch (error: Throwable) {
            failure(error)
        }

    override fun poolGroup(poolId: Double, workerId: Double, groupJson: String): String? =
        create(workerId) {
            val pool = pools[poolId.toInt()] ?: throw AnonRpcException(ErrorCode.CLOSED, "no such pool")
            pool.group(PoolGroup.fromWire(groupJson.toByteArray()))
        }

    override fun closePool(poolId: Double): String? {
        pools.remove(poolId.toInt())?.close()
        failProviderRequests(poolId.toInt())
        return null
    }

    override fun ready(workerId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(-workerId.toInt(), promise) { worker.ready().let { null } }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun fetch(workerId: Double, callId: Double, headJson: String, bodyBase64: String?, promise: Promise) {
        try {
            val worker = worker(workerId)
            val head = RequestHead.fromWire(headJson.toByteArray())
            val request = AnonRpcRequest(
                url = head.url,
                method = head.method ?: "GET",
                headers = head.headers.orEmpty(),
                body = bodyBase64?.let { AnonRpcRequest.Body.Bytes(Base64.decode(it, Base64.DEFAULT)) },
            )
            call(callId.toInt(), promise) {
                worker.fetch(request, head.redirect ?: Redirect.FOLLOW).use { response ->
                    BufferedResponse(
                        status = response.status,
                        headers = response.headers,
                        url = response.url,
                        body = Base64.encodeToString(response.body.bytes(), Base64.NO_WRAP),
                    ).toWire().decodeToString()
                }
            }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun acceptLog(workerId: Double, callId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(callId.toInt(), promise) { worker.acceptLog().toWire().decodeToString() }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun cancel(callId: Double) {
        calls[callId.toInt()]?.cancel()
    }

    override fun close(workerId: Double): String? {
        workers[workerId.toInt()]?.close()
        failProviderRequests(workerId.toInt())
        return null
    }

    /** Fail the provider requests of the worker or pool [id]. */
    private fun failProviderRequests(id: Int) {
        providerRequests.entries.removeIf { (_, request) ->
            val (owner, response) = request
            if (owner == id) response.complete(ProviderResponse.Error("worker closed").toWire().decodeToString())
            owner == id
        }
    }

    override fun respondProvider(workerId: Double, requestId: Double, responseJson: String) {
        providerRequests.remove(requestId.toInt())?.second?.complete(responseJson)
    }

    /** Reads the specifier through the JavaScript provider of a worker, blocking a native thread. */
    private inner class JavaScriptProvider(private val workerId: Int) : RpcProvider {
        override fun request(method: String, params: String): String {
            val requestId = nextRequest.getAndIncrement()
            val response = CompletableFuture<String>()
            providerRequests[requestId] = workerId to response
            emitProviderRequest(
                Arguments.createMap().apply {
                    putInt("workerId", workerId)
                    putInt("requestId", requestId)
                    putString("method", method)
                    putString("params", params)
                },
            )
            val answer = try {
                ProviderResponse.fromWire(response.get().toByteArray())
            } catch (error: ExecutionException) {
                throw AnonRpcException(ErrorCode.NETWORK_ERROR, error.cause?.message ?: "no result")
            } catch (_: AnonRpcException) {
                throw AnonRpcException(ErrorCode.NETWORK_ERROR, "invalid provider response")
            }
            return when (answer) {
                is ProviderResponse.Result -> JSONArray().put(answer.value).toString().removePrefix("[").removeSuffix("]")
                is ProviderResponse.Error -> throw AnonRpcException(ErrorCode.NETWORK_ERROR, answer.value)
            }
        }
    }

    companion object {
        const val NAME = "AnonRpc"
    }
}
