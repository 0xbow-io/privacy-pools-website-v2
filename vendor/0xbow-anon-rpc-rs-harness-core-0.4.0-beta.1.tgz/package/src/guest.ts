// What the anon-rpc crate's sandbox prelude runs of this package: plain values
// (§9.4) across the guest's JSON bridge, a failed call's details (§8), and
// the cancel reasons KPS carries (§12), so
// the native guest and every JavaScript harness share one implementation.
// guest.mjs bundles it, and `cargo xtask generate` writes the bundle to
// crates/anon-rpc/src/host/sandbox/prelude/05-plain.g.js.

export { decodePlain, encodePlain } from "./plain-value.js";
export { detailsOf } from "./plain-values.js";
export { wireReason } from "./abort.js";
