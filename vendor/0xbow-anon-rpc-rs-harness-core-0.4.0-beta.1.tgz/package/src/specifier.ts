// §4 — Worker identity and integrity.
//
// Reads an onchain IWorkerSpecifier (workerHash() / workerResolvers()) through
// a pre-existing RPC provider, fetches the bundle bytes from a resolver, and
// verifies keccak256(bytes) == workerHash. The hash is trust; the URL is not.

import { keccak_256 } from "@noble/hashes/sha3.js";
import type { RpcProvider } from "./spec-types.js";
import { RpcError } from "./errors.js";
import { toHex } from "./hex.js";

/**
 * A §4.1 resolver entry kind that needs a transport this module does not have
 * — `kps:`, which needs KPS (§4.2). A harness that has the transport passes
 * one; one that does not leaves the kind unrecognized, which §4.1 says to
 * ignore, so a specifier listing both kinds still boots from the other.
 */
export type ResolverKind = {
  matches(url: string): boolean;
  fetch(url: string, maxBytes: number, signal?: AbortSignal): Promise<Uint8Array>;
};

const SEL_WORKER_HASH = selector("workerHash()");
const SEL_WORKER_RESOLVERS = selector("workerResolvers()");

function selector(sig: string): string {
  return "0x" + toHex(keccak_256(new TextEncoder().encode(sig))).slice(0, 8);
}

export { toHex };

function hexToBytes(hex: string): Uint8Array {
  const h = hex.startsWith("0x") ? hex.slice(2) : hex;
  const out = new Uint8Array(h.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(h.slice(i * 2, i * 2 + 2), 16);
  return out;
}

export type Specifier = { workerHash: string; resolvers: string[] };

/**
 * The bootstrap provider answered for a different chain than the one the
 * specifier is published on. The specifier read is not attempted: at the same
 * address on another chain there may be no contract, or a different one
 * pinning different code.
 */
export class SpecifierChainError extends RpcError {
  readonly expectedChainId: number;
  readonly actualChainId: string;
  /** `actual` is the answered chain id, or, with `notAChainId`, the answer that was not one. */
  constructor(expected: number, actual: string, notAChainId = false) {
    // Code `protocol-error`, as the native packages fail `ready` for the same refusal.
    super({
      name: "SpecifierChainError",
      code: "protocol-error",
      message: notAChainId
        ? `the bootstrap RPC answered eth_chainId with ${actual}, which is not a chain id`
        : `the bootstrap RPC is on chain ${actual}, but the specifier is published on chain ${expected}`,
    });
    this.expectedChainId = expected;
    this.actualChainId = actual;
  }
}

/**
 * The specifier pins a bundle other than the one the host requires
 * (`WorkerInit.expectedWorkerHash`). No bundle is obtained.
 */
export class WorkerHashMismatchError extends RpcError {
  readonly expectedWorkerHash: string;
  readonly actualWorkerHash: string;
  constructor(expected: string, actual: string) {
    super({
      name: "WorkerHashMismatchError",
      code: "protocol-error",
      message: `the specifier pins bundle ${actual}, but this host expects ${expected}`,
    });
    this.expectedWorkerHash = expected;
    this.actualWorkerHash = actual;
  }
}

/** `expectedWorkerHash` in the form `workerHash` takes, or an unsupported TypeError. */
export function normalizeWorkerHash(hash: unknown): string {
  if (typeof hash !== "string" || !/^0x[0-9a-fA-F]{64}$/.test(hash)) {
    throw Object.assign(new TypeError(`expectedWorkerHash must be 0x and 64 hex digits, got ${String(hash)}`), {
      code: "unsupported",
    });
  }
  return hash.toLowerCase();
}

/** A specifier address, `0x` and 40 hex digits, or an unsupported TypeError, before any provider request. */
export function checkAddress(address: unknown): asserts address is string {
  if (typeof address !== "string" || !/^0x[0-9a-fA-F]{40}$/.test(address)) {
    throw Object.assign(new TypeError(`an address is 0x followed by 40 hexadecimal digits, got ${String(address)}`), {
      code: "unsupported",
    });
  }
}

/** `specifierChainId` as a positive safe integer, or an unsupported TypeError. */
export function checkChainId(chainId: unknown): asserts chainId is number {
  if (!Number.isSafeInteger(chainId) || (chainId as number) <= 0) {
    // Still a TypeError, with the code the native packages report.
    throw Object.assign(new TypeError(`specifierChainId must be a positive integer, got ${String(chainId)}`), {
      code: "unsupported",
    });
  }
}

/** Fail unless `provider` answers `eth_chainId` with `chainId`. */
export async function checkSpecifierChain(
  provider: RpcProvider,
  chainId: number,
  signal?: AbortSignal,
): Promise<void> {
  checkChainId(chainId);
  signal?.throwIfAborted();
  const res = await provider.request({ method: "eth_chainId", params: [] });
  signal?.throwIfAborted();
  // A JSON-RPC quantity: 0x and hex digits without leading zeros, as the
  // native packages accept. Anything else is not an answer to compare.
  if (typeof res !== "string" || !/^0x(0|[1-9a-fA-F][0-9a-fA-F]*)$/.test(res)) {
    throw new SpecifierChainError(chainId, JSON.stringify(res) ?? String(res), true);
  }
  const actual = BigInt(res);
  if (actual !== BigInt(chainId)) throw new SpecifierChainError(chainId, actual.toString());
}

/**
 * The two §4 reads. A provider call cannot be cancelled (EIP-1193 has no
 * signal), so an abort is checked between them: a closed worker issues no
 * further read, whatever the first one eventually returns.
 */
export async function readSpecifier(
  provider: RpcProvider,
  address: string,
  signal?: AbortSignal,
): Promise<Specifier> {
  checkAddress(address);
  signal?.throwIfAborted();
  const hashRet = await ethCall(provider, address, SEL_WORKER_HASH);
  signal?.throwIfAborted();
  const resolversRet = await ethCall(provider, address, SEL_WORKER_RESOLVERS);
  signal?.throwIfAborted();
  return {
    workerHash: "0x" + decodeBytes32(hashRet),
    resolvers: decodeStringArray(resolversRet),
  };
}

async function ethCall(provider: RpcProvider, to: string, data: string): Promise<Uint8Array> {
  const res = await provider.request({
    method: "eth_call",
    params: [{ to, data }, "latest"],
  });
  // As the native packages require: anything but 0x and whole bytes of hex
  // would decode to zeros or lose its last nibble.
  if (typeof res !== "string" || !/^0x([0-9a-fA-F]{2})*$/.test(res)) {
    throw abiError("eth_call did not return hex data");
  }
  return hexToBytes(res);
}

// §4.2: a harness SHOULD cap the accepted body size. A resolver is untrusted
// input; without a cap it can make the harness buffer arbitrarily many bytes
// before the hash check ever runs.
export const MAX_BUNDLE_BYTES = 64 * 1024 * 1024;

// Read a response body, streaming and counting: past the cap the read is
// cancelled without buffering the excess.
async function readBodyCapped(resp: Response, cap: number, signal?: AbortSignal): Promise<Uint8Array> {
  const overflow = () => new Error(`body exceeds the ${cap}-byte bundle cap`);
  if (resp.body) return readCapped(resp.body, cap, overflow, signal);
  const buf = new Uint8Array(await resp.arrayBuffer());
  signal?.throwIfAborted();
  if (buf.byteLength > cap) throw overflow();
  return buf;
}

/**
 * `stream` read whole, or `overflow()` once it passes `cap` bytes, cancelling
 * it without buffering the excess. An abort cancels it too, rather than
 * trusting whatever produced the stream to have wired its signal through.
 */
export async function readCapped(
  stream: ReadableStream<Uint8Array>,
  cap: number,
  overflow: () => Error,
  signal?: AbortSignal,
): Promise<Uint8Array> {
  const reader = stream.getReader();
  const onAbort = () => void reader.cancel(signal?.reason).catch(() => {});
  signal?.addEventListener("abort", onAbort, { once: true });
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      signal?.throwIfAborted();
      const { value, done } = await reader.read();
      signal?.throwIfAborted();
      if (done) break;
      total += value.byteLength;
      if (total > cap) {
        await reader.cancel().catch(() => {});
        throw overflow();
      }
      chunks.push(value);
    }
  } finally {
    signal?.removeEventListener("abort", onAbort);
  }
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) {
    out.set(c, off);
    off += c.byteLength;
  }
  return out;
}

/**
 * Fetch bundle bytes from the first working resolver and verify the hash (§4).
 *
 * `signal` ends the whole search: an abort fails it with the signal's reason,
 * and a resolver that failed because of the abort is not a reason to try the
 * next one.
 */
export async function fetchAndVerifyBundle(
  spec: Specifier,
  maxBytes = MAX_BUNDLE_BYTES,
  kinds: ResolverKind[] = [],
  signal?: AbortSignal,
): Promise<Uint8Array> {
  const errors: string[] = [];
  for (const url of spec.resolvers) {
    signal?.throwIfAborted();
    let bytes: Uint8Array;
    try {
      // §4.1 entry kinds. `http:` is accepted alongside `https:` as a
      // development affordance (local resolvers in tests and demos), and
      // `blob:` because §4.1 lists it: bytes this program already holds,
      // for a specifier the host built locally. Fetched here, in the HOST
      // context that minted it — the worker never sees the URL, and would
      // not be able to resolve it if it did.
      if (/^(https?|blob):/.test(url)) {
        const resp = await fetch(url, { signal });
        signal?.throwIfAborted();
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        bytes = await readBodyCapped(resp, maxBytes, signal);
      } else {
        const kind = kinds.find((k) => k.matches(url));
        if (!kind) {
          // §4.1: unrecognized entry kinds MUST be ignored — they never fail
          // the boot; recorded only for the all-resolvers-failed diagnostic.
          errors.push(`${url}: unrecognized resolver kind (ignored)`);
          continue;
        }
        bytes = await kind.fetch(url, maxBytes, signal);
      }
    } catch (e) {
      signal?.throwIfAborted();
      errors.push(`${url}: ${(e as Error).message}`);
      continue;
    }
    signal?.throwIfAborted();
    const got = "0x" + toHex(keccak_256(bytes));
    if (got !== spec.workerHash) {
      // A resolver served bytes that don't match the pinned hash: reject and
      // try the next one. Any bytes matching the hash are acceptable (§4).
      errors.push(`${url}: hash mismatch (got ${got}, want ${spec.workerHash})`);
      continue;
    }
    return bytes;
  }
  throw new RpcError({
    name: "Error",
    message: `no resolver yielded bytes matching workerHash: ${errors.join("; ")}`,
    code: "network-error",
  });
}

/* --- minimal ABI return decoding (bytes32, string[]) --- */

function abiError(message: string): RpcError {
  return new RpcError({ name: "Error", message: `specifier ABI decode: ${message}`, code: "protocol-error" });
}

function decodeBytes32(ret: Uint8Array): string {
  if (ret.length < 32) throw abiError("short bytes32 return");
  return toHex(ret.slice(0, 32));
}

// ABI return data comes from an untrusted RPC endpoint; every offset and
// length is bounds-checked so malicious data throws instead of OOM/hanging.
function word(ret: Uint8Array, at: number): number {
  if (at < 0 || at + 32 > ret.length) throw abiError("word out of bounds");
  let n = 0;
  for (let i = at; i < at + 32; i++) {
    n = n * 256 + ret[i];
    if (n > Number.MAX_SAFE_INTEGER) throw abiError("word too large");
  }
  return n;
}

function decodeStringArray(ret: Uint8Array): string[] {
  // Return is a single dynamic value: head word is the offset to the array.
  const base = word(ret, 0);
  const len = word(ret, base);
  if (base + 32 + len * 32 > ret.length) throw abiError("array length out of bounds");
  const out: string[] = [];
  const dec = new TextDecoder();
  for (let i = 0; i < len; i++) {
    const elemOff = base + 32 + word(ret, base + 32 + i * 32);
    const strLen = word(ret, elemOff);
    if (elemOff + 32 + strLen > ret.length) throw abiError("string out of bounds");
    out.push(dec.decode(ret.slice(elemOff + 32, elemOff + 32 + strLen)));
  }
  return out;
}
