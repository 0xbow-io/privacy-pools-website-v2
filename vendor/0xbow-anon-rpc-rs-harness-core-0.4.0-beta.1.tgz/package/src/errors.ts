// §12 — errors that cross a harness boundary.
//
// `name` and `code` cross intact, because host logic may branch on `code`;
// `message` crosses for humans and must never be branched on. A worker's
// failed call also carries its error's details (§8), such as tor-js's
// `torKind`, which host logic may branch on as on `code`.

import { decodePlain, encodePlain, type WirePlain } from "./plain-value.js";
import { applyDetails, detailsOf } from "./plain-values.js";

export type SerializedError = { name: string; message: string; code?: string; details?: WirePlain };

export class RpcError extends Error {
  code?: string;
  constructor(e: SerializedError) {
    super(e.message);
    this.name = e.name;
    this.code = e.code;
    applyDetails(this, decodeDetails(e.details));
  }
}

/** The serialized `details`, decoded; undefined when absent or malformed. */
export function decodeDetails(details: WirePlain | undefined): unknown {
  try {
    return details === undefined ? undefined : decodePlain(details);
  } catch {
    return undefined;
  }
}

/**
 * The one error-marshalling implementation; pair with `new RpcError(...)` to
 * deserialize. `withDetails` carries the error's details too, for a worker's
 * failed call on its way to the host (§8); an error on its way into a worker
 * carries none, so nothing of the host's leaks in.
 */
export function serializeError(err: unknown, withDetails = false): SerializedError {
  const out: SerializedError =
    err instanceof Error
      ? (() => {
          const code = (err as { code?: unknown }).code;
          return { name: err.name, message: err.message, ...(typeof code === "string" ? { code } : {}) };
        })()
      : { name: "Error", message: String(err) };
  const details = withDetails ? detailsOf(err) : undefined;
  if (details) out.details = encodePlain(details);
  return out;
}
