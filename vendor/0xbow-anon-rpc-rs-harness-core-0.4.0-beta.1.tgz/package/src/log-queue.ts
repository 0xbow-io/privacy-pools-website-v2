// §13.1 log retention: the buffer `acceptLog()` pulls from.
//
// Deliberately NOT CallQueue. That queue implements §8's call discipline,
// whose whole point is that nothing is ever dropped — a dropped call is a
// caller waiting forever. This one is the opposite by design: logs are
// best-effort diagnostics, a host may never collect them at all, and a buffer
// that grew without bound to hold them would turn a chatty worker into a
// memory leak. So it has a cap, and the cap means loss.
//
// Old entries go first. A worker that has produced 10,000 lines since anyone
// looked is nearly always more interesting at the end than at the start, and
// the start is what a host that was reading all along has already seen.

import { abortReason } from "./plain-values.js";

export type Waiter<T> = { resolve: (t: T) => void; reject: (e: unknown) => void };

export class LogQueue<T> {
  #items: T[] = [];
  #waiters: Waiter<T>[] = [];
  #closed?: { err: unknown };
  readonly #max: number;

  /**
   * `max` is how many undelivered entries are retained (§13.1 permits a
   * bound, and requires one to be the only place entries are lost). The
   * default is sized for a worker that logs its way through a slow start (a
   * Tor bootstrap is hundreds of lines), while a host that never calls
   * acceptLog holds a bounded amount of garbage.
   */
  constructor(max = 1000) {
    this.#max = max;
  }

  /** How many entries have been dropped for want of room. */
  dropped = 0;

  /**
   * Resolve with the next entry, waiting if there is none.
   *
   * §13.1: an abort withdraws the caller without consuming an entry, and a
   * closed queue still yields whatever it retained before rejecting — the
   * entries explaining a failure are the ones most worth reading.
   */
  take(signal?: AbortSignal): Promise<T> {
    if (signal?.aborted) return Promise.reject(abortReason(signal));
    const next = this.#items.shift();
    if (next !== undefined) return Promise.resolve(next);
    if (this.#closed) return Promise.reject(this.#closed.err);
    return new Promise<T>((resolve, reject) => {
      const waiter: Waiter<T> = {
        resolve: (item) => {
          signal?.removeEventListener("abort", onAbort);
          resolve(item);
        },
        reject: (e) => {
          signal?.removeEventListener("abort", onAbort);
          reject(e);
        },
      };
      const onAbort = () => {
        const i = this.#waiters.indexOf(waiter);
        if (i >= 0) this.#waiters.splice(i, 1);
        reject(abortReason(signal!));
      };
      signal?.addEventListener("abort", onAbort, { once: true });
      this.#waiters.push(waiter);
    });
  }

  /** Deliver to the oldest waiter, else retain — dropping the oldest if full. */
  push(item: T): void {
    if (this.#closed) return;
    const waiter = this.#waiters.shift();
    if (waiter) return waiter.resolve(item);
    this.#items.push(item);
    while (this.#items.length > this.#max) {
      this.#items.shift();
      this.dropped++;
    }
  }

  /**
   * Stop accepting entries; retained ones stay readable, and `take()` rejects
   * once they run out.
   *
   * Pending waiters reject immediately: there is nothing left to wait for, and
   * a host looping on `acceptLog()` would otherwise hang on a dead worker.
   */
  close(err: unknown): void {
    if (this.#closed) return;
    this.#closed = { err };
    for (const w of this.#waiters.splice(0)) w.reject(err);
  }

  /** Retained, undelivered entries. */
  get size(): number {
    return this.#items.length;
  }
}

// §14: log arguments may carry sensitive bytes, so bytes are described rather
// than printed, at any depth. Structured cloning keeps shared and cyclic
// references; `copies` keeps them too, so each object is copied once.
export function renderLogArg(a: unknown, copies = new Map<object, unknown>()): unknown {
  if (a instanceof Uint8Array) return `<${a.byteLength} bytes>`;
  if (typeof a !== "object" || a === null) return a;
  if (copies.has(a)) return copies.get(a);
  const out = (Array.isArray(a) ? [] : {}) as Record<string, unknown>;
  copies.set(a, out);
  // Defined, not assigned: a cloned own "__proto__" key must stay a key.
  for (const [k, v] of Object.entries(a)) {
    Object.defineProperty(out, k, { value: renderLogArg(v, copies), enumerable: true, writable: true, configurable: true });
  }
  return out;
}
