// Aborts and cancels as every harness reports them.

import { abortReason } from "./plain-values.js";

export { abortReason };

/**
 * `value`, or a rejection with `signal`'s reason as soon as it aborts, as
 * fetch rejects. Whatever `value` does after the abort is ignored: work that
 * ignores its signal and completes late cannot resume a caller that has
 * already been told to stop.
 */
export function untilAborted<T>(value: Promise<T>, signal?: AbortSignal | null): Promise<T> {
  if (!signal) return value;
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(abortReason(signal));
    signal.addEventListener("abort", onAbort);
    // Settling after an abort is a no-op, and handles a rejection nothing else awaits.
    value.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
    if (signal.aborted) onAbort();
  });
}

/**
 * A cancel or abort reason, reduced to what any KPS or §12 consumer reads and
 * what structured cloning always accepts: a string `code` and `message` of an
 * object, and any other value but `undefined` as the message.
 */
export function wireReason(r: unknown): { code?: string; message?: string } | undefined {
  if (typeof r !== "object" || r === null) return r === undefined ? undefined : { message: String(r) };
  const { code, message } = r as { code?: unknown; message?: unknown };
  return {
    ...(typeof code === "string" ? { code } : {}),
    ...(typeof message === "string" ? { message } : {}),
  };
}
