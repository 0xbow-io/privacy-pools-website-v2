// The platform-neutral parts of an anon-rpc harness: everything a harness
// needs that is about the specification rather than about where it runs.
export { abortReason, untilAborted, wireReason } from "./abort.js";
export { CallQueue } from "./call-queue.js";
export { LogQueue, renderLogArg } from "./log-queue.js";
export {
  readSpecifier,
  fetchAndVerifyBundle,
  checkAddress,
  checkChainId,
  checkSpecifierChain,
  normalizeWorkerHash,
  toHex,
  MAX_BUNDLE_BYTES,
  readCapped,
  SpecifierChainError,
  WorkerHashMismatchError,
  type Specifier,
  type ResolverKind,
} from "./specifier.js";
export { encodePlain, decodePlain, type WirePlain } from "./plain-value.js";
export {
  applyDetails,
  copyPlainValue,
  copyForwardedEntries,
  detailsOf,
  MODELED_INIT_KEYS,
  RESERVED_DETAIL_KEYS,
} from "./plain-values.js";
export { RpcError, decodeDetails, serializeError, type SerializedError } from "./errors.js";
export { TOR_EXIT_FAILURE_KINDS, isTorExitFailure } from "./tor-kinds.g.js";
