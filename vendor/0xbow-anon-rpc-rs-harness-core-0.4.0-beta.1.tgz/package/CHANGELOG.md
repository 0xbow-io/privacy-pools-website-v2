# @0xbow/anon-rpc-rs-harness-core changelog

Changes to this package by version. Specification changes are in the
[specification changelog](../../CHANGELOG.md). Every first-party package
shares the workspace version.

## 0.4.0-beta.1 (2026-10-30)

- **Added: a failed call's details** (spec §8): `serializeError` carries
  an error's plain-valued properties, and `RpcError` sets them. The
  anon-rpc crate's sandbox runs this package's plain-value and details
  code.
- **Added: `isTorExitFailure` and `TOR_EXIT_FAILURE_KINDS`**, with
  `RelayTooBusy` among the kinds: an exit that ended the stream as
  hibernating or out of resources, which C tor retries on a new circuit.
- **Added: `abortReason`, `untilAborted` and `wireReason`**, the abort
  rejections and cancel reasons every harness reports, and `checkAddress`.
  `LogQueue` bounds its entries at 1,000 by default.
- **Changed: a specifier read fails with a code**: `unsupported` for a
  malformed address, `protocol-error` for return data that does not
  decode, `network-error` when no resolver yields the bundle.
- **Changed: `SpecifierChainError` and `WorkerHashMismatchError` extend
  `RpcError`.**
- **Added: `readCapped` and `renderLogArg`**, the capped stream read and
  the byte-free log rendering the browser harnesses share.
- **Fixed: `LogQueue.take` with an aborted signal keeps its entry** (spec
  §13.1). It consumed one.
- **Fixed: an error whose keys cannot be listed still serializes**,
  without details. Serializing it threw.

## 0.4.0-alpha.8 (2026-10-26)

No changes to this package. It is released at the workspace version.

## 0.4.0-alpha.7 (2026-10-26)

Tracks spec 0.4.0. First release: the platform-neutral code the browser
harness and the browser extension harness each carried, now in one place.

- Spec types, `CallQueue`, `LogQueue`, `readSpecifier` /
  `fetchAndVerifyBundle` with the `specifierChainId` and
  `expectedWorkerHash` checks, `copyPlainValue`, `RpcError` /
  `serializeError`.
- `fetchAndVerifyBundle` takes extra `ResolverKind` values, so a harness passes
  the `kps:` kind only where it has KPS.
- `CallQueue.rejectAll` returns the items it dropped, so the caller settles
  them.
- `copyForwardedEntries` (§9.1): one implementation of which init entries
  are forwarded and how they are copied.
- `encodePlain` / `decodePlain`: one JSON encoding of §9.4 plain values,
  with bytes as hex, for the extension's messaging hop.
