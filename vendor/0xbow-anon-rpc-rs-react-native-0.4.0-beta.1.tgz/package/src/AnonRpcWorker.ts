// The browser harness's `AnonRpcWorker` API over the Swift and Kotlin SDKs.

import { NativeEventEmitter, Platform, type EventSubscription } from "react-native";

import native, { type ProviderRequest } from "./NativeAnonRpc";
import {
  NULL_BODY_STATUSES,
  decodeAnonRpcValue,
  decodeBase64,
  decodeBufferedResponse,
  decodeFailure,
  decodeLogEntry,
  encodeBase64,
  encodeProviderResponse,
  encodeBufferedRequest,
  encodeSpecifierInit,
  encodeTorInit,
  encodeWorkerSettings,
  failureError,
  type AnonRpcValue,
  type LogEntry,
  type ProviderResponse,
  type WorkerStart as WireWorkerStart,
} from "./wire.g";
import { abortReason, copyForwardedEntries, type AnonFetch } from "./plain-values";
import { startParts, type BundleInit, type RpcProvider, type TorConfig, type WorkerInit, type WorkerStart } from "./start";

export { RpcError, type AnonRpcValue, type LogArg, type LogEntry, type LogLevel } from "./wire.g";

/**
 * `start` as the native modules take it: its wire form, its bundle as
 * base64, and the provider a specifier start reads through.
 */
export function nativeStart(start: WorkerStart): [WireWorkerStart, string | null, RpcProvider | undefined] {
  const [wire, bundle, provider] = startParts(start);
  return [wire, bundle ? encodeBase64(bundle) : null, provider];
}

/** Throw the failure a synchronous native call returned, if it returned one. */
export function created(failure: string | null): void {
  if (failure !== null) throw failureError(decodeFailure(JSON.parse(failure)));
}

/**
 * The `RpcError` of a native rejection: its code, and the failure's details
 * (§8), which the native module passes as JSON in `userInfo.details`.
 */
export function rpcError(error: unknown): unknown {
  const code = (error as { code?: unknown } | null)?.code;
  if (!(error instanceof Error) || typeof code !== "string") return error;
  return failureError({ code, message: error.message, details: rejectionDetails(error) });
}

/** The details a native rejection carries; none when they are malformed. */
function rejectionDetails(error: Error): AnonRpcValue | undefined {
  const json = (error as { userInfo?: { details?: unknown } | null }).userInfo?.details;
  if (typeof json !== "string") return undefined;
  try {
    return decodeAnonRpcValue(JSON.parse(json));
  } catch {
    return undefined;
  }
}

let nextId = 1;
const providers = new Map<number, RpcProvider>();

/** A new number for a native worker, pool or call, within the Java `int` Android reads it as. */
export function nextNativeId(): number {
  if (nextId > 0x7fffffff) throw new RangeError("this runtime has used every native id");
  return nextId++;
}

/**
 * Create native worker or pool `id` with `make`, serving `provider` to it;
 * the creation's failure is thrown.
 */
export function create(id: number, provider: RpcProvider | undefined, make: (id: number) => string | null): void {
  if (provider) {
    providers.set(id, provider);
    serveProviders();
  }
  try {
    created(make(id));
  } catch (error) {
    forgetProvider(id);
    throw error;
  }
}

/** Stop answering the provider requests of native worker or pool `id`. */
export function forgetProvider(id: number): void {
  providers.delete(id);
}
let subscription: EventSubscription | undefined;

/**
 * Subscribe to the native provider requests. Only the New Architecture
 * gives the module its codegen event emitter; on the legacy architecture
 * the module sends them as device events, which iOS counts the listeners of
 * through the module itself.
 */
function onProviderRequest(listener: (request: ProviderRequest) => void): EventSubscription {
  if (typeof native.onProviderRequest === "function") return native.onProviderRequest(listener);
  type EmitterModule = ConstructorParameters<typeof NativeEventEmitter>[0];
  const emitter = new NativeEventEmitter(Platform.OS === "ios" ? (native as unknown as EmitterModule) : undefined);
  return emitter.addListener("onProviderRequest", (request) => listener(request as ProviderRequest));
}

/** Answer the native provider requests with each worker's JavaScript provider. */
function serveProviders(): void {
  subscription ??= onProviderRequest(async ({ workerId, requestId, method, params }) => {
    let response: ProviderResponse;
    try {
      const provider = providers.get(workerId);
      if (!provider) throw new Error("the worker has no provider");
      response = { result: (await provider.request({ method, params: JSON.parse(params) })) ?? null };
    } catch (error) {
      response = { error: error instanceof Error ? error.message : String(error) };
    }
    native.respondProvider(workerId, requestId, JSON.stringify(encodeProviderResponse(response)));
  });
}

/**
 * The bytes of a request's body, or `null` without one. React Native's
 * `Request` has no `body` stream, and reads every body, an empty one
 * included, through a native `Blob` whose data can be released before the
 * read completes, so string and byte bodies are copied directly.
 */
async function requestBody(
  input: RequestInfo | URL,
  init: RequestInit | undefined,
  request: Request,
): Promise<Uint8Array | null> {
  const body = init?.body;
  if (body == null) return input instanceof Request ? new Uint8Array(await request.arrayBuffer()) : null;
  if (typeof body === "string") return new TextEncoder().encode(body);
  if (body instanceof ArrayBuffer) return new Uint8Array(body.slice(0));
  if (ArrayBuffer.isView(body)) return new Uint8Array(body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength));
  return new Uint8Array(await request.arrayBuffer());
}

/**
 * Start the native call numbered `callId` unless `signal` has aborted. When
 * `signal` aborts, the call is cancelled and the promise rejects at once with
 * the abort reason.
 */
function cancellable<T>(callId: number, signal: AbortSignal | null | undefined, start: () => Promise<T>): Promise<T> {
  if (signal?.aborted) return Promise.reject(abortReason(signal));
  const call = start();
  return new Promise<T>((resolve, reject) => {
    const cancel = () => {
      native.cancel(callId);
      reject(abortReason(signal!));
    };
    signal?.addEventListener("abort", cancel);
    call
      .then(resolve, (error: unknown) => reject(rpcError(error)))
      .finally(() => signal?.removeEventListener("abort", cancel));
  });
}

/** Send a standard fetch through native worker `id`. */
export async function fetchThrough(
  id: number,
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  // Copied before anything is awaited (§9.1); a Request carries no forwarded
  // entries, only init does, and one that is not plain rejects the fetch.
  const fields = copyForwardedEntries(init);
  const request = new Request(input as RequestInfo, init);
  const signal = init?.signal ?? request.signal;
  if (signal?.aborted) throw abortReason(signal);
  const body = await requestBody(input, init, request);
  const buffered = JSON.stringify(
    encodeBufferedRequest({
      head: {
        method: request.method,
        url: request.url,
        headers: [...(request.headers as unknown as Iterable<[string, string]>)],
        redirect: init?.redirect ?? (input instanceof Request ? input.redirect : undefined),
        fields,
      },
      body: body ? encodeBase64(body) : undefined,
    }),
  );
  const callId = nextNativeId();
  const response = decodeBufferedResponse(
    JSON.parse(await cancellable(callId, signal, () => native.fetch(id, callId, buffered))),
  );
  const bytes = NULL_BODY_STATUSES.includes(response.status) ? null : decodeBase64(response.body);
  const { url } = response;
  // React Native's `Response` takes its `url` as an option.
  const result = new Response(bytes, { status: response.status, headers: response.headers, url } as ResponseInit);
  if (result.url !== url) Object.defineProperty(result, "url", { value: url });
  return result;
}

// The native creation a factory hands to the constructor.
let adopting: ((id: number) => string | null) | undefined;

function adopt(create: (id: number) => string | null): AnonRpcWorker {
  adopting = create;
  try {
    return new AnonRpcWorker(undefined as never);
  } finally {
    adopting = undefined;
  }
}

export class AnonRpcWorker {
  ready: Promise<void>;
  /** A standard `fetch`, bound so that it works as a free function. */
  fetch: AnonFetch;

  #id = nextNativeId();

  /** A worker that sends its traffic over the native Tor client. */
  static tor(config: TorConfig = {}): AnonRpcWorker {
    const [start] = nativeStart({ tor: config });
    const json = JSON.stringify(encodeTorInit(start.tor!));
    return adopt((id) => native.createTor(id, json));
  }

  /** A worker from bundle bytes already in hand. */
  static bundle(bundle: Uint8Array, init: BundleInit = {}): AnonRpcWorker {
    const [start, bytes] = nativeStart({ bundle, init });
    const json = JSON.stringify(encodeWorkerSettings(start.bundle!));
    return adopt((id) => native.createFromBundle(id, bytes!, json));
  }

  constructor(init: WorkerInit) {
    if (adopting) {
      create(this.#id, undefined, adopting);
    } else {
      const [start, , provider] = nativeStart({ specifier: init });
      const json = JSON.stringify(encodeSpecifierInit(start.specifier!));
      create(this.#id, provider, (id) => native.createFromAddress(id, json));
    }
    this.ready = native.ready(this.#id, nextNativeId()).catch((error) => {
      throw rpcError(error);
    });
    // A caller need not await `ready`; awaiting callers still observe a
    // rejection.
    this.ready.catch(() => {});
    this.fetch = this.#fetch.bind(this);
  }

  #fetch(input: RequestInfo | URL, init?: Parameters<AnonFetch>[1]): Promise<Response> {
    return fetchThrough(this.#id, input, init);
  }

  /**
   * The next log entry the worker produced, waiting for one if none is
   * retained. An abort consumes no entry: it cancels the native take, and an
   * entry the take already had is returned rather than lost.
   */
  async acceptLog(opts?: { signal?: AbortSignal }): Promise<LogEntry> {
    const signal = opts?.signal;
    if (signal?.aborted) throw abortReason(signal);
    const callId = nextNativeId();
    const cancel = () => native.cancel(callId);
    signal?.addEventListener("abort", cancel);
    try {
      return decodeLogEntry(JSON.parse(await native.acceptLog(this.#id, callId)));
    } catch (error) {
      throw signal?.aborted ? abortReason(signal) : rpcError(error);
    } finally {
      signal?.removeEventListener("abort", cancel);
    }
  }

  /** Stop the worker; pending and later calls fail with `closed`. */
  close(): void {
    forgetProvider(this.#id);
    native.close(this.#id);
  }
}
