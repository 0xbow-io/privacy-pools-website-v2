// The AnonRpc native module: forwards each call to AnonRpcBridge, which uses
// the public AnonRpc Swift SDK. On the New Architecture it is a TurboModule
// over the codegen spec; on the legacy architecture, an event emitter whose
// methods the bridge finds through RCT_EXPORT_METHOD.

#import <React/RCTBridgeModule.h>
#import <React/RCTInvalidating.h>
#ifdef RCT_NEW_ARCH_ENABLED
#import <AnonRpcSpec/AnonRpcSpec.h>
#else
#import <React/RCTEventEmitter.h>
#endif

#if __has_include(<AnonRpcReactNative/AnonRpcReactNative-Swift.h>)
#import <AnonRpcReactNative/AnonRpcReactNative-Swift.h>
#else
#import "AnonRpcReactNative-Swift.h"
#endif

#ifdef RCT_NEW_ARCH_ENABLED
@interface AnonRpc : NativeAnonRpcSpecBase <NativeAnonRpcSpec, RCTInvalidating>
#else
@interface AnonRpc : RCTEventEmitter <RCTBridgeModule, RCTInvalidating>
#endif
@end

@implementation AnonRpc {
  AnonRpcBridge *_bridge;
}

RCT_EXPORT_MODULE(AnonRpc)

- (instancetype)init
{
  if (self = [super init]) {
    _bridge = [AnonRpcBridge new];
    __weak AnonRpc *weakSelf = self;
    _bridge.emitProviderRequest = ^(NSDictionary *request) {
#ifdef RCT_NEW_ARCH_ENABLED
      [weakSelf emitOnProviderRequest:request];
#else
      [weakSelf sendEventWithName:@"onProviderRequest" body:request];
#endif
    };
  }
  return self;
}

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

// Close every worker and pool when JavaScript reloads, as the Android module
// does.
- (void)invalidate
{
  [_bridge invalidate];
}

#ifndef RCT_NEW_ARCH_ENABLED
- (NSArray<NSString *> *)supportedEvents
{
  return @[ @"onProviderRequest" ];
}
#endif

static void (^Resolver(RCTPromiseResolveBlock resolve))(id)
{
  return ^(id result) { resolve(result); };
}

static void (^Rejecter(RCTPromiseRejectBlock reject))(NSString *, NSString *, NSError *)
{
  return ^(NSString *code, NSString *message, NSError *error) { reject(code, message, error); };
}

// The creates, poolGroup, close and closePool are synchronous, so they run
// in JavaScript's order: each returns nil, or its failure as Failure JSON.
RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, createTor:(double)workerId initJson:(NSString *)initJson)
{
  return [_bridge createTor:(NSInteger)workerId initJson:initJson];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, createFromAddress:(double)workerId initJson:(NSString *)initJson)
{
  return [_bridge createFromAddress:(NSInteger)workerId initJson:initJson];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, createFromBundle:(double)workerId
                                    bundleBase64:(NSString *)bundleBase64
                                    settingsJson:(NSString *)settingsJson)
{
  return [_bridge createFromBundle:(NSInteger)workerId bundleBase64:bundleBase64 settingsJson:settingsJson];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, createReplacing:(double)workerId
                                    initJson:(NSString *)initJson
                                    bundleBase64:(NSString *)bundleBase64)
{
  return [_bridge createReplacing:(NSInteger)workerId initJson:initJson bundleBase64:bundleBase64];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, createPool:(double)poolId
                                    initJson:(NSString *)initJson
                                    bundleBase64:(NSString *)bundleBase64)
{
  return [_bridge createPool:(NSInteger)poolId initJson:initJson bundleBase64:bundleBase64];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, poolGroup:(double)poolId
                                    workerId:(double)workerId
                                    groupJson:(NSString *)groupJson)
{
  return [_bridge poolGroup:(NSInteger)poolId workerId:(NSInteger)workerId groupJson:groupJson];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, closePool:(double)poolId)
{
  return [_bridge closePool:(NSInteger)poolId];
}

RCT_EXPORT_METHOD(ready:(double)workerId callId:(double)callId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge ready:(NSInteger)workerId callId:(NSInteger)callId resolve:Resolver(resolve) reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(fetch:(double)workerId
        callId:(double)callId
   requestJson:(NSString *)requestJson
       resolve:(RCTPromiseResolveBlock)resolve
        reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge fetch:(NSInteger)workerId
          callId:(NSInteger)callId
     requestJson:requestJson
         resolve:Resolver(resolve)
          reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(acceptLog:(double)workerId
           callId:(double)callId
          resolve:(RCTPromiseResolveBlock)resolve
           reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge acceptLog:(NSInteger)workerId callId:(NSInteger)callId resolve:Resolver(resolve) reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(cancel:(double)callId)
{
  [_bridge cancel:(NSInteger)callId];
}

RCT_EXPORT_SYNCHRONOUS_TYPED_METHOD(NSString *, close:(double)workerId)
{
  return [_bridge close:(NSInteger)workerId];
}

RCT_EXPORT_METHOD(respondProvider:(double)workerId requestId:(double)requestId responseJson:(NSString *)responseJson)
{
  [_bridge respondProvider:(NSInteger)workerId requestId:(NSInteger)requestId responseJson:responseJson];
}

#ifdef RCT_NEW_ARCH_ENABLED
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeAnonRpcSpecJSI>(params);
}
#endif

@end
