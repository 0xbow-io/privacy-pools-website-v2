# @0xbow/anon-rpc-rs-react-native

Anonymized HTTP for React Native and Expo apps on iOS, Android, and web. `AnonRpcWorker` is the browser harness's [`AnonRpcWorker`](../../impl/browser-harness/) API, name for name, so viem and ethers code moves over unchanged. Construct it from a specifier address, optionally await `ready`, `fetch`, pull logs with `acceptLog`, and `close()`. On iOS and Android, a native module calls the [Swift](../swift/) and [Kotlin](../kotlin/) SDKs. They run the hash-pinned worker bundle in an embedded sandbox, or, with `AnonRpcWorker.tor()`, send every request over an [Arti](https://gitlab.torproject.org/tpo/core/arti) Tor client inside the app. On web, the same import is the browser harness.

## Requirements

The package has the following minimum versions:

| Platform | Minimum |
| --- | --- |
| React Native | 0.81 or later (peer range `>=0.81 <1`) |
| Expo (optional) | SDK 54, with a development build |
| iOS | 15.1, on devices and on arm64 and x86_64 simulators |
| Android | 7.0 (API 24), on `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64` |

The module runs on the New Architecture as a TurboModule, and on the legacy architecture of React Native 0.81. Expo apps need a development build (`npx expo prebuild`) because Expo Go doesn't include the module. The repository's example apps cover both architectures: `example` uses Expo SDK 58 with React Native 0.88, and `example-legacy` uses Expo SDK 54 with React Native 0.81 and `newArchEnabled` set to `false`.

React Native 0.81's `fmt` pod doesn't compile as C++20 under Xcode 27. The config plugin [`example-legacy/fmt-cxx17.plugin.js`](example-legacy/fmt-cxx17.plugin.js) builds it as C++17.

## Setup

The package and the two harness packages it depends on are assets of this repository's GitHub releases. The repository is private, so downloading them with [`gh`](https://cli.github.com/) requires an account with read access to it. To download the package, the browser harness, and the harness core into the `vendor` directory, run the following commands:

```sh
gh release download v0.4.0-beta.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-react-native-0.4.0-beta.1.tgz'
gh release download v0.4.0-beta.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz'
gh release download v0.4.0-beta.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz'
```

Then depend on the package's tar file, and resolve its browser harness and harness core dependencies from their tar files with the override field your package manager reads. npm and Bun read `overrides`:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-beta.1.tgz"
  },
  "overrides": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz",
    "@0xbow/anon-rpc-rs-harness-core": "file:./vendor/0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz"
  }
}
```

pnpm reads it under `pnpm.overrides`:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-beta.1.tgz"
  },
  "pnpm": {
    "overrides": {
      "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz",
      "@0xbow/anon-rpc-rs-harness-core": "file:./vendor/0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz"
    }
  }
}
```

Yarn 4 reads it under `resolutions` and requires `nodeLinker: node-modules` in the `.yarnrc.yml` file:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-beta.1.tgz"
  },
  "resolutions": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz",
    "@0xbow/anon-rpc-rs-harness-core": "file:./vendor/0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz"
  }
}
```

To finish the setup in an Expo app, do the following:

1. Add the package's config plugin to the `app.json` file: `"plugins": ["@0xbow/anon-rpc-rs-react-native"]`.
2. Run `npx expo prebuild`, then build the app.

The package bundles the Swift and Kotlin SDKs prebuilt, so you can build an app without a Rust toolchain, on EAS Build or on a local machine. On iOS, the config plugin adds the bundled `AnonRpc` pod to the Podfile. An app without Expo adds the following line to its Podfile:

```ruby
pod 'AnonRpc', :path => '../node_modules/@0xbow/anon-rpc-rs-react-native/native/ios'
```

On Android, the config plugin adds the bundled Maven repository, which holds `io.0xbow:anon-rpc-rs`, to the app's `build.gradle`, and the module adds it to every Gradle project of the app once Gradle configures the module. An app without Expo that builds with `--configure-on-demand` adds the following line to the `repositories` block of `allprojects` in `android/build.gradle`:

```groovy
maven { url "$rootDir/../node_modules/@0xbow/anon-rpc-rs-react-native/native/android" }
```

## Quick start

The following example starts the passthrough worker from its specifier contract on mainnet and sends one JSON-RPC call through it:

```ts
import { AnonRpcWorker } from "@0xbow/anon-rpc-rs-react-native";

const worker = new AnonRpcWorker({
  // The anonymizing network's specifier contract, on mainnet.
  address: "0x4fd77be300f31c5fe6ab266d35d27750a3478d27",
  preExisting: {
    // Reads the specifier contract once; any EIP-1193-style provider works.
    rpcProvider: {
      request: async ({ method, params }) => {
        const response = await fetch("https://ethereum-rpc.publicnode.com", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
        });
        return ((await response.json()) as { result: unknown }).result;
      },
    },
  },
});

// A standard fetch, routed through the hash-pinned worker.
const res = await worker.fetch("https://ethereum-rpc.publicnode.com", {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_blockNumber", params: [] }),
});
const { result } = (await res.json()) as { result: string };
console.log(result);

worker.close();
```

The passthrough worker fulfills calls with an ordinary fetch: it exercises the sandbox and hash pinning and anonymizes nothing. On iOS and Android, the sandbox has no `WebAssembly` and no nested `Worker`, so the tor-js, Nym, and Nox workers don't run in it. Their `ready` fails, and the package doesn't substitute Tor for them. For Tor, construct `AnonRpcWorker.tor()`.

## Fetch

`fetch` takes the same arguments as the global `fetch` and is bound to its worker, so it works as a free function. React Native's `Response` has no streaming body, so `fetch` resolves after the whole body arrives, and the package buffers request bodies before sending them. `response.url` is the final URL after redirects. `https` URLs are verified inside your app against the Mozilla roots, so a Tor exit sees only ciphertext; `.onion` hosts work too. The following rules apply to requests and responses:

- Header fields pass through React Native's `Headers`, which keeps them in the order they were added and joins a repeated field's values with commas, `set-cookie` included.
- Aborting the request's `signal` cancels the native transfer.
- Any other member of `init` is a forwarded entry (SPEC §9.1), which an embedded worker receives as a member of its `requestInit`. Its value must be a plain value (§9.4: JSON, plus `undefined`, `Uint8Array` and `ArrayBuffer`), or the `fetch` rejects with a `TypeError`.
- A `tor()` worker reads `anonOptions.isolationKey` (§9.3) by [the crate's isolation rules](https://github.com/0xbow-io/anon-rpc-rs/tree/main/crates/anon-rpc#isolation). On the web, the tor-js worker reads it too.

## Embedded workers

`new AnonRpcWorker({ address, config, preExisting: { rpcProvider } })` reads the specifier's `workerHash()` and `workerResolvers()` through `rpcProvider`, fetches the bundle from the first resolver that serves bytes with that hash, and runs only those bytes. `AnonRpcWorker.bundle(bytes, { config })` runs bundle bytes you already hold, identified by their keccak256 hash.

- The specifier read and the bundle fetch are not anonymized.
- `config` is a plain value (SPEC §9.4): JSON, plus `undefined`, `Uint8Array` and `ArrayBuffer`, with numbers delivered exactly. It reaches the worker as `anonRpcWorker.config`. Any other value throws a `TypeError`.
- `storageDir` sets where worker storage lives. It defaults to `anon-rpc/worker-storage` in the app's data directory.
- Inside the worker, `fetch` refuses loopback and private network addresses unless `allowPrivateNetworks` is `true`.
- `specifierChainId` is the ID of the chain that the specifier contract is published on. When it is set, the worker asks the provider for `eth_chainId` before the specifier read, and `ready` fails with `protocol-error` on any other chain. It does not limit the chains the worker's fetches reach.
- `expectedWorkerHash` is the bundle hash the host requires, as `0x` and 64 hex digits. When it is set, the worker compares it with the specifier's `workerHash()` before fetching any bundle, and `ready` fails with `protocol-error` when they differ; a malformed value fails with `unsupported`.

## Replacing workers and pools

`ReplacingWorker` is a `fetch` that starts a worker on first use and starts another when the worker in use stops answering. It replaces the worker because a route can stop carrying calls without the worker failing. `ready()` starts a worker without a call.

`WorkerPool` runs one replacing worker per isolation group and counts every live worker, spares included, against `maxWorkers`. `pool.group(key)` returns the group named `key`. When a group needs a worker and the budget is spent, the group waits, first come, first served. The least recently used group then gives up its worker after that worker's calls and response bodies finish, or at the call deadline. On iOS and Android, the anon-rpc crate runs both types through the Swift and Kotlin SDKs, by the rules of SPEC §5.1 and §5.2. Which traffic shares a group is the host's decision.

Both constructors take the following options:

| Option | Taken by | Description |
| --- | --- | --- |
| `start` | Both | How every worker starts: `{ tor: torConfig }`, `{ specifier: workerInit }`, or `{ bundle, init }`. A specifier start reads the specifier through `workerInit.preExisting.rpcProvider`. |
| `callTimeoutMs` | Both | How long a call can wait for its response head after the worker is ready. A call still waiting then fails with `timeout` and counts against the route. Without `callTimeoutMs`, a route that stops responding is never replaced. |
| `readyTimeoutMs` | Both | How long starting a worker and its `ready` together can take. |
| `maxWorkers` | `WorkerPool` | Required. The most workers alive at once, over every group and every spare. |
| `spare` | `WorkerPool` | How many started workers to keep for groups that have none. Default: `0`. |
| `idleCloseMs` | `WorkerPool` | How long a group's worker can go with no call pending before it closes. `pool.group(key, { idleCloseMs })` sets it for one group. |

## Errors, logs, and directories

Failures are `RpcError` objects. Each `code` is one of the specification's error codes, listed in `ErrorCode`, or a code that the worker reports for a failure. The error also carries the failure's details (SPEC §8) as properties of the `RpcError`, plain values keyed by name, such as `torKind` from a Tor worker.

`acceptLog({ signal })` returns the worker's log entries one at a time; an aborted call consumes no entry. Entries retained before `close()` stay readable after it.

`AnonRpcWorker.tor({ stateDir, cacheDir })` sets the directories the Tor client uses. By default, state lives in `anon-rpc/tor-state` in the app's data directory and the cache in `anon-rpc/tor-cache` in the app's cache directory. Workers with equal directories share one Tor client. Each worker is a separate isolation group, so use one worker for each identity that must stay unlinkable.

## Web

On `react-native-web`, the package's `browser` entry re-exports `AnonRpcWorker` and `RpcError` from [`@0xbow/anon-rpc-rs-browser-harness`](../../impl/browser-harness/), which runs workers in a sandboxed iframe. The entry's `ReplacingWorker` and `WorkerPool` run the harness's workers and start each one as `start` says. On web, the package differs from iOS and Android in the following ways:

- `AnonRpcWorker.tor({ gateways, rpcProvider, iframeUrl })` runs the tor-js worker, whose traffic leaves through the KPS `gateways`. `gateways` is required, and a `tor` start takes the same object.
- A `bundle` start fails with `unsupported`.
- `iframeUrl` is honored.
- Response bodies stream.

## Build the bundled SDKs

In a checkout of this repository, build the bundled SDKs from source before you build the package or an example app:

```sh
npm --prefix packages/react-native run build:native
```

The iOS build needs Xcode and the Rust iOS targets, as [`packages/swift`](../swift/) describes. The Android build needs the Android NDK, `cargo-ndk`, and the Rust Android targets, as [`packages/kotlin`](../kotlin/) describes. To limit the Android build to some ABIs, list them in `ANON_RPC_ABIS`, for example `ANON_RPC_ABIS=x86_64`.

## Tests

The following commands install the dependencies and run the package's tests:

```sh
bun install --cwd packages/react-native
npm --prefix packages/react-native/example install
npm --prefix packages/react-native test
```

`npm test` typechecks the package, runs its JavaScript tests over a fake native module, and checks that the example's Metro web resolution selects the web entry. That check needs the browser harness built (`npm --prefix impl/browser-harness run build`).

The `example` and `example-legacy` apps run the conformance cases through the real module on a simulator or emulator and report them to `check.mjs`. To run `example`, build the bundled SDKs, then run the following commands from the `packages/react-native/example` directory:

```sh
npx expo prebuild --clean --no-install
(cd ios && pod install && xcodebuild -workspace AnonRpcExample.xcworkspace -scheme AnonRpcExample -configuration Debug -sdk iphonesimulator -destination 'id=SIMULATOR_ID' -derivedDataPath build/DerivedData build)
node check.mjs ios ios/build/DerivedData/Build/Products/Debug-iphonesimulator/AnonRpcExample.app SIMULATOR_ID
(cd android && ./gradlew :app:assembleDebug)
node check.mjs android android/app/build/outputs/apk/debug/app-debug.apk EMULATOR_SERIAL
```

Replace the following:

- `SIMULATOR_ID`: the UDID of the iOS simulator.
- `EMULATOR_SERIAL`: the serial number of the Android emulator.

To run `example-legacy`, install it with `npm --prefix packages/react-native/example-legacy install`, then run the same commands from its directory, with `node ../example/check.mjs` in place of `node check.mjs`.

The case that fetches over the live Tor network runs only with `ANON_RPC_LIVE=1` in the environment of `check.mjs`.
