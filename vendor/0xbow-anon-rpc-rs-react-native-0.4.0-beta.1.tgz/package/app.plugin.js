// Expo config plugin: adds the AnonRpc pod this package bundles in native/ios
// to the app's Podfile, and the Maven repository in native/android to the
// app's build.gradle. The module's Gradle build adds that repository too, but
// only once it is configured, which `expo run:android` (configure on demand)
// does after it has resolved the app's dependencies.
const fs = require("fs");
const path = require("path");
// The app's own copy of Expo, which this package does not install.
const { withDangerousMod, withProjectBuildGradle } = require(
  require.resolve("expo/config-plugins", { paths: [process.cwd()] }),
);

const pod = path.join(__dirname, "native", "ios");
const maven = path.join(__dirname, "native", "android");

function withSwiftSdk(config) {
  return withDangerousMod(config, [
    "ios",
    (config) => {
      const podfile = path.join(config.modRequest.platformProjectRoot, "Podfile");
      const contents = fs.readFileSync(podfile, "utf8");
      const relative = path.relative(config.modRequest.platformProjectRoot, pod);
      const line = `  pod 'AnonRpc', :path => '${relative}'`;
      if (!contents.includes(line)) {
        fs.writeFileSync(podfile, contents.replace(/^(target '[^']+' do\n)/m, `$1${line}\n`));
      }
      return config;
    },
  ]);
}

function withKotlinSdk(config) {
  return withProjectBuildGradle(config, (config) => {
    const relative = path.relative(config.modRequest.platformProjectRoot, maven);
    const line = `    maven { url "$rootDir/${relative}" }`;
    const gradle = config.modResults;
    if (!gradle.contents.includes(line)) {
      gradle.contents = gradle.contents.replace(/^allprojects \{\n {2}repositories \{\n/m, `$&${line}\n`);
    }
    return config;
  });
}

module.exports = (config) => withKotlinSdk(withSwiftSdk(config));
