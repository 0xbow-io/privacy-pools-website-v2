import AnonRpcC
import Foundation

extension AnonRpcWorker {
    /// A response body that streams from the network as it arrives, as
    /// chunks of `Data`.
    ///
    /// Cancelling the reading task cancels the transfer, and so does
    /// releasing the body before its end.
    public final class Body: AsyncSequence, @unchecked Sendable {
        public typealias Element = Data

        let handle: UInt64
        /// The worker the body streams from, kept open while the body lives.
        private let worker: AnonRpcWorker
        /// Reads run one at a time on `reads`, into `buffer`.
        private let reads = DispatchQueue(label: "anon-rpc.body")
        private let buffer = UnsafeMutableBufferPointer<UInt8>.allocate(capacity: 64 * 1024)

        init(handle: UInt64, worker: AnonRpcWorker) {
            self.handle = handle
            self.worker = worker
        }

        deinit {
            anon_rpc_body_free(handle)
            buffer.deallocate()
        }

        /// The next chunk, empty at the end of the body.
        func read() async throws -> Data {
            let handle = handle
            return try await blocking(on: reads, cancel: { anon_rpc_body_cancel(handle) }) { [self] in
                var count = 0
                var error = AnonRpcBuffer()
                let status = anon_rpc_body_read(handle, buffer.baseAddress, buffer.count, &count, &error)
                try check(status, error)
                return Data(buffer[..<count])
            }
        }

        public func makeAsyncIterator() -> Iterator {
            Iterator(body: self)
        }

        public struct Iterator: AsyncIteratorProtocol {
            let body: Body

            /// The next chunk, or `nil` at the end of the body.
            public mutating func next() async throws -> Data? {
                let chunk = try await body.read()
                return chunk.isEmpty ? nil : chunk
            }
        }
    }
}
