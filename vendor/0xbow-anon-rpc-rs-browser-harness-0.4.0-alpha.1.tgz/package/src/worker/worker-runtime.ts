// Trusted harness code that runs as the Web Worker's top-level script. It wires
// up `anonRpcWorker` from the capability port, exposes it as a global, then
// loads the hash-verified (untrusted) worker bundle, which uses that global as
// its entire platform. The worker bundle is the §4 conformance artifact; this
// runtime is part of the harness.
//
// Bundled to a classic-worker IIFE so `importScripts` is available.

import { PortRpc } from "../protocol.js";
import { makeWorkerApi } from "./anon-rpc-worker-api.js";

addEventListener("message", function onInit(ev: MessageEvent) {
  if (ev.data?.kind !== "init") return;
  removeEventListener("message", onInit as EventListener);

  const port: MessagePort = ev.data.port;
  const bundleBytes: Uint8Array = ev.data.bundleBytes;
  const config: unknown = ev.data.config;

  const rpc = new PortRpc(port);
  // config is set before the bundle executes: §7.1 requires it available from
  // the worker's first instruction.
  const api = makeWorkerApi(rpc, config);
  (globalThis as unknown as { anonRpcWorker: unknown }).anonRpcWorker = api;

  try {
    const blob = new Blob([bundleBytes as unknown as BlobPart], { type: "text/javascript" });
    // eslint-disable-next-line no-restricted-globals
    (self as unknown as { importScripts: (u: string) => void }).importScripts(
      URL.createObjectURL(blob),
    );
  } catch (err) {
    const message = (err as Error)?.message ?? String(err);
    api.log.error("worker bundle failed to load:", message);
    // The host rejects `ready` on this; logging alone would leave it hanging.
    rpc.emit("boot-error", { message });
  }
});
