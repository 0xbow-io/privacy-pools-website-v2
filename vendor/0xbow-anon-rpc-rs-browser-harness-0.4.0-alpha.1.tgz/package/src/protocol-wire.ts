// The frames and the error marshalling of the capability RPC, which every
// harness speaks over its own transport. Each harness carries a copy of this
// file that `cargo xtask generate` writes from
// impl/browser-harness/src/protocol-wire.ts.

export type SerializedError = { name: string; message: string; code?: string };

export type Wire =
  | { t: "req"; id: number; method: string; args: unknown }
  | { t: "abort"; id: number }
  | { t: "res"; id: number; ok: true; value: unknown }
  | { t: "res"; id: number; ok: false; error: SerializedError }
  | { t: "evt"; topic: string; data: unknown };

export class RpcError extends Error {
  code?: string;
  constructor(e: SerializedError) {
    super(e.message);
    this.name = e.name;
    this.code = e.code;
  }
}

/** The one error-marshalling implementation; pair with `new RpcError(...)` to deserialize. */
export function serializeError(err: unknown): SerializedError {
  if (err instanceof Error) {
    const code = (err as { code?: unknown }).code;
    return {
      name: err.name,
      message: err.message,
      ...(typeof code === "string" ? { code } : {}),
    };
  }
  return { name: "Error", message: String(err) };
}
