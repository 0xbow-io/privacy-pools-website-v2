// Host-facing type surface from SPEC.md (§5): what an embedder hands a
// harness, and what it collects from one.

import type { LogArg } from "./worker-types.js";

/* §5 — Host-side harness API */

export type RpcProvider = {
  // Minimal EIP-1193-ish provider: enough to read a specifier contract.
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
};

export type WorkerInit = {
  // The specifier contract address.
  address: string;
  // Delivered to the worker as `anonRpcWorker.config` (§7.1). Structured-
  // cloneable; opaque to the harness — its schema is defined by the worker.
  config?: unknown;
  // Where a browser harness loads its null-origin document from, for an
  // embedder whose CSP will not let the harness construct one inline (§6).
  // A harness that does not use an iframe MUST ignore it.
  iframeUrl?: string;
  preExisting?: {
    rpcProvider?: RpcProvider;
  };
};

/** §5/§13.1: one log call, as the host collects it through `acceptLog()`. */
export type LogEntry = {
  level: "debug" | "info" | "warn" | "error";
  args: LogArg[];
};

