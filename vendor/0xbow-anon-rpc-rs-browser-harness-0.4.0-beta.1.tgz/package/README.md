# @0xbow/anon-rpc-rs-browser-harness

The browser harness gives a web page an anonymized `fetch` through
[anon-rpc](https://github.com/ethereum/anon-rpc), a standard that lets a wallet
or application make anonymized RPC requests by running hash-pinned
anon-client code inside a sandboxed worker.

Implements the [anon-rpc specification](../../SPEC.md)
version **0.4.0**. The package version, without its pre-release suffix, is
at least the implemented specification version; a package release without a
specification change goes past it.

The harness does the following:

- Resolves the anon-client bundle from an onchain specifier contract, over
  `https:` or over KPS through `kps:` resolver entries (SPEC §4.1 and §4.2),
  and checks `keccak256(bytes) == workerHash()` before it runs any of the
  bundle. Trust rests on the hash: any URL that serves matching bytes is
  acceptable.
- Runs the bundle in a Web Worker inside a null-origin sandboxed iframe,
  with no ambient access to your DOM, storage, cookies, or keys.
- Gives the worker a small, explicit capability API: inbound fetch calls, a
  [KPS](https://ethereum.github.io/kps/) key-pinned transport (bridged, so the
  worker never touches WebRTC), persistent storage (IndexedDB on the host
  origin, namespaced per specifier), and logging.
- Returns one thing to you: an anonymized `fetch`.

## Install

The package and the harness core it depends on are assets of this repository's GitHub releases. The repository is private, so downloading them with [`gh`](https://cli.github.com/) needs an account with read access to it. Download both into `vendor/`:

```sh
gh release download v0.4.0-beta.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz'
gh release download v0.4.0-beta.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz'
```

Then depend on the package's tar file, and resolve its harness core dependency from its tar file. Use the override field your package manager reads: `overrides` for npm and Bun, `pnpm.overrides` for pnpm, and `resolutions` for Yarn 4 (with `nodeLinker: node-modules` in `.yarnrc.yml`). For npm and Bun:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-beta.1.tgz"
  },
  "overrides": {
    "@0xbow/anon-rpc-rs-harness-core": "file:./vendor/0xbow-anon-rpc-rs-harness-core-0.4.0-beta.1.tgz"
  }
}
```

## Use

Construct an `AnonRpcWorker` from a specifier contract's address and a provider
that can read it, then call its `fetch`:

```ts
import { AnonRpcWorker } from "@0xbow/anon-rpc-rs-browser-harness";

const worker = new AnonRpcWorker({
  // The IWorkerSpecifier contract identifying the anon-client by hash.
  address: "0x…",
  // Optional: a plain value (JSON, plus undefined, Uint8Array, ArrayBuffer)
  // delivered to the worker exactly as `anonRpcWorker.config`. Opaque to the
  // harness; the worker defines its schema. Anything else throws a TypeError.
  config: { network: "mainnet" },
  // Bootstrap provider used only to read the specifier (breaks the circular
  // "need the chain to reach the chain" dependency).
  preExisting: { rpcProvider },
});

// Optional: wait for the worker to report that it is ready. Fetch calls
// made before then are buffered.
// await worker.ready;

// A standard fetch, routed through the sandboxed anon-client.
// It is this-bound, so it works as a free function.
const res = await worker.fetch("https://rpc.example/", {
  method: "POST",
  body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_blockNumber" }),
});

worker.close(); // tears down the iframe and worker
```

### Tor

`AnonRpcWorker.tor` starts the tor-js worker, a Tor client compiled to
WebAssembly, from its specifier on mainnet:

```ts
const worker = AnonRpcWorker.tor({
  // Required: the KPS gateways that relay Tor traffic, as
  // "<ip>:<port>:<certhash>". There is no default gateway.
  gateways: ["152.236.3.22:12298:uEiCH0VdbhryzJcMtCfB0vLA4sOvHdQ4hq5w7CopcwU59bQ"],
  rpcProvider,
  // iframeUrl: optional, as for the constructor.
});
```

`AnonRpcWorker.tor` is shorthand for
`new AnonRpcWorker(knownWorkerInit("tor-js", { rpcProvider, config: { gateways }, iframeUrl }))`,
so it also checks that `rpcProvider` answers for mainnet (see
[The specifier's chain](#the-specifiers-chain)). The gateway in the example is
a demonstration relay with limited capacity; for production traffic, run a
gateway you operate. The Rust crate and the Swift, Kotlin, React Native (on iOS
and Android), Flutter, and Node packages run workers in a sandbox without
WebAssembly, so tor-js doesn't run there. Their `tor` constructor uses the Arti
Tor client instead.

### Nym, Nox, and the other published workers

`KNOWN_WORKERS` lists the workers in
[`adopters.json5`](../../adopters.json5) (passthrough, tor-js, Nym, and Nox),
with each one's specifier and the chain it is published on. `knownWorkerInit`
turns a name into a `WorkerInit`:

```ts
import { AnonRpcWorker, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

// Nym is published on mainnet, Nox on Sepolia. Neither requires config.
const nym = new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider }));
const nox = new AnonRpcWorker(knownWorkerInit("nox", { rpcProvider: sepoliaProvider }));

// Either one carries calls to any chain: the specifier's chain is only where
// the bundle's identity is read.
await nox.fetch("https://ethereum-rpc.publicnode.com", { method: "POST", body });
```

The list is data: the harness boots every worker the same way. `kind` is
`"reference"` for passthrough, which does not anonymize. You must pass every
required config key (tor-js needs `gateways`), and `knownWorkerInit` throws a
`TypeError` when one is missing. Nym's bundle is about 18 MB and its mixnet
takes several seconds to join; Nox's bundle is about 2 MB. Nym's first call to
each host can take half a minute. For more information, see
[Networks and runtimes](../../docs/integrate-wallet.md#networks-and-runtimes)
in the integration guide. A Nym worker can also start on a route that never
answers; see [Replace a worker whose route fails](#replace-a-worker-whose-route-fails).

#### The specifier's chain

`WorkerInit.specifierChainId` is the ID of the chain the specifier contract is
published on, which is the chain `rpcProvider` must answer for. On another
chain the same address can be empty or hold a contract that pins different
code. `knownWorkerInit` sets it. When it is set, the harness asks `rpcProvider`
for `eth_chainId` before the §4 reads. On any other answer, it fails `ready`
with a `SpecifierChainError` (`expectedChainId`, `actualChainId`, code
`protocol-error`) without reading the specifier. A value that is not a positive
integer fails `ready` with a `TypeError` (code `unsupported`). The check covers
only the specifier reads, and the worker's fetches can reach any chain.
`specifierChainId` is an extension of this harness that SPEC.md §5 does not
define. When it's unset, the harness skips the `eth_chainId` request.

Workers of one specifier in one page share this boot work for the life of the
page. The chain check and the specifier reads run once per `rpcProvider`
object, and the harness keeps the verified bundle by its hash. It discards a
failed read or download, and work in flight stops only after every worker
waiting on it has closed. A worker started later sees a changed specifier only through
a different provider object or after a page reload.

#### The expected bundle hash

`WorkerInit.expectedWorkerHash` (§5) is the bundle hash the host requires. A
specifier owner can change the code it pins at any time, and this option keeps
that change from reaching a host that has not reviewed it. The value is `0x`
followed by 64 hex digits in either case. When it is set, the harness compares
it with the specifier's `workerHash()` before fetching any bundle, and fails
`ready` with a `WorkerHashMismatchError` (`expectedWorkerHash`,
`actualWorkerHash`, code `protocol-error`) when they differ. A malformed value
fails `ready` with a `TypeError` (code `unsupported`) before anything is read.

### Replace a worker whose route fails

A worker keeps the route it picks when it starts, and that route can carry
nothing. In 79 fresh Nym boots on desktop Chromium and Android Chrome, 7 drew
an exit that accepted connections and then failed every call, and the worker
never reported itself failed. `ReplacingWorker` is a `fetch` that starts a
worker on first use and starts another when the worker in use stops answering:

```ts
import { AnonRpcWorker, ReplacingWorker, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

const nym = new ReplacingWorker({
  start: () =>
    new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider })),
  // A cold route took up to 35 s; a call still waiting at 90 s counts as failed.
  callTimeoutMs: 90_000,
  readyTimeoutMs: 180_000,
});
const response = await nym.fetch("https://ethereum-rpc.publicnode.com", { method: "POST", body });
```

SPEC §5.1 defines `ReplacingWorker`. It follows these rules:

- **Call outcomes.** A call that answers with any status shows that the route
  works. A call that outlasts `callTimeoutMs` after the worker is ready fails
  with code `timeout` and counts as failed. A call that its caller cancels
  counts as neither, and so does a call whose `init` holds a forwarded entry
  that is not a plain value, which fails with a `TypeError` before it is
  sent.
- **Routes.** A call's route is its `anonOptions.isolationKey`, and calls
  without a key share one route. A worker that isolates by key, such as
  tor-js, keeps a circuit per key, so one key can stop answering while the
  others work. The rules below apply to each route alone.
- **Replacement.** The worker is replaced when a call fails with none on its
  route answered since (the second such failure, once the worker has
  answered) and every host with a call still waiting on that route has also
  failed since the route's last answer. One failing endpoint says nothing
  about the route while another host can still answer.
- **Silent route.** When the failure is a call that outlasted `callTimeoutMs`
  while no call on its route answered, the worker is replaced even while calls
  to other hosts wait. The route stayed silent for a whole deadline, and
  waiting on hosts first tried during it adds one deadline per host to the
  replacement.
- **Retiring.** Replacing closes the old worker, which ends the calls still on
  it. A worker that fails to start, or isn't ready within `readyTimeoutMs`, is
  closed, the calls waiting on it fail, and the next call starts another.
- **Closing.** `close()` closes the worker in use, and later calls fail with
  code `closed`.

`start` receives a signal that aborts when that worker is closed, for anything
it reads before it constructs the worker. `ready()` starts a worker without a
call and settles when it is ready. `ReplacingWorker` uses only a worker's
`ready`, `fetch`, and `close`, so it also accepts the React Native and Node
packages' workers.

### Run isolation groups under a worker budget

Traffic that must not be linked goes over separate workers, unless the worker
keeps isolation keys apart (see
[Pass per-call options](#pass-per-call-options)). Each worker costs memory,
CPU, and a route. On an Android Chrome emulator each added worker
took 120 MB to 250 MB, and tor-js workers slowed down past four. `WorkerPool`
runs one `ReplacingWorker` per isolation group and counts every live worker
against one budget:

```ts
import { AnonRpcWorker, WorkerPool, knownWorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";

const pool = new WorkerPool({
  start: () => new AnonRpcWorker(knownWorkerInit("nym", { rpcProvider: mainnetProvider })),
  maxWorkers: 2, // every worker alive, spares included
  spare: 1, // started ahead for the next group that needs a worker
  idleCloseMs: 120_000, // close a group's worker unused this long
  callTimeoutMs: 90_000,
  readyTimeoutMs: 180_000,
});

await pool.group("reads").ready(); // start a long-lived group now
const operation = pool.group(`withdrawal:${id}`); // takes the spare
await operation.fetch(relayerUrl, { method: "POST", body });
operation.close(); // frees its place; the pool starts a new spare
```

SPEC §5.2 defines `WorkerPool`. It follows these rules:

- **Isolation.** Calls in two groups never share a worker. You decide which
  traffic shares a group; when the budget is tight, use fewer groups.
- **Waiting.** A group that needs a worker when the budget is spent waits,
  first come, first served, until a group closes, an idle worker closes, or a
  worker is retired. The wait counts toward `readyTimeoutMs`, and a caller's
  signal ends it for that call.
- **Turnover.** While a group waits, the least recently used group gives up
  its worker. That group's later calls wait for a place in turn. Its worker
  closes after the calls already on it and their response bodies finish, or
  `callTimeoutMs` after it gave up its place. With `callTimeoutMs` set, a busy
  group can't starve another.
- **Idling.** A group's `idleCloseMs` can differ from the pool's
  (`pool.group(key, { idleCloseMs })`). A response body still being read
  doesn't keep a group busy.
- **Spares.** A spare that fails to start frees its place, and the next spare
  starts only when a group needs one.
- **Closing.** `pool.close()` closes every group and spare, and later calls
  fail with code `closed`.

Size a Nym pool by CPU. Each Nym worker runs a full mixnet client whose cover
traffic never stops, so it uses about a quarter of a 4-core Android device
whether or not it carries a call. Four of them held a 4-vCPU emulator at 72% to
96% before the first call, and first calls failed after other load took the
rest. On phones, start from
`maxWorkers: Math.max(1, Math.floor(navigator.hardwareConcurrency / 2))`, and
give Nym groups an `idleCloseMs` of 60 s to 120 s, because an idle Nym worker
uses as much CPU as a busy one.

### Pass per-call options

Every key of the `fetch` call's `init` that SPEC §9.1 does not model reaches
the worker in its `requestInit`. Options that the specification defines go in
`anonOptions`, which are addressed to the worker (SPEC §9.3):

```ts
await worker.fetch(rpcUrl, { method: "POST", body, anonOptions: { isolationKey: account } });
```

`isolationKey` asks that calls under different keys not be linkable to one
another. Values are §9.4 plain values (JSON, plus `undefined`, `Uint8Array`,
and `ArrayBuffer`), copied when `fetch` is called and never logged. A value
that is not plain rejects the `fetch` with a `TypeError`. Only `init` carries
options, even when the input is a `Request`. `ReplacingWorker` and every
`WorkerPool` group pass them on.

Support varies by worker. A worker that does not act on a key carries every
call alike. Pass a key only to a worker whose bundle hash you require
(`expectedWorkerHash`) and whose handling of it you know. The tor-js 0.4.4
bundle, which the tor-js specifier pins, gives each key its own circuits and
TLS session cache, so calls under different keys share neither, and an empty
key or one over 256 bytes fails the call. One tor-js worker can then carry
every identity, where a worker that ignores the key needs a worker or
`WorkerPool` group for each.

### Collect the worker's logs

A worker's §13 `log` calls go to the console until you collect them. After you
call `acceptLog()` (SPEC §5, §13.1), they stop being echoed there:

```ts
for (;;) {
  // Resolves with the next entry; waits when there is none. Rejects once the
  // worker has failed or closed AND its retained entries are drained, so the
  // lines explaining a failure arrive before the rejection does.
  const { level, args } = await worker.acceptLog();
  render(level, args);
}
```

The harness retains entries from the moment the worker starts, so a line
logged during boot is still there when you first ask. The buffer holds 1,000
entries and drops the oldest beyond that. §13.1 makes this the only place a
harness can lose a log call it has accepted.

### Run under a strict Content Security Policy

By default the harness builds its null-origin iframe with `srcdoc` and an
inline bootstrap script, which needs nothing from you. If your page's Content
Security Policy (CSP) omits `'unsafe-inline'` from `script-src`, that bootstrap
doesn't run: a `srcdoc` document inherits the embedder's policy, and a document
can tighten that policy but can't relax it. `ready` then rejects about
3 seconds after the iframe loads, with an error that names `iframeUrl`, and the
console shows a CSP violation.

To run under such a policy, serve the harness's bootstrap page yourself and
point `iframeUrl` (SPEC §5) at it:

```ts
new AnonRpcWorker({ address, preExisting, iframeUrl: "/anon-rpc-iframe.html" });
```

The page needs only the bootstrap script, which the package exports as
`@0xbow/anon-rpc-rs-browser-harness/iframe-boot.js`
(`dist/iframe-boot.js`). Serve the script from your origin; this page loads it
as `/anon-rpc-iframe.js`:

```html
<!doctype html><meta charset="utf-8"><script src="/anon-rpc-iframe.js"></script>
```

The harness still applies `sandbox="allow-scripts"`, so the document runs at an
opaque origin however it was loaded. A cross-origin bootstrap puts the
isolation boundary in a third party's hands, so §6 requires the URL to be
same-origin with your page, and the harness rejects any other.

On Firefox, allow `data:` in the bootstrap page's `script-src` wherever a
policy applies there. Firefox refuses `importScripts(blob:)` in an
opaque-origin worker, so the harness detects this and loads the verified
bundle from a `data:` URL; other browsers use `blob:`.

MV3 browser extensions must use `iframeUrl` and must also declare the page in
the manifest's `sandbox.pages`.
[`@0xbow/anon-rpc-rs-browser-extension-harness`](../browser-extension-harness)
packages all of this.

## Browser support

The harness needs Chrome 100, Firefox 100, or Safari 15.4 (iOS 15.4) or later.
Those versions add `AbortSignal.throwIfAborted`, `WritableStream`, and
`Object.hasOwn`, the most recent platform features the harness uses. Stream
bytes, for KPS streams and for streamed request and response bodies, cross the
sandbox boundary as messages, so browsers that can't transfer a stream (Safari
before 27) run every worker.

Tested with Chromium 156, Firefox 157, and WebKit 27.2 (Playwright 1.64),
Safari 27.0.1 on macOS, and Safari on iOS 26.4 and 26.5 (Simulator): Nym,
Nox, and tor-js boot and carry calls in each. Versions between the minimum
and these are untested.

## Notes

- The harness runs only in browsers: the isolation model is a null-origin
  iframe, and the KPS transport runs over WebRTC. For Node applications, use
  [`@0xbow/anon-rpc-rs-node`](../../packages/node/).
- The specification defines the worker-facing capability API
  (`anonRpcWorker`) and all conformance requirements. To start an anon-client,
  copy the template in [`impl/passthrough-worker`](../passthrough-worker/).
- Status: a prototype-grade reference implementation of a draft
  specification. Interfaces track the specification and might change.

## License

MIT © Ethereum Foundation
