// Byte streams across the capability port, one chunk per call.
//
// No stream object crosses the port: Safari before 27 throws DataCloneError on
// transferring a ReadableStream or a WritableStream. The side that holds a
// stream keeps it and answers reads and writes for it; the other side gets a
// stand-in stream that makes those calls. A read pulls one chunk, a stand-in
// readable reads at most a few chunks ahead of its reader, and a write waits
// for the holder to accept it, so backpressure still reaches the real stream,
// and cancel, close and abort cross with their reason. The holder forgets a
// stream once it ends, once the other side's stand-in for it is
// garbage-collected, or once the port closes, so it keeps the stream exactly
// as long as the other side can still use it, and cancels or aborts one it
// forgets before its end. The native harness's sandbox relays its streams the
// same way.

import { wireReason } from "@0xbow/anon-rpc-rs-harness-core";
import type { PortRpc } from "./protocol.js";

/** What crosses the port in place of a stream. */
export type StreamRef = { relay: number };

export function isStreamRef(v: unknown): v is StreamRef {
  return typeof v === "object" && v !== null && typeof (v as StreamRef).relay === "number";
}

// The chunk as a Uint8Array over a buffer of its own, so the buffer can be
// transferred without detaching bytes that belong to someone else.
function ownBytes(chunk: unknown): Uint8Array {
  if (chunk instanceof Uint8Array) return chunk.slice();
  if (chunk instanceof ArrayBuffer) return new Uint8Array(chunk.slice(0));
  if (ArrayBuffer.isView(chunk)) return new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength).slice();
  throw new TypeError("a byte stream chunk must be a Uint8Array");
}

// How far a stand-in readable reads ahead of its reader. Each read is a round
// trip over the port, and with one at a time the port sits idle while every
// reply crosses, which more than halves throughput. A stand-in asks for
// another chunk while the reads already in flight, judged by the last chunk's
// size, bring at most READ_AHEAD_BYTES, and keeps at most READ_AHEAD_MAX of
// them in flight.
const READ_AHEAD_BYTES = 1 << 20;
const READ_AHEAD_MAX = 16;

type RelayRead = { done?: true; chunk?: Uint8Array };

class StreamRelay {
  #rpc: PortRpc;
  #nextId = 1;
  #readers = new Map<number, ReadableStreamDefaultReader<Uint8Array>>();
  #writers = new Map<number, WritableStreamDefaultWriter<Uint8Array>>();
  // Keyed on a stand-in's underlying source or sink, not on the stream: the
  // stream keeps it for as long as it can still call it, while Chromium and
  // WebKit may collect a stream's JS object whose native stream is still being
  // read through a reader.
  #collected = new FinalizationRegistry<number>((id) => this.#rpc.emit("relay.drop", { id }));

  constructor(rpc: PortRpc) {
    this.#rpc = rpc;
    // Nothing on the other side can use the stream any more, so it is ended
    // as dispose() ends it: the source stops producing, the sink is reset.
    rpc.onEvent("relay.drop", ({ id }: { id: number }) => {
      void this.#readers.get(id)?.cancel().catch(() => {});
      void this.#writers.get(id)?.abort().catch(() => {});
      this.#readers.delete(id);
      this.#writers.delete(id);
    });
    rpc.on("relay.read", async ({ id }: { id: number }) => {
      const reader = this.#readers.get(id);
      if (!reader) throw new Error(`unknown stream ${id}`);
      try {
        const r = await reader.read();
        if (r.done) {
          this.#readers.delete(id);
          return { value: { done: true } };
        }
        const chunk = ownBytes(r.value);
        return { value: { chunk }, transfer: [chunk.buffer as ArrayBuffer] };
      } catch (e) {
        this.#readers.delete(id);
        throw e;
      }
    });
    rpc.on("relay.cancel", async ({ id, reason }: { id: number; reason?: unknown }) => {
      const reader = this.#readers.get(id);
      this.#readers.delete(id);
      await reader?.cancel(reason);
      return { value: undefined };
    });
    rpc.on("relay.write", async ({ id, chunk }: { id: number; chunk: Uint8Array }) => {
      const writer = this.#writers.get(id);
      if (!writer) throw new Error(`unknown stream ${id}`);
      try {
        await writer.write(chunk);
      } catch (e) {
        this.#writers.delete(id);
        throw e;
      }
      return { value: undefined };
    });
    rpc.on("relay.close", async ({ id }: { id: number }) => {
      const writer = this.#writers.get(id);
      if (!writer) throw new Error(`unknown stream ${id}`);
      this.#writers.delete(id);
      await writer.close();
      return { value: undefined };
    });
    rpc.on("relay.abort", async ({ id, reason }: { id: number; reason?: unknown }) => {
      const writer = this.#writers.get(id);
      this.#writers.delete(id);
      await writer?.abort(reason);
      return { value: undefined };
    });
  }

  /** Keep `stream` on this side and answer the peer's reads of it. Locks it; throws if already locked. */
  sendReadable(stream: ReadableStream<Uint8Array>): StreamRef {
    const id = this.#nextId++;
    this.#readers.set(id, stream.getReader());
    return { relay: id };
  }

  /** Keep `stream` on this side and apply the peer's writes to it. Locks it; throws if already locked. */
  sendWritable(stream: WritableStream<Uint8Array>): StreamRef {
    const id = this.#nextId++;
    this.#writers.set(id, stream.getWriter());
    return { relay: id };
  }

  /** Cancel and forget every stream this side holds, as the port closes. */
  dispose(): void {
    for (const reader of this.#readers.values()) void reader.cancel().catch(() => {});
    for (const writer of this.#writers.values()) void writer.abort().catch(() => {});
    this.#readers.clear();
    this.#writers.clear();
  }

  /** The peer's readable stream `ref`, read through the port. */
  readable({ relay: id }: StreamRef): ReadableStream<Uint8Array> {
    const rpc = this.#rpc;
    // Reads asked of the holder and not yet taken, oldest first. Once the
    // stream ends, the rest are left unread.
    const reads: Promise<RelayRead>[] = [];
    // Taken as large until a chunk shows otherwise, so a first read asks for
    // little.
    let chunkSize = READ_AHEAD_BYTES;
    const source: UnderlyingDefaultSource<Uint8Array> = {
      async pull(controller) {
        while (reads.length < READ_AHEAD_MAX && reads.length * chunkSize <= READ_AHEAD_BYTES) {
          const read = rpc.call<RelayRead>("relay.read", { id });
          read.catch(() => {});
          reads.push(read);
        }
        const r = await reads.shift()!;
        if (r.done) return controller.close();
        chunkSize = r.chunk!.byteLength;
        controller.enqueue(r.chunk!);
      },
      cancel: (reason) => rpc.call<void>("relay.cancel", { id, reason: wireReason(reason) }),
    };
    this.#collected.register(source, id);
    // No queue of its own: the reads in flight are the stand-in's buffer.
    return new ReadableStream<Uint8Array>(source, { highWaterMark: 0 });
  }

  /** The peer's writable stream `ref`, written through the port. */
  writable({ relay: id }: StreamRef): WritableStream<Uint8Array> {
    const rpc = this.#rpc;
    const sink: UnderlyingSink<Uint8Array> = {
      write(chunk) {
        const bytes = ownBytes(chunk);
        return rpc.call<void>("relay.write", { id, chunk: bytes }, { transfer: [bytes.buffer as ArrayBuffer] });
      },
      close: () => rpc.call<void>("relay.close", { id }),
      abort: (reason) => rpc.call<void>("relay.abort", { id, reason: wireReason(reason) }),
    };
    this.#collected.register(sink, id);
    return new WritableStream<Uint8Array>(sink);
  }
}

const relays = new WeakMap<PortRpc, StreamRelay>();

/** The stream relay for `rpc`: one per port, so every user of the port shares its ids. */
export function streamRelay(rpc: PortRpc): StreamRelay {
  let relay = relays.get(rpc);
  if (!relay) relays.set(rpc, (relay = new StreamRelay(rpc)));
  return relay;
}
