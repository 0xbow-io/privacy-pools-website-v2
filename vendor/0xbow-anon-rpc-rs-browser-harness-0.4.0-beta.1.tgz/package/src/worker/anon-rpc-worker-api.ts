// Worker side of the capability API. Builds the `anonRpcWorker` object that
// untrusted worker code sees as its entire platform (§7). Every method is a thin
// proxy across the capability port; stream bytes (KPS streams and call
// bodies) cross through the stream relay.

import type {
  AnonRpcWorkerApi,
  FetchCall,
  IncomingCall,
  AnonFetchResponse,
  AnonRequestInit,
  HeaderList,
  KpsApi,
  KpsConn,
  KpsStream,
  KpsConnCloseInfo,
  KpsStreamCloseInfo,
  KpsReason,
  StorageApi,
  StorageKey,
  LogApi,
  LogArg,
  PlainValue,
} from "../spec-types.js";
import { CallQueue } from "@0xbow/anon-rpc-rs-harness-core";
import { PortRpc, abortError, serializeError } from "../protocol.js";
import { isStreamRef, streamRelay, type StreamRef } from "../stream-relay.js";

type StreamParts = {
  streamId: number;
  readable: StreamRef;
  writable: StreamRef;
};

type AcceptedCall = {
  callId: number;
  url: string;
  // WireRequestInit as it arrives: named, since AnonRequestInit's index
  // signature would swallow the members of an Omit<> of it.
  requestInit?: {
    method?: string;
    headers?: HeaderList;
    body?: Uint8Array | StreamRef;
    redirect?: AnonRequestInit["redirect"];
    hasSignal?: boolean;
    forwarded?: { [key: string]: PlainValue };
  };
};

export function makeWorkerApi(rpc: PortRpc, config?: PlainValue): AnonRpcWorkerApi {
  // AbortControllers for delivered calls; host emits "call-abort" when its
  // fetch caller aborts (the call's signal originates host-side). An abort can
  // race the acceptCall response across the port, so aborts for calls not yet
  // registered are remembered and applied on delivery.
  const callAborts = new Map<number, AbortController>();
  const preAborted = new Set<number>();
  rpc.onEvent("call-abort", ({ callId }: { callId: number }) => {
    const ac = callAborts.get(callId);
    if (ac) ac.abort(new DOMException("aborted", "AbortError"));
    else preAborted.add(callId);
  });

  // Close info is pushed by the host when the underlying stream/conn settles
  // (which is also when the host prunes its registries). It can arrive before
  // the answer that opened the stream or conn, so it waits for the proxy.
  function closeInfo<T>(event: string, key: "streamId" | "connId"): (id: number) => Promise<T> {
    const waiting = new Map<number, (info: T) => void>();
    const early = new Map<number, T>();
    rpc.onEvent(event, (msg: Record<string, unknown>) => {
      const id = msg[key] as number;
      const resolve = waiting.get(id);
      waiting.delete(id);
      if (resolve) resolve(msg.info as T);
      else early.set(id, msg.info as T);
    });
    return (id) =>
      new Promise<T>((resolve) => {
        if (!early.has(id)) return void waiting.set(id, resolve);
        resolve(early.get(id)!);
        early.delete(id);
      });
  }
  const streamClosed = closeInfo<KpsStreamCloseInfo>("stream.closed", "streamId");
  const connClosed = closeInfo<KpsConnCloseInfo>("conn.closed", "connId");

  function makeStream(p: StreamParts): KpsStream {
    const closed = streamClosed(p.streamId);
    return {
      readable: streamRelay(rpc).readable(p.readable),
      writable: streamRelay(rpc).writable(p.writable),
      closeWrite: () => rpc.call("stream.closeWrite", { streamId: p.streamId }),
      cancelRead: (reason?: KpsReason) => rpc.call("stream.cancelRead", { streamId: p.streamId, reason }),
      resetWrite: (reason?: KpsReason) => rpc.call("stream.resetWrite", { streamId: p.streamId, reason }),
      close: (reason?: KpsReason) => rpc.call("stream.close", { streamId: p.streamId, reason }),
      closed,
    };
  }

  // A stream or conn the host opened after the worker gave up on it is closed,
  // or the host would hold it until the worker ends.
  function dropStream(parts: unknown): void {
    const s = makeStream(parts as StreamParts);
    void s.readable.cancel().catch(() => {});
    void s.writable.abort().catch(() => {});
    void s.close().catch(() => {});
  }
  function dropConn(opened: unknown): void {
    const { connId } = opened as { connId: number };
    void connClosed(connId); // takes the close info, so none is left waiting
    void rpc.call("conn.close", { connId }).catch(() => {});
  }
  const opening = (opts: { signal?: AbortSignal } | undefined, onLate: (value: unknown) => void) =>
    opts?.signal ? { signal: opts.signal, onLate } : undefined;

  function makeConn(connId: number, remoteAddress: { ip: string; port: number }): KpsConn {
    const closed = connClosed(connId);
    return {
      remoteAddress,
      openStream: async (opts) =>
        makeStream(await rpc.call<StreamParts>("conn.openStream", { connId }, opening(opts, dropStream))),
      acceptStream: async (opts) =>
        makeStream(await rpc.call<StreamParts>("conn.acceptStream", { connId }, opening(opts, dropStream))),
      close: (reason?: KpsReason) => rpc.call("conn.close", { connId, reason }),
      sendDatagram: (data, opts) => rpc.call("conn.sendDatagram", { connId, data }, sigOpt(opts)),
      receiveDatagram: (opts) => rpc.call<Uint8Array>("conn.receiveDatagram", { connId }, sigOpt(opts)),
      closed,
    };
  }

  // `hasSignal` tells the host whether this dial has a deadline of the
  // worker's own. The host's side of the call always has a signal, and the
  // kps client treats any signal as replacing its default dial timeout.
  const kps: KpsApi = {
    dial: async (addr, opts) => {
      const { connId, remoteAddress } = await rpc.call<{
        connId: number;
        remoteAddress: { ip: string; port: number };
      }>("kps.dial", { addr, hasSignal: !!opts?.signal }, opening(opts, dropConn));
      return makeConn(connId, remoteAddress);
    },
    openStream: async (addr, opts) =>
      makeStream(
        await rpc.call<StreamParts>("kps.openStream", { addr, hasSignal: !!opts?.signal }, opening(opts, dropStream)),
      ),
  };

  const storage = storageApi(rpc);

  const log: LogApi = {
    debug: (...args: LogArg[]) => rpc.emit("log", { level: "debug", args }),
    info: (...args: LogArg[]) => rpc.emit("log", { level: "info", args }),
    warn: (...args: LogArg[]) => rpc.emit("log", { level: "warn", args }),
    error: (...args: LogArg[]) => rpc.emit("log", { level: "error", args }),
  };

  // acceptCall abort handling lives HERE, not at the RPC layer: a transport-
  // level abort can lose the race with delivery, in which case the host has
  // already consumed a call from its queue and the res is silently dropped —
  // the call would be lost (§8 forbids that). Instead every host request runs
  // to completion, and what it delivers goes to the oldest acceptCall still
  // waiting, or is kept for the next one. The call stays on this side: its
  // body has already crossed the port: a transferred buffer cannot cross it
  // again, and a relayed stream is read from this side alone.
  const delivered = new CallQueue<AcceptedCall>();

  function acceptCall(opts?: { signal?: AbortSignal }): Promise<IncomingCall> {
    const signal = opts?.signal;
    if (signal?.aborted) return Promise.reject(signal.reason ?? new DOMException("aborted", "AbortError"));
    if (delivered.size === 0) {
      rpc.call<AcceptedCall>("acceptCall", {}).then(
        (r) => delivered.push(r),
        (e) => delivered.rejectNext(e),
      );
    }
    return delivered
      .take(signal)
      .then((r) => makeFetchCall(rpc, callAborts, preAborted, r.callId, r.url, r.requestInit));
  }

  return {
    signalReady: () => rpc.emit("ready", {}),
    // Failure finality (§7: later signals ignored) is enforced host-side —
    // #fail is one-shot and resolving an already-rejected ready is a no-op.
    signalFailed: (reason?: { code?: string; message?: string }) =>
      rpc.emit("failed", { reason }),
    acceptCall,
    config,
    kps,
    storage,
    log,
  };
}

function makeFetchCall(
  rpc: PortRpc,
  callAborts: Map<number, AbortController>,
  preAborted: Set<number>,
  callId: number,
  url: string,
  wireInit?: AcceptedCall["requestInit"],
): FetchCall {
  let requestInit: AnonRequestInit | undefined;
  if (wireInit) {
    // §9.1: forwarded entries sit beside the modeled fields, under their own
    // keys (never a modeled one — the host excluded those). Spread defines
    // properties, so a forwarded "__proto__" stays an own key.
    const { hasSignal, body, forwarded, ...wire } = wireInit;
    const rest: AnonRequestInit = { ...forwarded, ...wire };
    if (body !== undefined) rest.body = isStreamRef(body) ? streamRelay(rpc).readable(body) : body;
    requestInit = rest;
    if (hasSignal) {
      const ac = new AbortController();
      callAborts.set(callId, ac);
      requestInit = { ...requestInit, signal: ac.signal };
      // The host's abort may have crossed the port before this call arrived.
      if (preAborted.delete(callId)) ac.abort(new DOMException("aborted", "AbortError"));
    }
  }

  let responded = false;
  return {
    kind: "fetch",
    url,
    ...(requestInit ? { requestInit } : {}),
    respond(response: AnonFetchResponse | Promise<AnonFetchResponse>) {
      if (responded) throw new Error("respond() called more than once");
      responded = true;
      Promise.resolve(response)
        .then((r) => {
          // respond() hands the body off: a stream is read through the relay,
          // and a Uint8Array's buffer is transferred (a multi-MB response must
          // not be structured-cloned). Worker code must not reuse the buffer
          // after responding with it.
          if (r.body instanceof ReadableStream) {
            const response = { ...r, body: streamRelay(rpc).sendReadable(r.body) };
            return rpc.call("respond", { callId, ok: true, response });
          }
          const transfer = r.body instanceof Uint8Array ? [r.body.buffer as unknown as Transferable] : [];
          return rpc.call("respond", { callId, ok: true, response: r }, { transfer });
        })
        .catch((e: unknown) =>
          // Carry name/code and the error's plain-valued details across the
          // boundary (§8, §12): host logic may branch on those, never on
          // message text.
          rpc.call("respond", { callId, ok: false, error: serializeError(e, true) }),
        )
        .catch(() => {}) // the failure respond itself may be refused (e.g. call already aborted)
        .finally(() => callAborts.delete(callId));
    },
  };
}

/** The most keys one read-ahead fetches. */
export const READ_AHEAD_MAX = 256;

/** How long a value read ahead may wait for its get before it is dropped. */
export const READ_AHEAD_TTL_MS = 5_000;

/**
 * §11 storage over the capability port, with read-ahead for a worker that
 * reads back the keys it listed, in order, one get at a time.
 *
 * tor-js loads its stored directory that way: about 7,500 keys, at one round
 * trip each, took 22 to 25 s on Android Chrome, longer than downloading the
 * directory again. A get of the key that follows the previous get in the
 * latest listing also fetches the keys after it, in one `storage.getMany`,
 * and the window doubles while reads keep following the listing, up to
 * READ_AHEAD_MAX keys. A read out of that order costs one get, as before, and
 * resets the window, so a worker that reads few or scattered keys fetches
 * little it does not use.
 *
 * Values read ahead are a snapshot, and at most one window is held. Every
 * write from this worker drops them first, so it always reads its own
 * writes; a get of a key not held drops the rest; and one not read within
 * READ_AHEAD_TTL_MS is read again, so a write from another worker sharing
 * the namespace is not hidden for longer than that.
 */
function storageApi(rpc: PortRpc): StorageApi {
  type Ahead = { value: Promise<Uint8Array | undefined>; batch: Promise<unknown>; at: number };
  let listing: { keys: StorageKey[]; index: Map<StorageKey, number> } | undefined;
  // Position in `listing` of the latest get of a listed key.
  let last = -1;
  let window = 1;
  const ahead = new Map<StorageKey, Ahead>();

  function get(key: StorageKey, opts?: { signal?: AbortSignal }): Promise<Uint8Array | undefined> {
    const now = performance.now();
    const hit = ahead.get(key);
    if (hit) {
      ahead.delete(key);
      if (now - hit.at <= READ_AHEAD_TTL_MS) {
        last = listing?.index.get(key) ?? -1;
        return untilAborted(hit.value, opts?.signal);
      }
    }
    // A miss starts a new window, so the values left from the last are ones
    // the reader skipped: dropping them keeps at most one window held.
    ahead.clear();
    const i = listing?.index.get(key);
    if (i === undefined || i !== last + 1) {
      if (i !== undefined) last = i;
      window = 1;
      return rpc.call("storage.get", { key }, sigOpt(opts));
    }
    last = i;
    window = Math.min(window * 2, READ_AHEAD_MAX);
    const keys = listing!.keys.slice(i, i + window);
    const batch = rpc.call<(Uint8Array | undefined)[]>("storage.getMany", { keys });
    keys.forEach((k, j) => {
      if (j === 0) return;
      const value = batch.then((values) => values[j]);
      // Only a get that takes the value reports a failure, not the batch.
      value.catch(() => {});
      ahead.set(k, { value, batch, at: now });
    });
    batch.catch(() => {
      for (const k of keys) if (ahead.get(k)?.batch === batch) ahead.delete(k);
    });
    return untilAborted(
      batch.then((values) => values[0]),
      opts?.signal,
    );
  }

  // Dropped before the write is sent, so no later get can see an older value.
  const writing = <T>(send: () => Promise<T>): Promise<T> => {
    ahead.clear();
    return send();
  };

  async function* list(opts?: { prefix?: string; signal?: AbortSignal }): AsyncIterable<StorageKey> {
    const keys = await rpc.call<StorageKey[]>("storage.list", { prefix: opts?.prefix }, sigOpt(opts));
    listing = { keys, index: new Map(keys.map((k, i) => [k, i])) };
    last = -1;
    window = 1;
    ahead.clear();
    for (const k of keys) yield k;
  }

  return {
    get,
    set: (key, value, opts) => writing(() => rpc.call("storage.set", { key, value }, sigOpt(opts))),
    delete: (key, opts) => writing(() => rpc.call("storage.delete", { key }, sigOpt(opts))),
    has: (key, opts) => rpc.call("storage.has", { key }, sigOpt(opts)),
    clear: (opts) => writing(() => rpc.call("storage.clear", { prefix: opts?.prefix }, sigOpt(opts))),
    list,
  };
}

// A value shared with other gets, which one caller's abort must not cancel.
function untilAborted<T>(value: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return value;
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(abortError());
    signal.addEventListener("abort", onAbort, { once: true });
    // Settling after an abort is a no-op, and handles a rejection nothing else awaits.
    value.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
    if (signal.aborted) onAbort();
  });
}

function sigOpt(opts?: { signal?: AbortSignal }): { signal?: AbortSignal } | undefined {
  return opts?.signal ? { signal: opts.signal } : undefined;
}
