// Combining abort signals.

/**
 * A signal that aborts with the reason of the first of `signals` to abort, or
 * with a TimeoutError after `timeoutMs`.
 *
 * `AbortSignal.any` and `AbortSignal.timeout` would do this, but need Chrome
 * 116, Firefox 124 and Safari 17.4, above the harness's floor of Chrome 100,
 * Firefox 100 and Safari 15.4 (README). `release` detaches the combined
 * signal from its inputs and stops the timer; call it once the work it guards
 * has settled, so a long-lived input (a worker's lifetime) does not collect
 * one listener per call.
 */
export function combineSignals(
  signals: AbortSignal[],
  timeoutMs?: number,
): { signal: AbortSignal; release: () => void } {
  const ac = new AbortController();
  const detach: (() => void)[] = [];
  const release = () => {
    for (const d of detach.splice(0)) d();
  };
  const abort = (reason: unknown) => {
    release();
    ac.abort(reason);
  };
  for (const s of signals) {
    if (s.aborted) {
      abort(s.reason);
      return { signal: ac.signal, release };
    }
    const onAbort = () => abort(s.reason);
    s.addEventListener("abort", onAbort, { once: true });
    detach.push(() => s.removeEventListener("abort", onAbort));
  }
  if (timeoutMs !== undefined) {
    const timer = setTimeout(() => abort(new DOMException("signal timed out", "TimeoutError")), timeoutMs);
    detach.push(() => clearTimeout(timer));
  }
  return { signal: ac.signal, release };
}
