// What ReplacingWorker and WorkerPool share about a call: copying its init,
// following its abort, naming its host, tracking its body, and the errors and
// option checks the crate's pools also apply.

import { RpcError } from "@0xbow/anon-rpc-rs-harness-core";

// `response`, calling `done` once its body has been read, has failed, or was
// cancelled, or at once when it has none: closing a worker would end a body
// still arriving (§9.2).
export function readTracked(response: Response, done: () => void): Response {
  const source = response.body;
  if (!source) {
    done();
    return response;
  }
  const reader = source.getReader();
  let open = true;
  const finish = () => {
    if (open) {
      open = false;
      done();
    }
  };
  const body = new ReadableStream<Uint8Array>({
    pull: async (controller) => {
      try {
        const chunk = await reader.read();
        if (chunk.done) {
          finish();
          controller.close();
        } else controller.enqueue(chunk.value);
      } catch (e) {
        finish();
        controller.error(e);
      }
    },
    cancel: (reason) => {
      finish();
      return reader.cancel(reason);
    },
  });
  const tracked = new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers });
  if (response.url) Object.defineProperty(tracked, "url", { value: response.url });
  return tracked;
}

/** A deadline `name` in milliseconds: absent, or finite and not negative. */
export function checkDeadline(name: string, ms: number | undefined): void {
  if (ms !== undefined && !(Number.isFinite(ms) && ms >= 0)) {
    throw unsupported(`${name} must be a number of milliseconds, not negative`);
  }
}

export function unsupported(message: string): RpcError {
  return new RpcError({ name: "RpcError", message, code: "unsupported" });
}

export function closedError(): RpcError {
  return new RpcError({ name: "Error", message: "worker closed", code: "closed" });
}

// The authority of an absolute URL, without its userinfo: what calls to one
// endpoint share; the whole URL when it has none, as the crate's host_of
// takes it. Parsed by hand, since React Native's URL lacks `host`.
export function hostOf(input: RequestInfo | URL): string {
  const url = typeof input === "string" ? input : "href" in input ? input.href : input.url;
  const authority = /^[a-z][a-z0-9+.-]*:\/\/([^/?#]*)/i.exec(url)?.[1];
  if (authority === undefined) return url.toLowerCase();
  return authority.slice(authority.lastIndexOf("@") + 1).toLowerCase();
}

// The route a call goes over, for route health: its `anonOptions.isolationKey`
// (§9.3) when that is a string, as the crate's route_of takes it, and the
// route of calls without a key otherwise. The worker judges the key.
export function isolationKeyOf(init: RequestInit | undefined): string | undefined {
  const key = (init as { anonOptions?: { isolationKey?: unknown } } | undefined)?.anonOptions?.isolationKey;
  return typeof key === "string" ? key : undefined;
}
