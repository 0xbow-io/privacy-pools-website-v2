// When a worker's route has stopped carrying calls, by the rule SPEC.md §5.1
// states and the anon-rpc crate applies to the native lanes.

export type Outcome = "answered" | "failed" | "exit-failure" | "timeout" | "abandoned";

/** One route's calls since the worker started. */
type Route = { waiting: Map<string, number>; failedHosts: Set<string>; failures: number; answers: number };

/**
 * Whether one of a worker's routes has stopped carrying calls. A call's route
 * is its `anonOptions.isolationKey` (§9.3), or the one route of calls without
 * a key: a worker that isolates by key keeps a route per key, and one key's
 * route can stop carrying calls while the others answer.
 *
 * A route has stopped when a call on it has failed with none on it answering
 * since (the second such failure, once the worker has answered on any route),
 * and either no call on it to another host is still waiting or the failure is
 * a timeout during which no call on it answered. A host that fails while
 * another may still answer is that endpoint's problem, not the route's, and
 * replacing the worker would cut off the calls that work. A route that
 * answered nothing for a whole call deadline has shown that no host still
 * answers; waiting on calls to hosts first tried during it would only put the
 * replacement off by a deadline per new host.
 *
 * An exit failure on a keyed route counts for nothing: the exit failed, not
 * the route, and the host moves the key (§9.3), as Tor moves a stream to a
 * new circuit. Without a key it counts as a failure.
 */
export function routeHealth() {
  const routes = new Map<string | undefined, Route>();
  let answered = false;
  const routeOf = (key: string | undefined): Route => {
    let route = routes.get(key);
    if (!route) routes.set(key, (route = { waiting: new Map(), failedHosts: new Set(), failures: 0, answers: 0 }));
    return route;
  };
  return {
    /** One call to `host` on route `key` has been sent; pass the result to `settled`. */
    sent(host: string, key?: string): number {
      const route = routeOf(key);
      route.waiting.set(host, (route.waiting.get(host) ?? 0) + 1);
      return route.answers;
    },
    /** One call has finished; true when the worker should be replaced. */
    settled(host: string, outcome: Outcome, answersAtSend: number, key?: string): boolean {
      const route = routeOf(key);
      const left = (route.waiting.get(host) ?? 1) - 1;
      if (left > 0) route.waiting.set(host, left);
      else route.waiting.delete(host);
      const replace = judge(route, host, outcome, key !== undefined, answersAtSend);
      // A route with nothing pending and nothing against it holds no state, so
      // one key per call does not grow the map.
      if (route.waiting.size === 0 && route.failures === 0) routes.delete(key);
      return replace;
    },
  };

  function judge(route: Route, host: string, outcome: Outcome, keyed: boolean, answersAtSend: number): boolean {
    if (outcome === "abandoned" || (outcome === "exit-failure" && keyed)) return false;
    if (outcome === "answered") {
      answered = true;
      route.answers++;
      route.failures = 0;
      route.failedHosts.clear();
      return false;
    }
    route.failures++;
    route.failedHosts.add(host);
    if (route.failures < (answered ? 2 : 1)) return false;
    if (outcome === "timeout" && route.answers === answersAtSend) return true;
    return [...route.waiting.keys()].every((other) => route.failedHosts.has(other));
  }
}
