// The published workers a host can select by name: adopters.json5's entries,
// as data. The harness stays provider-agnostic; it runs whatever a specifier
// pins, and nothing here changes how a worker boots. What this adds is the two
// facts a host gets wrong by hand: which address, and which chain to read it
// on. test/known-workers.test.ts holds the list to adopters.json5.

import type { PlainValue, RpcProvider, WorkerInit } from "../spec-types.js";

export type KnownWorkerId = "passthrough" | "tor-js" | "nym" | "nox";

export type KnownWorker = {
  readonly id: KnownWorkerId;
  /** "Name: tagline", as adopters.json5 writes it. */
  readonly label: string;
  /** "network" anonymizes; "reference" only demonstrates the mechanism. */
  readonly kind: "network" | "reference";
  /** The specifier contract's address. */
  readonly specifier: string;
  /**
   * The chain the specifier contract is published on, so the chain the
   * bootstrap `rpcProvider` must answer for. It does not limit which chain
   * the worker's anonymized fetches can reach.
   */
  readonly specifierChainId: number;
  /** The `config` keys the worker cannot start without. None has a default. */
  readonly requiredConfig: readonly string[];
  /**
   * Whether the pinned bundle keeps calls under different
   * `anonOptions.isolationKey` values (§9.3) on separate routes, so one worker
   * can carry several identities. Otherwise each needs a worker of its own,
   * such as a `WorkerPool` group.
   */
  readonly isolatesByKey: boolean;
};

const ENTRIES: KnownWorker[] = [
  {
    id: "passthrough",
    label: "Passthrough: plain fetch (no anonymization)",
    kind: "reference",
    specifier: "0x4fd77be300f31c5fe6ab266d35d27750a3478d27",
    specifierChainId: 1,
    requiredConfig: [],
    isolatesByKey: false,
  },
  {
    id: "tor-js",
    label: "tor-js: fetch over Tor",
    kind: "network",
    specifier: "0x700dA3193D35fA54Cd3fBf29B66f2a2A0385659e",
    specifierChainId: 1,
    // The KPS gateways Tor traffic leaves the browser through. The one in
    // adopters.json5 is a demonstration gateway, so it is not a default.
    requiredConfig: ["gateways"],
    isolatesByKey: true,
  },
  {
    id: "nym",
    label: "Nym: fetch over the Nym mixnet",
    kind: "network",
    specifier: "0x3aCD9742C68F6d993066Ae25533e09b9e1f60eD0",
    specifierChainId: 1,
    requiredConfig: [],
    isolatesByKey: false,
  },
  {
    id: "nox",
    label: "Nox: fetch over a Sphinx mixnet",
    kind: "network",
    specifier: "0x35133267A8F7EC35046a83DCA0f4Ca8A6e1b7A9A",
    specifierChainId: 11155111,
    requiredConfig: [],
    isolatesByKey: false,
  },
];

/** Frozen, entries and their key lists included: a host cannot repoint one. */
export const KNOWN_WORKERS: readonly KnownWorker[] = Object.freeze(
  ENTRIES.map((w) => Object.freeze({ ...w, requiredConfig: Object.freeze([...w.requiredConfig]) })),
);

/** The known worker `id`; a RangeError for any other name. */
export function knownWorker(id: KnownWorkerId): KnownWorker {
  const w = KNOWN_WORKERS.find((k) => k.id === id);
  if (!w) {
    throw new RangeError(`unknown worker "${id}"; known: ${KNOWN_WORKERS.map((k) => k.id).join(", ")}`);
  }
  return w;
}

export type KnownWorkerOptions = {
  /** Reads the specifier, as `preExisting.rpcProvider`; it must answer for the specifier's chain. */
  rpcProvider: RpcProvider;
  /** The worker's own config (§7.1, a §9.4 plain value), including any key it requires. */
  config?: PlainValue;
  iframeUrl?: string;
};

/**
 * The `WorkerInit` for a known worker: its address, the chain to check the
 * bootstrap provider against, and the caller's config, which must carry every
 * key the worker requires (a TypeError otherwise, before anything boots).
 */
export function knownWorkerInit(id: KnownWorkerId, opts: KnownWorkerOptions): WorkerInit {
  const w = knownWorker(id);
  for (const key of w.requiredConfig) {
    const value = (opts.config as Record<string, unknown> | undefined)?.[key];
    if (value === undefined || value === null || (Array.isArray(value) && value.length === 0)) {
      throw new TypeError(`the ${id} worker needs config.${key}, and there is no default`);
    }
  }
  return {
    address: w.specifier,
    specifierChainId: w.specifierChainId,
    ...(opts.config === undefined ? {} : { config: opts.config }),
    ...(opts.iframeUrl === undefined ? {} : { iframeUrl: opts.iframeUrl }),
    preExisting: { rpcProvider: opts.rpcProvider },
  };
}
