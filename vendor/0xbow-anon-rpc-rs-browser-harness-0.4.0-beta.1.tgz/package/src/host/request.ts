// Normalizes the host's `fetch(input, init)` arguments (§5: `fetch: typeof
// fetch`) into the wire shape sent to the worker (§9.1), plus the transfer
// list for its byte buffers and the effective abort signal, and builds the
// host's Response from the worker's answer (§9.2). The platform's Request
// validates the call as fetch would. A stream body stays a stream here; it
// crosses through the stream relay when the worker takes the call. The
// extension harness imports this module as `./request`.

import type { AnonFetchResponse, AnonRequestInit, HeaderList, PlainValue } from "../spec-types.js";
import { MODELED_INIT_KEYS, copyForwardedEntries } from "@0xbow/anon-rpc-rs-harness-core";

export type WireRequestInit = {
  method?: string;
  headers?: HeaderList;
  body?: Uint8Array | ReadableStream<Uint8Array>;
  redirect?: AnonRequestInit["redirect"];
  // The signal itself cannot cross the port; the worker reconstructs one and
  // the host drives it via "call-abort" events.
  hasSignal?: boolean;
  // §9.1 forwarded entries, already §9.4 copies. Kept apart from the fields
  // above so a host key such as "hasSignal" cannot collide with the wire's
  // own; the worker spreads them into requestInit.
  forwarded?: { [key: string]: PlainValue };
};

export type NormalizedRequest = {
  url: string;
  requestInit?: WireRequestInit;
  transfer?: Transferable[];
  signal?: AbortSignal;
};

/**
 * `init` as it is now: the members §9.1 models as they are, and §9.4 copies of
 * its forwarded entries, so a call held until its worker is ready is the call
 * the host made. A forwarded entry that is not plain throws a TypeError.
 */
export function initNow(init: RequestInit): RequestInit {
  return { ...copyForwardedEntries(init), ...modeled(init) };
}

/** The members of `init` that §9.1 models, each read once. */
function modeled(init: RequestInit): RequestInit {
  const now: Record<string, unknown> = {};
  for (const key of MODELED_INIT_KEYS) {
    const value = (init as Record<string, unknown>)[key];
    if (value !== undefined) now[key] = value;
  }
  return now as RequestInit;
}

export async function normalizeRequest(input: RequestInfo | URL, init?: RequestInit): Promise<NormalizedRequest> {
  // Before any await: §9.1 copies forwarded values when fetch is called, so a
  // host mutating them afterwards cannot change the call. Each member is read
  // once: a getter must give the worker what the Request was built from.
  const forwarded = init && copyForwardedEntries(init);
  const opts = init && modeled(init);
  const stream = opts?.body instanceof ReadableStream ? (opts.body as ReadableStream<Uint8Array>) : undefined;
  if (stream?.locked) throw new TypeError("the body stream is locked");
  // A Request input whose body init does not replace.
  const inputBody = input instanceof Request && opts?.body == null;
  // As fetch does: a body already read, or a stream someone holds, cannot be
  // sent. Caught here, it fails the call; caught at transfer, it would fail
  // only after the worker took the call, leaving it unanswered.
  if (inputBody && (input.bodyUsed || input.body?.locked)) {
    throw new TypeError("the Request's body has already been used");
  }
  // The Request validates method, URL, headers and redirect as fetch does,
  // and refuses a GET or HEAD body. A stream body stays out of it, so that it
  // is forwarded rather than taken: an empty one stands in, which replaces a
  // Request input's body as the stream does. So does the signal, whose abort
  // path the caller of this owns.
  const req =
    input instanceof Request && !opts
      ? input
      : new Request(input, { ...opts, signal: undefined, ...(stream ? { body: new Uint8Array(0) } : {}) });
  const signal =
    opts && "signal" in opts ? (opts.signal ?? undefined) : input instanceof Request ? input.signal : undefined;

  const headers: HeaderList = [];
  req.headers.forEach((v, k) => headers.push([k, v]));
  // The Request drops headers a page may not set (Cookie, Origin, Referer…).
  // The worker is not a page, so the caller's own pass too.
  for (const [k, v] of headersToList(opts?.headers)) {
    if (!req.headers.has(k)) headers.push([k.toLowerCase(), v]);
  }

  const transfer: Transferable[] = [];
  let body: WireRequestInit["body"];
  if (stream) {
    body = stream;
  } else if (inputBody && req.body) {
    // A Request input's body is a stream: kept as one for the relay.
    body = req.body;
  } else if (req.method !== "GET" && req.method !== "HEAD") {
    // Read whole, as fetch would send it; an engine without Request body
    // streams (Firefox) has no `body` to forward either.
    const bytes = new Uint8Array(await req.arrayBuffer());
    if (bytes.byteLength) {
      body = bytes;
      transfer.push(bytes.buffer as ArrayBuffer);
    }
  }

  const requestInit: WireRequestInit = {};
  if (req.method !== "GET") requestInit.method = req.method;
  if (headers.length) requestInit.headers = headers;
  if (body !== undefined) requestInit.body = body;
  if (req.redirect !== "follow") requestInit.redirect = req.redirect;
  if (signal) requestInit.hasSignal = true;
  if (forwarded) requestInit.forwarded = forwarded;
  return {
    url: req.url,
    ...(Object.keys(requestInit).length ? { requestInit } : {}),
    transfer,
    signal,
  };
}

/** Header entries from any `HeadersInit`, converted as Headers converts them, unfiltered. */
export function headersToList(h: HeadersInit | undefined): HeaderList {
  const out: HeaderList = [];
  if (!h) return out;
  if (h instanceof Headers) h.forEach((v, k) => out.push([k, v]));
  else if (Array.isArray(h)) for (const [k, v] of h) out.push([String(k), String(v)]);
  else for (const [k, v] of Object.entries(h)) out.push([k, String(v)]);
  return out;
}

/** The host's Response for a worker's answer (§9.2). Throws as the Response constructor does for a status outside 200 to 599. */
export function toResponse(r: Omit<AnonFetchResponse, "body"> & { body: AnonFetchResponse["body"] | null }): Response {
  const headers = new Headers();
  for (const [k, v] of r.headers) headers.append(k, v);
  const status = r.status;
  // 204/205/304 must have a null body; a stream sent anyway is not read.
  const nullBody = status === 204 || status === 205 || status === 304;
  if (nullBody && r.body instanceof ReadableStream) void r.body.cancel().catch(() => {});
  const body = nullBody ? null : (r.body as BodyInit | null);
  const resp = new Response(body, { status, headers });
  // Response.url is read-only and unset by the constructor; surface the
  // worker-reported post-redirect URL (§9.2) by shadowing the getter.
  if (r.url) Object.defineProperty(resp, "url", { value: r.url });
  return resp;
}
