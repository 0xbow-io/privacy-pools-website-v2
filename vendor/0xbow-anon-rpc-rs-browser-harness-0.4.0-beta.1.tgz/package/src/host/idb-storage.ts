// §11 storage backend.
//
// Storage is implemented on the HOST side: the worker's null-origin iframe has
// no storage of its own (that is the isolation working as intended), so every
// operation crosses the capability port to here. Persistent via IndexedDB on
// the host origin, with records keyed [specifierAddress, storageKey] so each
// worker is confined to its own namespace (§11). Falls back to an in-memory
// backend where IndexedDB is unavailable (e.g. non-browser tests).

export interface StorageBackend {
  get(address: string, key: string): Promise<Uint8Array | undefined>;
  /** The values of `keys`, in order, `undefined` for each absent key. */
  getMany(address: string, keys: readonly string[]): Promise<(Uint8Array | undefined)[]>;
  set(address: string, key: string, value: Uint8Array): Promise<void>;
  delete(address: string, key: string): Promise<void>;
  has(address: string, key: string): Promise<boolean>;
  listKeys(address: string, prefix?: string): Promise<string[]>;
  clear(address: string, prefix?: string): Promise<void>;
  /** Release the backend once operations already begun have finished, when it resolves. */
  close(): Promise<void>;
}

const DB_NAME = "anon-rpc-harness";
const STORE_NAME = "kv";

export function openStorageBackend(): Promise<StorageBackend> {
  if (typeof indexedDB === "undefined") {
    return Promise.resolve(new MemoryBackend());
  }
  return IdbBackend.open();
}

/**
 * `base` as a worker without its namespace's lock sees it, as tor-js's
 * `addLocking` gives a contender: its own writes and deletions stay in memory
 * over the stored values, so two workers on one namespace never overwrite
 * each other's state.
 */
export function privateOverlay(base: StorageBackend): StorageBackend {
  // Per address, each key this worker wrote, or null once it deleted it.
  const spaces = new Map<string, Map<string, Uint8Array | null>>();
  const own = (address: string) => {
    let m = spaces.get(address);
    if (!m) spaces.set(address, (m = new Map()));
    return m;
  };
  const listKeys = async (address: string, prefix = "") => {
    const mine = own(address);
    const keys = new Set((await base.listKeys(address, prefix)).filter((k) => !mine.has(k)));
    for (const [k, v] of mine) if (v && k.startsWith(prefix)) keys.add(k);
    return [...keys].sort();
  };
  return {
    // Copies, as IndexedDB's are: the host transfers what getMany returns.
    get: async (address, key) => (own(address).has(key) ? own(address).get(key)?.slice() : base.get(address, key)),
    async getMany(address, keys) {
      const mine = own(address);
      const unwritten = keys.filter((k) => !mine.has(k));
      const values = await base.getMany(address, unwritten);
      const stored = new Map(unwritten.map((k, i) => [k, values[i]]));
      return keys.map((k) => (mine.has(k) ? mine.get(k)?.slice() : stored.get(k)));
    },
    set: async (address, key, value) => void own(address).set(key, value),
    delete: async (address, key) => void own(address).set(key, null),
    has: async (address, key) => (own(address).has(key) ? own(address).get(key) != null : base.has(address, key)),
    listKeys,
    async clear(address, prefix) {
      for (const k of await listKeys(address, prefix)) own(address).set(k, null);
    },
    close: () => base.close(),
  };
}

function req<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

// One operation's part of a shared transaction. `start` issues its requests
// against the transaction's store and settles the operation as they succeed
// or fail, as a transaction per operation did; one the transaction's abort
// overtakes fails with it. A cursor walk issues each step's request as the
// previous one succeeds, after requests queued behind it, so it runs `alone`
// in its own transaction.
type Op = {
  write: boolean;
  alone: boolean;
  start(store: IDBObjectStore): void;
  fail(error: unknown): void;
};

// A request whose failure fails only its own operation: preventDefault keeps
// the error from aborting the transaction the other operations share.
function onRequest<T>(r: IDBRequest<T>, success: (result: T) => void, fail: (error: unknown) => void): void {
  r.onsuccess = () => success(r.result);
  r.onerror = (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    fail(r.error);
  };
}

/**
 * IndexedDB storage that serves operations in batches. Operations queue in
 * the order they arrive, and every operation queued while a transaction runs
 * goes into the next one, readwrite if any of them writes; a listing or a
 * clear, which walks a cursor, gets one to itself. Order is the arrival
 * order, as it is with a transaction per operation, since IndexedDB runs
 * overlapping transactions in the order they were created.
 *
 * A transaction per operation costs about 3 ms on Android Chrome. A worker
 * that reads or writes a few thousand keys at once, such as tor-js storing or
 * loading its directory, spent 20 s or more on that alone.
 */
class IdbBackend implements StorageBackend {
  #db: IDBDatabase;
  #queue: Op[] = [];
  #running = false;
  #closing = false;
  // Resolves close() once the queue has run out.
  #drained?: () => void;

  private constructor(db: IDBDatabase) {
    this.#db = db;
  }

  static async open(): Promise<IdbBackend> {
    const open = indexedDB.open(DB_NAME, 1);
    open.onupgradeneeded = () => {
      open.result.createObjectStore(STORE_NAME);
    };
    return new IdbBackend(await req(open));
  }

  get(address: string, key: string): Promise<Uint8Array | undefined> {
    return this.#run(false, (store, done, fail) => onRequest(store.get([address, key]), done, fail));
  }

  getMany(address: string, keys: readonly string[]): Promise<(Uint8Array | undefined)[]> {
    return this.#run(false, (store, done, fail) => {
      const values: (Uint8Array | undefined)[] = new Array(keys.length);
      let left = keys.length;
      if (left === 0) return done(values);
      keys.forEach((key, i) =>
        onRequest(
          store.get([address, key]),
          (value: Uint8Array | undefined) => {
            values[i] = value;
            if (--left === 0) done(values);
          },
          fail,
        ),
      );
    });
  }

  set(address: string, key: string, value: Uint8Array): Promise<void> {
    return this.#run(true, (store, done, fail) => onRequest(store.put(value, [address, key]), () => done(undefined), fail));
  }

  delete(address: string, key: string): Promise<void> {
    return this.#run(true, (store, done, fail) => onRequest(store.delete([address, key]), () => done(undefined), fail));
  }

  has(address: string, key: string): Promise<boolean> {
    return this.#run(false, (store, done, fail) =>
      onRequest(store.getKey([address, key]), (found) => done(found !== undefined), fail),
    );
  }

  listKeys(address: string, prefix = ""): Promise<string[]> {
    return this.#run(false, (store, done, fail) => {
      const keys: string[] = [];
      this.#walk(store.openKeyCursor(IDBKeyRange.lowerBound([address, prefix])), address, prefix, (cursor) => {
        keys.push((cursor.key as [string, string])[1]);
      }, () => done(keys), fail);
    }, true);
  }

  clear(address: string, prefix = ""): Promise<void> {
    // clear() needs value cursors: key cursors cannot delete().
    return this.#run(true, (store, done, fail) => {
      this.#walk(store.openCursor(IDBKeyRange.lowerBound([address, prefix])), address, prefix, (cursor) => {
        cursor.delete();
      }, () => done(undefined), fail);
    }, true);
  }

  // Walk the [address, prefix…] key range. The walk starts at the range's
  // lower bound and stops manually at the first key past the namespace or
  // prefix — exact for any key string, unlike the `prefix + "￿"` upper-
  // bound trick.
  #walk<C extends IDBCursor>(
    r: IDBRequest<C | null>,
    address: string,
    prefix: string,
    visit: (cursor: C) => void,
    end: () => void,
    fail: (error: unknown) => void,
  ): void {
    onRequest(r, (cursor) => {
      if (!cursor) return end();
      const [addr, key] = cursor.key as [string, string];
      if (addr !== address || !key.startsWith(prefix)) return end();
      visit(cursor);
      cursor.continue();
    }, fail);
  }

  #run<T>(
    write: boolean,
    start: (store: IDBObjectStore, done: (value: T) => void, fail: (error: unknown) => void) => void,
    alone = false,
  ): Promise<T> {
    if (this.#closing) return Promise.reject(new DOMException("The storage backend is closed.", "InvalidStateError"));
    return new Promise<T>((resolve, reject) => {
      this.#queue.push({ write, alone, start: (store) => start(store, resolve, reject), fail: reject });
      if (!this.#running) this.#next();
    });
  }

  #next(): void {
    // Everything queued up to the first walk, or the walk alone.
    const end = this.#queue[0]?.alone ? 1 : this.#queue.findIndex((op) => op.alone);
    const ops = this.#queue.splice(0, end < 0 ? this.#queue.length : end);
    if (ops.length === 0) {
      this.#running = false;
      if (this.#closing) {
        this.#db.close();
        this.#drained?.();
      }
      return;
    }
    this.#running = true;
    let tx: IDBTransaction;
    try {
      tx = this.#db.transaction(STORE_NAME, ops.some((op) => op.write) ? "readwrite" : "readonly");
    } catch (error) {
      for (const op of ops) op.fail(error);
      return this.#next();
    }
    const store = tx.objectStore(STORE_NAME);
    for (const op of ops) {
      try {
        op.start(store);
      } catch (error) {
        // A request that throws (a key IndexedDB cannot store, say) fails its
        // own operation and leaves the transaction to the others.
        op.fail(error);
      }
    }
    tx.oncomplete = () => this.#next();
    tx.onabort = () => {
      const error = tx.error ?? new DOMException("The storage transaction was aborted.", "AbortError");
      for (const op of ops) op.fail(error);
      this.#next();
    };
  }

  close(): Promise<void> {
    this.#closing = true;
    if (this.#running) return new Promise((resolve) => (this.#drained = resolve));
    this.#db.close();
    return Promise.resolve();
  }
}

class MemoryBackend implements StorageBackend {
  #spaces = new Map<string, Map<string, Uint8Array>>();

  #space(address: string): Map<string, Uint8Array> {
    let m = this.#spaces.get(address);
    if (!m) this.#spaces.set(address, (m = new Map()));
    return m;
  }

  async get(address: string, key: string): Promise<Uint8Array | undefined> {
    return this.#space(address).get(key);
  }

  async getMany(address: string, keys: readonly string[]): Promise<(Uint8Array | undefined)[]> {
    // Copies, as IndexedDB's are: the host transfers what this returns.
    const space = this.#space(address);
    return keys.map((key) => space.get(key)?.slice());
  }

  async set(address: string, key: string, value: Uint8Array): Promise<void> {
    this.#space(address).set(key, value);
  }

  async delete(address: string, key: string): Promise<void> {
    this.#space(address).delete(key);
  }

  async has(address: string, key: string): Promise<boolean> {
    return this.#space(address).has(key);
  }

  async listKeys(address: string, prefix = ""): Promise<string[]> {
    return [...this.#space(address).keys()].filter((k) => k.startsWith(prefix));
  }

  async clear(address: string, prefix = ""): Promise<void> {
    const space = this.#space(address);
    if (!prefix) return space.clear();
    for (const k of [...space.keys()]) if (k.startsWith(prefix)) space.delete(k);
  }

  async close(): Promise<void> {}
}
