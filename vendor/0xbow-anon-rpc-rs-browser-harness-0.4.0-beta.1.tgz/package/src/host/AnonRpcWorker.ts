// §5 — Host-side harness API: `AnonRpcWorker`.
//
// Responsibilities (§3.1): verify bundle integrity (§4), run the worker under
// §6 isolation (Web Worker inside a null-origin sandboxed iframe), implement the
// capability API for the worker, and expose `fetch` to the host.

import type { WorkerInit, AnonFetch, AnonFetchResponse, LogEntry, PlainValue, RpcProvider } from "../spec-types.js";
import { PortRpc, RpcError, type SerializedError } from "../protocol.js";
import { registerKpsBridge } from "./kps-bridge-host.js";
import { normalizeRequest, toResponse, type WireRequestInit } from "./request.js";
import { openStorageBackend, privateOverlay, type StorageBackend } from "./idb-storage.js";
import { READ_AHEAD_MAX } from "../worker/anon-rpc-worker-api.js";
import { sharedBundle, sharedRead } from "./boot-cache.js";
import { knownWorkerInit } from "./known-workers.js";
import { applyRequestQuirks, workerQuirks, type WorkerQuirks } from "./worker-quirks.js";
import { isStreamRef, streamRelay } from "../stream-relay.js";
import {
  CallQueue,
  LogQueue,
  renderLogArg,
  abortReason,
  checkAddress,
  untilAborted,
  checkChainId,
  checkSpecifierChain,
  copyPlainValue,
  fetchAndVerifyBundle,
  normalizeWorkerHash,
  readSpecifier,
  MAX_BUNDLE_BYTES,
  WorkerHashMismatchError,
} from "@0xbow/anon-rpc-rs-harness-core";
import { kpsResolverKind } from "./kps-http.js";

// Injected at build time (see build.mjs): source text the null-origin iframe
// blob-spawns, since an opaque-origin iframe cannot load host-origin scripts.
declare const __WORKER_RUNTIME_SRC__: string;
declare const __IFRAME_BOOT_SRC__: string;

/** What `AnonRpcWorker.tor` takes. */
export type TorInit = {
  /**
   * The KPS gateways tor-js relays Tor traffic through, as
   * `<ip>:<port>:<certhash>`. Required: there is no default gateway.
   */
  gateways: string[];
  /** Reads the tor-js specifier contract on mainnet, as `preExisting.rpcProvider`. */
  rpcProvider: RpcProvider;
  iframeUrl?: string;
};

type CallRecord = {
  callId: number;
  url: string;
  requestInit?: WireRequestInit;
  bodyTransfer?: Transferable[];
  signal?: AbortSignal;
  resolve: (r: Response) => void;
  reject: (e: unknown) => void;
  // Detaches the host-signal abort listener; called when the call settles.
  cleanup?: () => void;
};

export class AnonRpcWorker {
  ready: Promise<void>;
  fetch: AnonFetch;

  #init: WorkerInit;
  #config: PlainValue;
  #rpc?: PortRpc;
  #port?: MessagePort;
  #iframe?: HTMLIFrameElement;
  #disposeKps?: () => void;
  #onWindowMessage?: (ev: MessageEvent) => void;

  // Calls awaiting acceptCall (§8: ordered, no drop, backpressured).
  #queue = new CallQueue<CallRecord>();
  // Log entries awaiting acceptLog (§13.1: ordered, bounded, lossy).
  #logs = new LogQueue<LogEntry>();
  // Set once the host has shown it is collecting logs, which is what stops
  // them also going to the console. Not a setting: a host that reads its
  // worker's logs does not want them duplicated into a console it is not
  // looking at, and one that never reads still gets the old behaviour.
  #logsClaimed = false;
  #calls = new Map<number, CallRecord>();
  // Ends each response body still streaming in; see #trackBody.
  #bodies = new Set<(reason: unknown) => void>();
  #nextCallId = 1;
  #readyResolve!: () => void;
  #readyReject!: (e: unknown) => void;
  // Set on fatal failure (boot failure, worker crash, close): everything
  // pending is rejected with it and future fetches fail fast.
  #failed = false;
  #failure?: unknown;
  // Aborted with that failure. The boot runs under it, so a boot still reading
  // the specifier, downloading the bundle or waiting for the iframe stops
  // there, and cancels the download rather than finishing it.
  #lifetime = new AbortController();
  // §11 storage backend (IndexedDB; memory fallback), opened on first use.
  #storage?: Promise<StorageBackend>;
  // The release of the namespace's Web Lock while this worker holds it.
  #storageLock?: Promise<(() => void) | null | undefined>;
  // Workarounds for the verified bundle's known defects, if it has any.
  #quirks: WorkerQuirks = {};

  /**
   * A worker running tor-js, the Tor client compiled to WebAssembly, whose
   * traffic leaves through `gateways`.
   */
  static tor({ gateways, rpcProvider, iframeUrl }: TorInit): AnonRpcWorker {
    return new AnonRpcWorker(knownWorkerInit("tor-js", { rpcProvider, config: { gateways }, iframeUrl }));
  }

  constructor(init: WorkerInit) {
    this.#init = init;
    // §7.1: a config that is not a §9.4 plain value fails construction, before
    // anything boots. Copied now, so later host mutation cannot reach the worker.
    this.#config = copyPlainValue(init.config, "config");
    this.ready = new Promise<void>((res, rej) => {
      this.#readyResolve = res;
      this.#readyReject = rej;
    });
    // A caller need not await `ready` (e.g. close() before boot finishes);
    // this branch absorbs the rejection so it is never "unhandled", while
    // awaiting callers still observe it.
    this.ready.catch(() => {});
    // §5: `fetch` MUST be this-bound so it works as a free function.
    this.fetch = this.#fetch.bind(this);
    this.#boot().catch((e) => this.#fail(e));
  }

  // A dead worker fails everything, not just `ready`: in-flight and queued
  // fetches would otherwise hang with no error surfaced. It is torn down too,
  // whatever the cause: after an uncaught error or signalFailed the worker is
  // untrusted code in an unknown state, and it keeps no frame, no channel and
  // no KPS connection to act on.
  #fail(err: unknown): void {
    if (this.#failed) return;
    this.#failed = true;
    this.#failure = err;
    this.#lifetime.abort(err);
    this.#teardown();
    this.#readyReject(err);
    for (const rec of this.#calls.values()) {
      rec.cleanup?.();
      rec.reject(err);
    }
    this.#calls.clear();
    for (const end of this.#bodies) end(err);
    this.#queue.rejectAll(err);
    // Note the asymmetry with the call queue above, which is emptied: §13.1
    // keeps retained log entries deliverable after a failure. The lines a
    // worker wrote on its way down are the ones worth reading.
    this.#logs.close(err);
  }

  #teardown(): void {
    this.#disposeKps?.();
    if (this.#rpc) streamRelay(this.#rpc).dispose();
    if (this.#onWindowMessage) window.removeEventListener("message", this.#onWindowMessage);
    this.#iframe?.remove();
    this.#port?.close();
    // IndexedDB lets transactions already begun finish, then closes; the
    // namespace's lock passes on only after that.
    const lock = this.#storageLock;
    void this.#storage
      ?.then((storage) => storage.close())
      .catch(() => {})
      .then(() => lock)
      .then((release) => release?.());
  }

  // Every await below is raced against the lifetime signal and followed by a
  // check of it, so a close() at any point, including one whose cancellation
  // the awaited work ignores, ends the boot before its next side effect.
  async #boot(): Promise<void> {
    const provider = this.#init.preExisting?.rpcProvider;
    if (!provider) throw new Error("preExisting.rpcProvider is required to read the specifier");
    const signal = this.#lifetime.signal;
    const expected =
      this.#init.expectedWorkerHash === undefined ? undefined : normalizeWorkerHash(this.#init.expectedWorkerHash);

    // Refused before any provider request, as the native packages refuse it.
    const { address } = this.#init;
    checkAddress(address);
    // Shared with the page's other workers booting through the same
    // provider and specifier (boot-cache.ts), so only the first one's boot
    // reaches the network.
    const chainId = this.#init.specifierChainId;
    if (chainId !== undefined) {
      // Validated before the lookup, so a cached answer never stands in for
      // another value's check.
      checkChainId(chainId);
      await sharedRead(provider, `chain:${chainId}`, (s) => checkSpecifierChain(provider, chainId, s), signal);
      signal.throwIfAborted();
    }
    const spec = await sharedRead(provider, `specifier:${address.toLowerCase()}`, (s) => readSpecifier(provider, address, s), signal);
    signal.throwIfAborted();
    if (expected !== undefined && spec.workerHash !== expected) {
      throw new WorkerHashMismatchError(expected, spec.workerHash);
    }
    const bundleBytes = await sharedBundle(spec.workerHash, (s) => fetchAndVerifyBundle(spec, MAX_BUNDLE_BYTES, [kpsResolverKind], s), signal);
    signal.throwIfAborted();
    this.#quirks = workerQuirks(spec.workerHash);

    const channel = new MessageChannel();
    this.#port = channel.port1;
    const rpc = new PortRpc(channel.port1);
    this.#rpc = rpc;
    this.#registerHandlers(rpc);

    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts"); // §6: null origin, scripts only
    iframe.style.display = "none";
    // §5/§6 `iframeUrl`: a host whose CSP forbids inline script supplies the
    // document, because a `srcdoc` frame inherits that CSP and the bootstrap
    // below would simply not execute. Either path ends at an opaque origin
    // running the same iframe-boot code — the sandbox attribute above is
    // applied regardless, as §6 requires.
    if (this.#init.iframeUrl) iframe.src = sameOriginIframeUrl(this.#init.iframeUrl);
    else iframe.srcdoc = `<!doctype html><meta charset="utf-8"><script>${__IFRAME_BOOT_SRC__}</script>`;
    this.#iframe = iframe;

    const ready = new Promise<void>((resolve, reject) => {
      let said = false;
      const onMessage = (ev: MessageEvent) => {
        if (ev.source !== iframe.contentWindow) return;
        if (ev.data?.kind === "iframe-ready") {
          said = true;
          resolve();
        }
        // An uncaught worker error is fatal harness policy: the worker is
        // untrusted code in an unknown state, so everything pending fails —
        // whether it happens during boot or after signalReady.
        if (ev.data?.kind === "worker-error") {
          this.#fail(new Error(`worker error: ${ev.data.message}`));
        }
      };
      this.#onWindowMessage = onMessage;
      window.addEventListener("message", onMessage);
      // The bootstrap says iframe-ready as its first statement, so a document
      // that has loaded and stays silent never ran it: a host CSP without
      // 'unsafe-inline' and no iframeUrl, or an iframeUrl page without the
      // bootstrap. Waiting on would leave `ready` pending forever.
      iframe.addEventListener("load", () => {
        setTimeout(() => {
          if (!said) {
            reject(
              new Error(
                "the sandboxed iframe loaded but its bootstrap did not run; a Content Security Policy without 'unsafe-inline' needs iframeUrl (§6)",
              ),
            );
          }
        }, IFRAME_READY_GRACE_MS);
      });
    });
    document.body.appendChild(iframe);
    await untilAborted(ready, signal);
    signal.throwIfAborted();

    // §7.1: config rides the init message. It is already a §9.4 copy, and
    // structured clone carries every plain value unchanged. The bundle
    // goes as a copy of its own, transferred: a clone would keep a second
    // copy alive in the page while the worker boots, and the page keeps the
    // verified bytes for its next worker, so they must never be transferred.
    const bytes = bundleBytes.slice();
    iframe.contentWindow!.postMessage(
      { kind: "init", runtimeSource: __WORKER_RUNTIME_SRC__, bundleBytes: bytes, config: this.#config },
      "*",
      [channel.port2, bytes.buffer],
    );

    // `this.ready` resolves when the worker emits "ready" (signalReady, §7).
  }

  #registerHandlers(rpc: PortRpc): void {
    this.#disposeKps = registerKpsBridge(rpc);

    rpc.onEvent("ready", () => this.#readyResolve());

    // The worker runtime reports a bundle that failed to load (§4-valid bytes
    // can still throw at top level); without this, `ready` would hang.
    rpc.onEvent("boot-error", ({ message }: { message: string }) => {
      this.#fail(new Error(`worker bundle failed to load: ${message}`));
    });

    // §7 signalFailed: the worker deliberately reports an unrecoverable
    // failure. code crosses intact for the host to branch on (§12); #fail's
    // one-shot guard gives the MUST-ignore-later-signals semantics.
    rpc.onEvent("failed", ({ reason }: { reason?: { code?: string; message?: string } }) => {
      this.#fail(
        new RpcError({
          name: "WorkerFailedError",
          message: reason?.message ?? "worker signalled failure",
          code: reason?.code,
        }),
      );
    });

    rpc.onEvent("log", ({ level, args }: { level: string; args: unknown[] }) => {
      this.#logs.push({ level: level as LogEntry["level"], args: args as LogEntry["args"] });
      if (this.#logsClaimed) return;
      const fn = (console as any)[level] ?? console.log;
      fn.call(console, "[worker]", ...args.map((a) => renderLogArg(a)));
    });

    rpc.on("acceptCall", async (_args, { signal }) => {
      for (;;) {
        const rec = await this.#queue.take(signal);
        // A body stream the caller locked after calling fetch cannot be read
        // for the worker. Fail that call and hand over the next.
        const body = rec.requestInit?.body;
        if (body instanceof ReadableStream && body.locked) {
          this.#calls.delete(rec.callId);
          rec.cleanup?.();
          rec.reject(new TypeError("the body stream was locked before the worker took the call"));
          continue;
        }
        const requestInit = applyRequestQuirks(
          body instanceof ReadableStream ? { ...rec.requestInit, body: streamRelay(rpc).sendReadable(body) } : rec.requestInit,
          this.#quirks,
        );
        const value = {
          callId: rec.callId,
          url: rec.url,
          requestInit,
        };
        return { value, transfer: rec.bodyTransfer ?? [] };
      }
    });

    rpc.on("respond", async (msg: {
      callId: number;
      ok: boolean;
      response?: AnonFetchResponse;
      error?: SerializedError;
    }) => {
      const rec = this.#calls.get(msg.callId);
      // Unknown callId is expected when the host aborted the call after the
      // worker had already accepted it: the late respond is dropped, and a
      // streamed body cancelled so the worker does not hold its source.
      if (!rec) {
        const body: unknown = msg.response?.body;
        if (isStreamRef(body)) void streamRelay(rpc).readable(body).cancel().catch(() => {});
        return { value: undefined };
      }
      this.#calls.delete(msg.callId);
      rec.cleanup?.();
      if (msg.ok && msg.response) {
        const r = msg.response;
        const wireBody: unknown = r.body;
        const body = isStreamRef(wireBody) ? this.#trackBody(streamRelay(rpc).readable(wireBody), rec.signal) : r.body;
        // toResponse validates worker-supplied status/headers; a throw must
        // settle the fetch (the record is already removed) rather than escape.
        try {
          rec.resolve(toResponse({ ...r, body }));
        } catch (e) {
          if (body instanceof ReadableStream) void body.cancel(e).catch(() => {});
          rec.reject(e);
        }
      } else {
        // §12: name/code cross the boundary intact; host logic may branch on
        // code, never on message text.
        rec.reject(new RpcError(msg.error ?? { name: "Error", message: "worker failed the call" }));
      }
      return { value: undefined };
    });

    // §11: scoped to the specifier address (normalized, so checksum-cased and
    // lowercased forms of one address share a namespace).
    const addr = this.#init.address.toLowerCase();
    // One worker of the origin per namespace, across tabs and pool members,
    // holds the Web Lock `anon-rpc-storage:<address>` and writes IndexedDB;
    // any other keeps its writes to itself, as Arti does without its state
    // lock. A page without Web Locks persists every worker's writes, since
    // state that never persists would choose new Tor guards on every load.
    const store = () => {
      if (!this.#storage) {
        const lock = (this.#storageLock = takeLock(`anon-rpc-storage:${addr}`));
        this.#storage = Promise.all([openStorageBackend(), lock]).then(([backend, held]) =>
          held === null ? privateOverlay(backend) : backend,
        );
      }
      return this.#storage;
    };
    rpc.on("storage.get", async ({ key }) => ({ value: await (await store()).get(addr, storageKey(key)) }));
    // The worker side's read-ahead (see storageApi). Each value is a fresh
    // copy read from IndexedDB, so its buffer is transferred, not cloned.
    rpc.on("storage.getMany", async ({ keys }: { keys: unknown }) => {
      // The worker is untrusted: one message must not queue unbounded reads.
      if (!Array.isArray(keys) || keys.length > READ_AHEAD_MAX || !keys.every((k) => typeof k === "string")) {
        throw new TypeError(`storage.getMany takes at most ${READ_AHEAD_MAX} string keys`);
      }
      const values = await (await store()).getMany(addr, keys);
      return { value: values, transfer: values.flatMap((v) => (v ? [v.buffer as ArrayBuffer] : [])) };
    });
    rpc.on("storage.set", async ({ key, value }) => {
      // As the native sandbox refuses it, so `get` only ever returns bytes.
      if (!(value instanceof Uint8Array)) throw new TypeError("storage.set: value must be a Uint8Array");
      await (await store()).set(addr, storageKey(key), value);
      return { value: undefined };
    });
    rpc.on("storage.delete", async ({ key }) => {
      await (await store()).delete(addr, storageKey(key));
      return { value: undefined };
    });
    rpc.on("storage.has", async ({ key }) => ({ value: await (await store()).has(addr, storageKey(key)) }));
    rpc.on("storage.list", async ({ prefix }: { prefix?: unknown }) => ({
      value: await (await store()).listKeys(addr, storagePrefix(prefix)),
    }));
    rpc.on("storage.clear", async ({ prefix }: { prefix?: unknown }) => {
      await (await store()).clear(addr, storagePrefix(prefix));
      return { value: undefined };
    });
  }

  async #fetch(input: RequestInfo | URL, init?: Parameters<AnonFetch>[1]): Promise<Response> {
    if (this.#failed) throw this.#failure;
    const { url, requestInit, transfer, signal: hostSignal } = await normalizeRequest(input, init);
    // Normalizing awaits, and the worker may have failed or been closed
    // meanwhile; a call queued after that would never be taken or rejected.
    if (this.#failed) throw this.#failure;
    const callId = this.#nextCallId++;

    return new Promise<Response>((resolve, reject) => {
      const rec: CallRecord = {
        callId,
        url,
        requestInit,
        bodyTransfer: transfer,
        signal: hostSignal,
        resolve,
        reject,
      };
      this.#calls.set(callId, rec);

      if (hostSignal) {
        const onAbort = () => {
          // Not yet delivered: withdraw it from the queue so the worker never
          // sees a dead call. Already delivered: tell the worker to abort it.
          if (!this.#queue.remove(rec)) this.#rpc?.emit("call-abort", { callId });
          if (this.#calls.delete(callId)) {
            reject(abortReason(hostSignal));
          }
        };
        if (hostSignal.aborted) {
          this.#calls.delete(callId);
          reject(abortReason(hostSignal));
          return;
        }
        hostSignal.addEventListener("abort", onAbort, { once: true });
        rec.cleanup = () => hostSignal.removeEventListener("abort", onAbort);
      }
      this.#queue.push(rec);
    });
  }

  // §9.2: a streamed body is part of its call, so what fails a call before
  // its response (the caller aborting, the worker failing or closing) must also
  // fail a body still arriving. The relayed stream notices neither: the
  // caller's signal was detached when the response came, and a torn-down frame
  // need not answer this side's reads again. Cancelling the source tells the
  // worker to stop producing.
  #trackBody(src: ReadableStream<Uint8Array>, signal?: AbortSignal): ReadableStream<Uint8Array> {
    const reader = src.getReader();
    let ended = false;
    let end!: (reason: unknown) => void;
    const onAbort = () => end(abortReason(signal!));
    const settle = () => {
      ended = true;
      this.#bodies.delete(end);
      signal?.removeEventListener("abort", onAbort);
    };
    const body = new ReadableStream<Uint8Array>(
      {
        start: (controller) => {
          end = (reason) => {
            if (ended) return;
            settle();
            controller.error(reason);
            void reader.cancel(reason).catch(() => {});
          };
        },
        pull: async (controller) => {
          let chunk: ReadableStreamReadResult<Uint8Array>;
          try {
            chunk = await reader.read();
          } catch (e) {
            if (!ended) {
              settle();
              controller.error(e);
            }
            return;
          }
          if (ended) return;
          if (chunk.done) {
            settle();
            controller.close();
          } else {
            controller.enqueue(chunk.value);
          }
        },
        cancel: (reason) => {
          settle();
          return reader.cancel(reason);
        },
      },
      { highWaterMark: 0 },
    );
    this.#bodies.add(end);
    if (signal?.aborted) onAbort();
    else signal?.addEventListener("abort", onAbort, { once: true });
    return body;
  }

  /**
   * §5/§13.1: the next log entry the worker produced, waiting for one if the
   * buffer is empty.
   *
   * Calling it at all is what claims the worker's logs: from the first call,
   * entries stop being echoed to the console, because a host that collects
   * them is not served by seeing them twice.
   */
  acceptLog(opts?: { signal?: AbortSignal }): Promise<LogEntry> {
    this.#logsClaimed = true;
    return this.#logs.take(opts?.signal);
  }

  /**
   * Stop the worker for good: a boot still in progress stops at its next step
   * and creates nothing, and the iframe, channel and KPS connections are torn
   * down. Pending and future calls fail with "worker closed", code `closed`.
   * Repeating it, or calling it after a failure, does nothing.
   */
  close(): void {
    // §12: code "closed", as the native packages report it.
    this.#fail(new RpcError({ name: "Error", message: "worker closed", code: "closed" }));
  }
}

// How long after the iframe's load event its iframe-ready may still arrive.
const IFRAME_READY_GRACE_MS = 3_000;

/**
 * §6: `iframeUrl` MUST be same-origin with the host document.
 *
 * A cross-origin bootstrap would put the isolation boundary in a third party's
 * hands — they would choose what runs in the frame that is supposed to contain
 * the worker, and receive the capability port. Resolved against the host's own
 * URL first, so a relative path is the normal way to write it.
 */
function sameOriginIframeUrl(raw: string): string {
  let url: URL;
  try {
    url = new URL(raw, location.href);
  } catch {
    throw new Error(`iframeUrl is not a valid URL: ${raw}`);
  }
  if (url.origin !== location.origin) {
    throw new Error(
      `iframeUrl must be same-origin with the host (${location.origin}), got ${url.origin} — ` +
        "a cross-origin bootstrap would control the isolation boundary (§6)",
    );
  }
  return url.href;
}

export { RpcError };

// §11 keys are strings. The worker is untrusted, and IndexedDB would store a
// number or an array as a key too, which the prefix and cursor walks behind
// list, clear and the read-ahead do not expect.
function storageKey(key: unknown): string {
  if (typeof key !== "string") throw new TypeError("storage keys are strings");
  return key;
}

function storagePrefix(prefix: unknown): string | undefined {
  if (prefix !== undefined && typeof prefix !== "string") throw new TypeError("a storage prefix is a string");
  return prefix;
}

/**
 * Take the Web Lock `name` if it is free: resolves with its release, null
 * while another holder has it, or undefined where Web Locks are unavailable.
 */
function takeLock(name: string): Promise<(() => void) | null | undefined> {
  const locks = (globalThis.navigator as Navigator | undefined)?.locks;
  if (!locks) return Promise.resolve(undefined);
  return new Promise((resolve) => {
    locks
      .request(name, { ifAvailable: true }, (lock) => {
        if (!lock) return resolve(null);
        return new Promise<void>((release) => resolve(release));
      })
      .catch(() => resolve(undefined));
  });
}
