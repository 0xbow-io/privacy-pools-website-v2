// When a worker's route has stopped carrying calls, by the rule SPEC.md §5.1
// states and the anon-rpc crate applies to the native lanes.

export type Outcome = "answered" | "failed" | "timeout" | "abandoned";

/**
 * Whether a worker's route has stopped carrying calls: a call has failed with
 * none answering since (the second such failure, for a worker that has
 * answered before), and either no call to another host is still waiting or
 * the failure is a timeout during which no call to any host answered. A host
 * that fails while another may still answer is that endpoint's problem, not
 * the route's, and replacing the worker would cut off the calls that work. A
 * route that answered nothing for a whole call deadline has shown that no
 * host still answers; waiting on calls to hosts first tried during it would
 * only put the replacement off by a deadline per new host.
 */
export function routeHealth() {
  const waiting = new Map<string, number>();
  const failedHosts = new Set<string>();
  let failures = 0;
  let answers = 0;
  return {
    /** One call has been sent; pass the result to `settled`. */
    sent(host: string): number {
      waiting.set(host, (waiting.get(host) ?? 0) + 1);
      return answers;
    },
    /** One call has finished; true when the route should be replaced. */
    settled(host: string, outcome: Outcome, answersAtSend: number): boolean {
      const left = (waiting.get(host) ?? 1) - 1;
      if (left > 0) waiting.set(host, left);
      else waiting.delete(host);
      if (outcome === "abandoned") return false;
      if (outcome === "answered") {
        answers++;
        failures = 0;
        failedHosts.clear();
        return false;
      }
      failures++;
      failedHosts.add(host);
      if (failures < (answers > 0 ? 2 : 1)) return false;
      if (outcome === "timeout" && answers === answersAtSend) return true;
      return [...waiting.keys()].every((other) => failedHosts.has(other));
    },
  };
}
