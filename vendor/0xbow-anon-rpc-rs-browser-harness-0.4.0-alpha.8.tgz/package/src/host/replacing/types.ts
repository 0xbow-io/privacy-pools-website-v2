// The options ReplacingWorker and WorkerPool share, and what they need of a
// worker.

/** What ReplacingWorker uses of a worker. */
export type ReplaceableWorker = {
  ready: Promise<void>;
  fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
  close(): void;
};

export type ReplacingWorkerOptions<W extends ReplaceableWorker> = {
  /**
   * Starts a worker: at the first call, and at the first call after the
   * worker in use was replaced or failed to start. `signal` aborts when that
   * worker is closed, for anything the start itself reads.
   */
  start: (signal: AbortSignal) => W | Promise<W>;
  /**
   * How long a call may wait for its response once the worker is ready. A
   * call still waiting then fails with code `timeout` and counts against the
   * route, as a failed call does. Allow for a cold route: the first call to
   * each new host over Nym took 16 to 35 s on Android Chrome. Without it,
   * only calls that fail count, and a route that hangs is never replaced.
   */
  callTimeoutMs?: number;
  /**
   * How long `start` and the worker's `ready` together may take before the
   * worker is closed and the calls waiting on it fail; the next call starts
   * another. Without it, a start that never finishes holds every call until
   * the caller aborts it.
   */
  readyTimeoutMs?: number;
};
