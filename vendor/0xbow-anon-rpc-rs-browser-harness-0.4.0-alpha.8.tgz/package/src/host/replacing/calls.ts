// What ReplacingWorker and WorkerPool share about a call: copying its init,
// following its abort, naming its host, tracking its body, and the errors and
// option checks the crate's pools also apply.

import { MODELED_INIT_KEYS, RpcError, copyForwardedEntries } from "@0xbow/anon-rpc-rs-harness-core";

// `response`, calling `done` once its body has been read, has failed, or was
// cancelled, or at once when it has none: closing a worker would end a body
// still arriving (§9.2).
export function readTracked(response: Response, done: () => void): Response {
  const source = response.body;
  if (!source) {
    done();
    return response;
  }
  const reader = source.getReader();
  let open = true;
  const finish = () => {
    if (open) {
      open = false;
      done();
    }
  };
  const body = new ReadableStream<Uint8Array>({
    pull: async (controller) => {
      try {
        const chunk = await reader.read();
        if (chunk.done) {
          finish();
          controller.close();
        } else controller.enqueue(chunk.value);
      } catch (e) {
        finish();
        controller.error(e);
      }
    },
    cancel: (reason) => {
      finish();
      return reader.cancel(reason);
    },
  });
  const tracked = new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers });
  if (response.url) Object.defineProperty(tracked, "url", { value: response.url });
  return tracked;
}

/** A deadline `name` in milliseconds: absent, or finite and not negative. */
export function checkDeadline(name: string, ms: number | undefined): void {
  if (ms !== undefined && !(Number.isFinite(ms) && ms >= 0)) {
    throw unsupported(`${name} must be a number of milliseconds, not negative`);
  }
}

export function unsupported(message: string): RpcError {
  return new RpcError({ name: "RpcError", message, code: "unsupported" });
}

export function closedError(): RpcError {
  return new RpcError({ name: "Error", message: "worker closed", code: "closed" });
}

// The value, or the signal's reason as soon as it aborts, as AnonRpcWorker.fetch
// rejects: a call stops waiting for a worker or a response that other calls
// share. An AbortError stands in where the platform gives no reason (React
// Native's AbortController).
export function untilAborted<T>(value: Promise<T>, signal?: AbortSignal | null): Promise<T> {
  if (!signal) return value;
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(signal.reason === undefined ? abortError() : signal.reason);
    signal.addEventListener("abort", onAbort);
    // Settling after an abort is a no-op, and handles a rejection nothing else awaits.
    value.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
    if (signal.aborted) onAbort();
  });
}

function abortError(): Error {
  const error = new Error("The operation was aborted.");
  error.name = "AbortError";
  return error;
}

// The authority of an absolute URL, without its userinfo: what calls to one
// endpoint share; the whole URL when it has none, as the crate's host_of
// takes it. Parsed by hand, since React Native's URL lacks `host`.
export function hostOf(input: RequestInfo | URL): string {
  const url = typeof input === "string" ? input : "href" in input ? input.href : input.url;
  const authority = /^[a-z][a-z0-9+.-]*:\/\/([^/?#]*)/i.exec(url)?.[1];
  if (authority === undefined) return url.toLowerCase();
  return authority.slice(authority.lastIndexOf("@") + 1).toLowerCase();
}

/**
 * `init` as it is now: the members §9.1 models as they are, and §9.4 copies of
 * its forwarded entries, so a call held until its worker is ready is the call
 * the host made. A forwarded entry that is not plain throws a TypeError.
 */
export function initNow(init: RequestInit): RequestInit {
  const now: Record<string, unknown> = { ...copyForwardedEntries(init) };
  for (const key of MODELED_INIT_KEYS) {
    const value = (init as Record<string, unknown>)[key];
    if (value !== undefined) now[key] = value;
  }
  return now as RequestInit;
}
