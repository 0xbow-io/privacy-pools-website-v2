// WorkerPool (SPEC.md §5.2): one ReplacingWorker per isolation group, under
// a budget of live workers.

import type { ReplaceableWorker, ReplacingWorkerOptions } from "./types.js";
import { ReplacingWorker } from "./replacing-worker.js";
import { checkDeadline, closedError, initNow, readTracked, unsupported } from "./calls.js";

export type WorkerPoolOptions<W extends ReplaceableWorker> = ReplacingWorkerOptions<W> & {
  /** The most workers alive at once, over every group and every spare. */
  maxWorkers: number;
  /**
   * How many workers to keep started for groups that have none, from the
   * first `group()` call on. The next group to start a worker takes one, and
   * the pool starts another while the budget allows. Defaults to 0.
   */
  spare?: number;
  /**
   * How long a group's worker may go with no call waiting before it is
   * closed; the group's next call starts another. Without it, a group keeps
   * its worker until it is closed. A response body still being read does not
   * count as a call waiting.
   */
  idleCloseMs?: number;
};

/** One isolation group of a WorkerPool: a `fetch` over a worker of its own. */
export type WorkerGroup = {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
  /** Start the group's worker without a call, and settle when it is ready. */
  ready(): Promise<void>;
  /** Close the group's worker and free its place; later calls fail with code `closed`. */
  close(): void;
};

type Spare<W> = { worker: Promise<W>; lifetime: AbortController; claim(signal: AbortSignal): void };
type Waiter = { grant(): void };
// One worker's use by a group: the calls pending on it, the response bodies
// still being read from it, and when the last call began. A drained use takes
// no new calls, and closes once nothing is pending or callTimeoutMs after it
// was drained.
type Use<W extends ReplaceableWorker> = {
  group: WorkerGroup;
  replacing: ReplacingWorker<W>;
  busy: number;
  reading: number;
  lastUse: number;
  draining: boolean;
  drain(): void;
  settle(): void;
  close(): void;
};

/**
 * Workers for isolation groups under one budget. Each group is a
 * ReplacingWorker of its own, so calls in two groups never share a worker,
 * and the pool counts every worker alive, spares included, against
 * `maxWorkers`. A group whose worker would pass the budget waits, first come
 * first served, until a group closes, idles out or retires a worker; the wait
 * counts towards `readyTimeoutMs`, and a caller's signal ends it for that
 * call. While groups wait, the least recently used groups holding a worker
 * are drained: their later calls start a new worker, which waits like any
 * other, and their worker closes once no call or response body is pending on
 * it, or at the call deadline. Which traffic shares a group is the host's
 * policy.
 */
export class WorkerPool<W extends ReplaceableWorker = ReplaceableWorker> {
  #options: WorkerPoolOptions<W>;
  #groups = new Map<string, WorkerGroup>();
  #spares: Spare<W>[] = [];
  #waiting: Waiter[] = [];
  // The use each worker holding a place serves, by the worker's lifetime.
  #holders = new Map<AbortSignal, Use<W>>();
  #uses = 0;
  #live = 0;
  #closed = false;

  constructor(options: WorkerPoolOptions<W>) {
    // The rules the anon-rpc crate applies to the native lanes' pools.
    const { maxWorkers, spare = 0 } = options;
    if (!Number.isInteger(maxWorkers) || maxWorkers < 1) {
      throw unsupported("maxWorkers must be a whole number of at least 1");
    }
    if (!Number.isInteger(spare) || spare < 0 || spare > maxWorkers) {
      throw unsupported("spare must be a whole number from 0 to maxWorkers");
    }
    checkDeadline("idleCloseMs", options.idleCloseMs);
    checkDeadline("callTimeoutMs", options.callTimeoutMs);
    checkDeadline("readyTimeoutMs", options.readyTimeoutMs);
    this.#options = options;
  }

  /**
   * The group named `key`, made on first use; the same object until it is
   * closed. `idleCloseMs` overrides the pool's for a group this call makes.
   */
  group(key: string, options: { idleCloseMs?: number } = {}): WorkerGroup {
    if (this.#closed) throw closedError();
    let group = this.#groups.get(key);
    if (!group) {
      checkDeadline("idleCloseMs", options.idleCloseMs);
      group = this.#makeGroup(key, options.idleCloseMs ?? this.#options.idleCloseMs);
      this.#groups.set(key, group);
      this.#refill();
    }
    return group;
  }

  /** Close every group and spare; waiting and later calls fail with code `closed`. */
  close(): void {
    if (this.#closed) return;
    this.#closed = true;
    for (const waiter of this.#waiting.splice(0)) waiter.grant();
    for (const group of [...this.#groups.values()]) group.close();
    for (const spare of this.#spares.splice(0)) closeSpare(spare);
  }

  #makeGroup(key: string, idleCloseMs: number | undefined): WorkerGroup {
    const { callTimeoutMs, readyTimeoutMs } = this.#options;
    let use: Use<W> | undefined;
    let closed = false;
    let idle: ReturnType<typeof setTimeout> | undefined;
    const current = (): Use<W> => {
      if (use) return use;
      let bound: ReturnType<typeof setTimeout> | undefined;
      const made: Use<W> = {
        group,
        replacing: new ReplacingWorker<W>({ start: (signal) => this.#start(signal, made), callTimeoutMs, readyTimeoutMs }),
        busy: 0,
        reading: 0,
        lastUse: 0,
        draining: false,
        drain: () => {
          if (made.draining) return;
          made.draining = true;
          if (use === made) {
            use = undefined;
            clearTimeout(idle);
          }
          if (made.busy === 0 && made.reading === 0) made.close();
          else if (callTimeoutMs !== undefined) bound = setTimeout(made.close, callTimeoutMs);
        },
        settle: () => {
          if (made.draining && made.busy === 0 && made.reading === 0) made.close();
        },
        close: () => {
          clearTimeout(bound);
          made.replacing.close();
        },
      };
      return (use = made);
    };
    const using = async <T>(run: (worker: ReplacingWorker<W>) => Promise<T>, held = current()): Promise<T> => {
      held.busy++;
      held.lastUse = ++this.#uses;
      clearTimeout(idle);
      try {
        return await run(held.replacing);
      } finally {
        if (--held.busy === 0) {
          if (held.draining) held.settle();
          else if (idleCloseMs !== undefined && !closed) {
            idle = setTimeout(() => {
              if (use !== held) return;
              use = undefined;
              held.close();
            }, idleCloseMs);
          }
        }
      }
    };
    const group: WorkerGroup = {
      fetch: (input, init) => {
        // As ReplacingWorker takes it, keeping a signal init inherits.
        let now: RequestInit | undefined;
        try {
          now = init && { ...initNow(init), signal: init.signal };
        } catch (e) {
          return Promise.reject(e);
        }
        if (closed) return Promise.reject(closedError());
        const held = current();
        return using(async (worker) => {
          const response = await worker.fetch(input, now);
          // Counted before the call stops being pending, so a drained worker
          // never closes between the two.
          held.reading++;
          return readTracked(response, () => {
            held.reading--;
            held.settle();
          });
        }, held);
      },
      ready: () => (closed ? Promise.reject(closedError()) : using((worker) => worker.ready())),
      close: () => {
        if (closed) return;
        closed = true;
        clearTimeout(idle);
        use?.close();
        use = undefined;
        // A drained worker of the group closes with it.
        for (const held of this.#holders.values()) if (held.group === group) held.close();
        if (this.#groups.get(key) === group) this.#groups.delete(key);
      },
    };
    return group;
  }

  // A group's ReplacingWorker starts each worker here. The worker holds its
  // place in the budget until `signal`, its lifetime, aborts.
  async #start(signal: AbortSignal, use: Use<W>): Promise<W> {
    // A group closed before its start ran takes nothing: a spare claimed
    // with a signal already aborted would never free its place.
    if (this.#closed || signal.aborted) throw closedError();
    const spare = this.#spares.shift();
    if (spare) {
      spare.claim(signal);
      this.#hold(signal, use);
      this.#refill();
      return spare.worker;
    }
    await this.#acquire(signal);
    if (this.#closed || signal.aborted) {
      this.#release();
      throw closedError();
    }
    signal.addEventListener("abort", () => this.#release(), { once: true });
    this.#hold(signal, use);
    // Drained at once, with nothing pending: start no worker for it.
    if (signal.aborted) throw closedError();
    return this.#options.start(signal);
  }

  // The worker of `signal` holds a place for `use` until it closes. A group
  // that took a place while others still wait may itself be drained, so the
  // place is released on `signal` before this runs.
  #hold(signal: AbortSignal, use: Use<W>): void {
    this.#holders.set(signal, use);
    signal.addEventListener("abort", () => this.#holders.delete(signal), { once: true });
    this.#turnover();
  }

  // Drain as many holders as there are waiting groups no drained holder will
  // free a place for, least recently used first.
  #turnover(): void {
    const holders = [...this.#holders.values()];
    let needed = this.#waiting.length - holders.filter((use) => use.draining).length;
    for (const use of holders.filter((use) => !use.draining).sort((a, b) => a.lastUse - b.lastUse)) {
      if (needed-- <= 0) return;
      use.drain();
    }
  }

  #acquire(signal: AbortSignal): Promise<void> {
    if (this.#live < this.#options.maxWorkers) {
      this.#live++;
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => {
      const waiter: Waiter = {
        grant: () => {
          signal.removeEventListener("abort", onAbort);
          this.#live++;
          resolve();
        },
      };
      const onAbort = () => {
        this.#waiting.splice(this.#waiting.indexOf(waiter), 1);
        reject(closedError());
      };
      signal.addEventListener("abort", onAbort, { once: true });
      this.#waiting.push(waiter);
      this.#turnover();
    });
  }

  // A place in the budget is free: it goes to the longest waiting group, or
  // else to a new spare. A spare that failed before any group took it frees
  // its place without starting another, so a start that keeps failing does
  // not loop.
  #release(refill = true): void {
    this.#live--;
    const next = this.#waiting.shift();
    if (next) next.grant();
    else if (refill) this.#refill();
  }

  #refill(): void {
    const { spare: wanted = 0, maxWorkers, readyTimeoutMs } = this.#options;
    while (!this.#closed && this.#spares.length < wanted && this.#live < maxWorkers && this.#waiting.length === 0) {
      this.#live++;
      const lifetime = new AbortController();
      let claimed = false;
      const worker = Promise.resolve().then(() => this.#options.start(lifetime.signal));
      const spare: Spare<W> = {
        worker,
        lifetime,
        claim: (signal) => {
          claimed = true;
          signal.addEventListener("abort", () => closeSpare(spare, () => this.#release()), { once: true });
        },
      };
      let timer: ReturnType<typeof setTimeout> | undefined;
      const late = new Promise<never>((_, reject) => {
        if (readyTimeoutMs !== undefined) timer = setTimeout(() => reject(new Error("spare not ready in time")), readyTimeoutMs);
      });
      Promise.race([worker.then((w) => w.ready), late])
        .catch(() => {
          if (claimed || this.#closed) return;
          this.#spares.splice(this.#spares.indexOf(spare), 1);
          closeSpare(spare, () => this.#release(false));
        })
        .finally(() => clearTimeout(timer));
      this.#spares.push(spare);
    }
  }
}

function closeSpare<W extends ReplaceableWorker>(spare: Spare<W>, after?: () => void): void {
  spare.lifetime.abort();
  spare.worker.then(
    (worker) => worker.close(),
    () => {},
  );
  after?.();
}
