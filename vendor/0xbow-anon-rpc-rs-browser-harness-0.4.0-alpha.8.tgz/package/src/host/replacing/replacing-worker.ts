// ReplacingWorker (SPEC.md §5.1): a fetch that replaces its worker when the
// worker's route stops carrying calls.

import type { ReplaceableWorker, ReplacingWorkerOptions } from "./types.js";
import { routeHealth } from "./route-health.js";
import { RpcError } from "@0xbow/anon-rpc-rs-harness-core";
import { checkDeadline, closedError, hostOf, initNow, untilAborted } from "./calls.js";

type Slot<W> = {
  worker: Promise<W>;
  health: ReturnType<typeof routeHealth>;
  lifetime: AbortController;
};

/**
 * A `fetch` over a worker it starts on first use and replaces when the
 * worker's route stops carrying calls (see routeHealth). A call that answers
 * with any status shows the route works; one that fails, or outlasts
 * `callTimeoutMs`, counts against it; one its caller aborts counts for
 * nothing. Replacing closes the old worker, which ends the calls still on it.
 * A worker that fails to start is dropped, so a later call tries again rather
 * than every call failing for the rest of the session.
 */
export class ReplacingWorker<W extends ReplaceableWorker = ReplaceableWorker> {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

  #options: ReplacingWorkerOptions<W>;
  #current?: Slot<W>;
  #closed = false;

  constructor(options: ReplacingWorkerOptions<W>) {
    checkDeadline("callTimeoutMs", options.callTimeoutMs);
    checkDeadline("readyTimeoutMs", options.readyTimeoutMs);
    this.#options = options;
    this.fetch = this.#fetch.bind(this);
  }

  /** The worker in use, once a call has started one; it may not be ready yet. */
  get worker(): Promise<W> | undefined {
    return this.#current?.worker;
  }

  /**
   * Start a worker if none is in use, without a call, and settle when it is
   * ready; it rejects as a call waiting for that worker would.
   */
  async ready(): Promise<void> {
    if (this.#closed) throw closedError();
    await (this.#current ??= this.#startSlot()).worker;
  }

  /** Close the worker in use; pending and later calls fail with code `closed`. */
  close(): void {
    this.#closed = true;
    this.#retire(this.#current);
  }

  async #fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    if (this.#closed) throw closedError();
    const signal = init?.signal ?? (typeof input === "object" && "signal" in input ? input.signal : undefined);
    // The worker takes the call only once it is ready, and a host may reuse
    // init meanwhile.
    init = init && initNow(init);
    const slot = (this.#current ??= this.#startSlot());
    const worker = await untilAborted(slot.worker, signal);
    // The deadline runs from here: waiting for a worker to start is not the
    // route's fault, and counting it would replace a worker still starting.
    // It ends at the response; the caller's signal still ends the body.
    const call = new AbortController();
    let timedOut = false;
    // Abandoned, as the crate counts it: the caller left before the call
    // settled, not merely a call that failed and was aborted after.
    let abandoned = false;
    const onAbort = () => {
      abandoned = true;
      call.abort(signal?.reason);
    };
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) onAbort();
    const timer =
      this.#options.callTimeoutMs === undefined
        ? undefined
        : setTimeout(() => {
            timedOut = true;
            call.abort();
          }, this.#options.callTimeoutMs);
    const host = hostOf(input);
    const answersAtSend = slot.health.sent(host);
    try {
      const response = await untilAborted(worker.fetch(input, { ...init, signal: call.signal }), call.signal);
      slot.health.settled(host, "answered", answersAtSend);
      return response;
    } catch (error) {
      signal?.removeEventListener("abort", onAbort);
      const outcome = timedOut ? "timeout" : abandoned ? "abandoned" : "failed";
      if (slot.health.settled(host, outcome, answersAtSend)) this.#retire(slot);
      if (timedOut) {
        throw new RpcError({ name: "TimeoutError", message: "the worker did not answer in time", code: "timeout" });
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  #startSlot(): Slot<W> {
    const lifetime = new AbortController();
    const slot: Slot<W> = { lifetime, health: routeHealth(), worker: undefined as unknown as Promise<W> };
    slot.worker = (async () => {
      // Retiring the slot fails whatever it is still waiting for.
      const retired = new Promise<never>((_, reject) =>
        lifetime.signal.addEventListener("abort", () => reject(closedError()), { once: true }),
      );
      retired.catch(() => {});
      const started = Promise.resolve().then(() => this.#options.start(lifetime.signal));
      started.then(
        (worker) => {
          if (lifetime.signal.aborted) worker.close();
          else lifetime.signal.addEventListener("abort", () => worker.close(), { once: true });
        },
        () => {},
      );
      // The deadline covers `start` as well as `ready`: either may wait on I/O.
      const { readyTimeoutMs } = this.#options;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const late = new Promise<never>((_, reject) => {
        if (readyTimeoutMs === undefined) return;
        timer = setTimeout(
          () => reject(new RpcError({ name: "TimeoutError", message: "the worker did not start in time", code: "timeout" })),
          readyTimeoutMs,
        );
      });
      try {
        const worker = await Promise.race([started, retired, late]);
        await Promise.race([worker.ready, retired, late]);
        return worker;
      } finally {
        clearTimeout(timer);
      }
    })();
    slot.worker.catch(() => this.#retire(slot));
    return slot;
  }

  #retire(slot: Slot<W> | undefined): void {
    if (!slot) return;
    if (this.#current === slot) this.#current = undefined;
    slot.lifetime.abort();
  }
}
