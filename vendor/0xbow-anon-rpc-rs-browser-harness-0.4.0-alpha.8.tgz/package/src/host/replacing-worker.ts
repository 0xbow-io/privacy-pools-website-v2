// A fetch that keeps a worker whose route still carries calls, starting a new
// worker when the one in use stops answering.
//
// A worker keeps the route it picks when it starts. A Nym worker keeps its
// gateway and exit for its whole life, and 7 of 79 fresh boots on desktop
// Chromium and Android Chrome drew an exit that accepted the connection and
// then carried nothing; the worker never reported itself failed, so every
// call on it failed or timed out. A worker that has failed stays failed too
// (§5, §7). Either way the only recovery is a new worker, which picks its
// route again.
//
// SPEC.md §5.1 and §5.2 define ReplacingWorker and WorkerPool, which the
// anon-rpc crate implements for the native lanes. They use nothing but a
// worker's `ready`, `fetch`, and `close`, and avoid AbortSignal.any,
// AbortSignal.timeout, and URL, which React Native lacks or only partly
// implements.

import { RpcError } from "@0xbow/anon-rpc-rs-harness-core";

/** The class of this module's own `timeout` and `closed` failures. */
export { RpcError };
export type { ReplaceableWorker, ReplacingWorkerOptions } from "./replacing/types.js";
export { routeHealth } from "./replacing/route-health.js";
export { ReplacingWorker } from "./replacing/replacing-worker.js";
export { WorkerPool, type WorkerGroup, type WorkerPoolOptions } from "./replacing/worker-pool.js";
