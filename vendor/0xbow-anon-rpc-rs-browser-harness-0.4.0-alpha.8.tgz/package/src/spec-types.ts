// Type surface from SPEC.md (§5, §7–§13), shared by every harness; see
// @0xbow/anon-rpc-rs-harness-core. Re-exported here so this package's own
// imports, and its consumers', keep one path.
export type * from "@0xbow/anon-rpc-rs-harness-core/spec-types";
