# @0xbow/anon-rpc-rs-browser-harness changelog

Changes to this package by version. Specification changes are in the
[specification changelog](../../CHANGELOG.md); this package implements the
spec version named in its README. Every first-party package shares the
workspace version.

## 0.4.0-alpha.8 (2026-10-26)

No changes to this package. It is released at the workspace version.

## 0.4.0-alpha.7 (2026-10-26)

Implements spec 0.4.0 (was 0.3.5). Requires
`@0xbow/anon-rpc-rs-harness-core` at the same version (pinned exactly).

- **Changed (breaking): per-call options replace worker-defined fields**
  (spec §9.1, §9.3). Every key of a `fetch` init that §9.1 does not model
  reaches the worker in `requestInit`: `anonOptions`, standard fields such
  as `cache`, and anything else. Values are copied when `fetch` is called,
  and a value that is not a §9.4 plain value rejects the `fetch` with a
  `TypeError` instead of being left out. An isolation key moves from
  `init.isolationKey` to `init.anonOptions.isolationKey`.
- **Added: `anonOptions.isolationKey`** (§9.3), typed on `AnonOptions`.
- **Changed (breaking): `config` must be a §9.4 plain value**: JSON, plus
  `undefined`, `Uint8Array` and `ArrayBuffer`. Anything else (`Date`, `Map`,
  class instances), or a cyclic value, makes the constructor throw a
  `TypeError`, where earlier versions structured-cloned it.
- `fetch` is typed `AnonFetch`, which accepts `anonOptions` and is still
  assignable to `typeof fetch`. New exported types: `AnonFetch`,
  `AnonOptions`, `PlainValue`.
- `ReplacingWorker` and every `WorkerPool` group copy forwarded entries
  when called, and a value that is not plain rejects the call.
- **Changed (breaking): `ReplacingWorker` and `WorkerPool` check their
  deadlines** as the native packages' pools do. A `callTimeoutMs`,
  `readyTimeoutMs` or `idleCloseMs` that is negative, `NaN` or infinite
  throws `unsupported` at construction (or when a group is first used);
  previously a negative call or ready deadline fired at once, and an
  infinite `idleCloseMs` was accepted.
- **Fixed: abandoned calls and isolation hosts match the native pools.**
  A call counts as abandoned only when its caller leaves before it settles; it
  used to count whenever the caller's signal had aborted by the time the
  worker failed it. A URL with no authority is grouped by the whole URL
  instead of losing what follows an `@`.
- **Internal: platform-neutral code moved to
  `@0xbow/anon-rpc-rs-harness-core`**: the spec types, the §4 specifier
  read and hash check, the call and log queues, §9.4 plain-value copying,
  and the §12 error helpers, so the two harnesses share one copy.
  `RpcError`, `SpecifierChainError`, `WorkerHashMismatchError`,
  `normalizeWorkerHash` and every type are still exported here.

## 0.4.0-alpha.6 (2026-10-22)

Implements spec 0.3.5 (was 0.3.2).

- **Added: worker-defined fields** (spec 0.3.5, §9.3). A member of `fetch`'s
  `init` that the Fetch standard's `RequestInit` does not define reaches the
  worker as a member of its `requestInit` when its value is `null`, a
  boolean, a finite number, a string, a `Uint8Array`, or an array or plain
  object of these. It is copied when `fetch` is called and never logged. Any
  other value stays behind and the call is still sent, and a `Request`
  passed as the input carries none. A worker can define per-call options
  this way, such as an isolation key.
- **Added: `WorkerPool`** (spec §5.2). A host that keeps unlinkable traffic
  on separate workers runs one `ReplacingWorker` per isolation group, and
  the pool counts every live worker, spares included, against `maxWorkers`.
  A group that needs a worker past the budget waits, first come first
  served, and never shares another group's worker, while the least recently
  used group gives up its worker once that worker's calls and response
  bodies are done, or at the call deadline. `spare` starts workers ahead for
  the next group, and `idleCloseMs` closes a group's worker after a quiet
  period. On an Android Chrome emulator each worker added 120 to 250 MB,
  four Nym workers left a 4-vCPU device no headroom for first calls, and
  tor-js workers slowed past four. A `maxWorkers` that is not a positive
  integer, a `spare` outside 0 to `maxWorkers`, or a negative `idleCloseMs`
  throws `RpcError` with code `unsupported`. It is also exported from
  `@0xbow/anon-rpc-rs-browser-harness/replacing-worker`.
- **Added: `ReplacingWorker.ready()`** starts a worker without a call and
  settles when it is ready.
- **Changed: `ReplacingWorker` and every `WorkerPool` group read `init` when
  called.** A call that waits for a worker keeps a copy of `init`'s members
  and of its worker-defined fields, so a host that reuses its `init` object
  or replaces a member meanwhile does not change the call; a headers object
  or body the host mutates in place is still shared. Both pass worker-defined
  fields on to the worker in use.
- **Added: `WorkerInit.expectedWorkerHash`** (spec 0.3.3). The harness
  compares it with the specifier's `workerHash()` before obtaining any
  bundle, and `ready` rejects with `WorkerHashMismatchError` (code
  `protocol-error`) when they differ. A value that is not `0x` and 64 hex
  digits throws a `TypeError` with code `unsupported` before anything is
  read.
- **Changed: workers in one page share their boot reads.** The
  `eth_chainId` check and the specifier reads are kept per provider object,
  and the verified bundle by `workerHash` for the life of the page, so a
  second worker of the same specifier starts without repeating them. A
  failure is not kept.
- **Changed: the bundle is transferred into the sandbox, not cloned.** Each
  worker gets a copy of the verified bundle with a transfer list, from the
  page to the iframe and on to the worker, and the page keeps its own for
  the next worker. Four Nym workers starting together on an Android Chrome
  emulator peaked at 679 to 696 MB in the renderer, down from 876 to 880 MB.
- **Fixed: `ReplacingWorker` replaces a silent route at its first
  deadline.** A call that times out while no call to any host answered
  during its deadline now counts against the route even if other calls are
  still waiting. Before, each new host's calls restarted the wait: an
  Android Chrome Nym load waited 225 s for its second worker.
- **Fixed: an aborted `ReplacingWorker` call rejects with the signal's
  reason**, as `AnonRpcWorker.fetch` does, instead of a new `AbortError`.
- **Fixed: storage refuses keys and prefixes that are not strings.** A
  worker's `storage` call with a number or array key fails instead of
  storing a key that listing, clearing, and read-ahead do not expect.

## 0.4.0-alpha.5 (2026-10-21)

Implements spec 0.3.2 (unchanged).

- **Fixed: a worker reads back its stored keys in a few round trips.** A
  tor-js worker starting on a stored directory lists about 9,000 keys and
  reads each with its own `storage.get`, and each read cost a round trip over
  the capability port and an IndexedDB transaction: 22 to 37 s on Android
  Chrome, longer than downloading the directory again, and now 1.7 to 5.1 s.
  A get of the key after
  the previous get in the latest listing now also fetches the keys that
  follow, in one request, with the window doubling to 256 keys while reads
  follow the listing; a read out of that order is still a single get. At
  most one window is held. Values read ahead are dropped on any write from
  the worker, so it always reads its own writes, and one left unread for 5 s
  is read again.
- **Changed: storage operations share IndexedDB transactions.** Every
  operation queued while a transaction runs goes into the next one, in the
  order it arrived; a listing or clear gets a transaction to itself. 3,000
  concurrent writes from a worker, as tor-js makes after downloading its
  directory, took 2 or 3 transactions in Chromium and WebKit and up to about
  60 in Firefox, instead of 3,000. An operation that fails, such as a value
  IndexedDB cannot store, fails alone.
- **Added: `ReplacingWorker`.** A `fetch` that starts a worker on first use
  and starts a new one when the worker's route stops carrying calls, as 7 of
  79 fresh Nym boots did without the worker ever failing. `callTimeoutMs`
  bounds the wait for a response once the worker is ready, and
  `readyTimeoutMs` the wait for a worker to start. It is also published on
  its own as `@0xbow/anon-rpc-rs-browser-harness/replacing-worker`. See
  [Replace a worker whose route fails](README.md#replace-a-worker-whose-route-fails).

## 0.4.0-alpha.4 (2026-10-19)

Implements spec 0.3.2 (unchanged).

- **Changed: the GitHub release is marked Latest.** Releases with a
  pre-release version were published as GitHub pre-releases, which are never
  marked Latest. The package's behaviour is unchanged.

## 0.4.0-alpha.3 (2026-10-18)

Implements spec 0.3.2 (unchanged).

- **Fixed: request headers reach the destination through Nym.** Nym's
  anon-rpc-worker 0.1.0 hands a call's `HeaderList` unchanged to mix-fetch,
  whose reader takes only `{ name: value }` objects, so every request header
  was dropped: a JSON-RPC POST arrived without `Content-Type`, and endpoints
  that require it (Arbitrum, Citrea, and Robinhood Chain among them)
  answered 415. For that bundle hash alone, the harness now also sets each
  header as a named property on the same list. The list's pairs, length, and
  JSON form are unchanged, so a worker that reads `headers` as §9.1 defines it
  sees no difference, and a fixed Nym release, having a new hash, gets the
  plain list.
- **Fixed: tuple headers are converted as fetch converts them.** A
  `[name, value]` list passed as `headers` reached the worker as given, so a
  number or `true` arrived where §9.1 promises strings. Each name and value
  is now converted with `String()`, and one that cannot be converted fails
  the `fetch` call, as `fetch` does.

## 0.4.0-alpha.2 (2026-10-16)

Implements spec 0.3.2 (unchanged).

- **Added: `KNOWN_WORKERS`, `knownWorker()` and `knownWorkerInit()`.** The
  workers adopters.json5 lists (passthrough, tor-js, Nym, and Nox) as frozen
  data: specifier, the chain it is published on, whether the worker
  anonymizes, and the config keys it requires. `knownWorkerInit("nym", {
  rpcProvider })` builds the `WorkerInit`; Nym and Nox need no config, and
  tor-js still needs `gateways`, with no default. The harness boots every
  worker the same way.
- **Added: `WorkerInit.specifierChainId`.** The chain the specifier contract
  is published on. When set, the harness checks the bootstrap provider's
  `eth_chainId` before the §4 reads and fails `ready` with a
  `SpecifierChainError` on any other chain, without reading the specifier.
  The error's `code` is `protocol-error`, the code the native packages fail
  with for the same refusal. It does not restrict the chains the worker's fetches reach. An extension
  of this harness, not part of SPEC.md §5. A `specifierChainId` that is not a
  positive integer throws a `TypeError` with code `unsupported`, as the native
  packages report it.
- **Changed: `AnonRpcWorker.tor()` checks for mainnet.** It now sets
  `specifierChainId: 1`, so its provider receives an `eth_chainId` call
  before the specifier read, and a provider on another chain fails `ready`.
  An empty `gateways` list throws a `TypeError`.
- **Fixed: an aborted KPS dial ends at once.** `@kpstreams/webrtc-client`
  0.2.1 missed an abort that landed while a dial was still setting up, and
  kept the peer connection open until the handshake finished or failed (up to
  15 seconds); a failed setup left it open too. The harness now bundles a
  patched copy of the client (`third_party/PATCHES.md` describes it) and
  depends on `@kpstreams/core` directly.
- **Fixed: `ready` rejects when the iframe's bootstrap never runs.** A host
  page whose Content Security Policy forbids inline script, with no
  `iframeUrl`, left `ready` and every call pending forever. Three seconds after
  the iframe loads without saying it is ready, `ready` now rejects with a
  message naming `iframeUrl`, and a sandbox that cannot construct its Web
  Worker reports that as the worker's failure.
- **Fixed: calls that could hang.** A `Request` whose body was already read,
  or a locked body stream, now fails the call with a `TypeError`, as `fetch`
  does, instead of failing at transfer after the worker took the call; a
  stream locked after `fetch` was called fails its call when the worker
  reaches it, and the worker gets the next call. A failure whose reason is
  `undefined` now fails later calls too.
- **Changed: errors match the native packages.** `close()` fails pending and
  later calls with code `closed`. An `eth_chainId` answer that is not a
  JSON-RPC quantity (including a `0X` prefix) is reported as "not a chain id"
  rather than as a chain mismatch, and an `eth_call` result that is not whole
  bytes of hex fails with code `protocol-error` instead of decoding to zeros.
- **Fixed: storage is released on close.** Teardown closes the IndexedDB
  connection once operations already begun finish.
- **Fixed: a `Request` body reaches the worker in Firefox.** Firefox has no
  `Request.body` stream, so `fetch(new Request(url, { method: "POST", body }))`
  sent the request without its body. The harness now reads the bytes where
  the engine exposes no stream.
- **Fixed: `close()` stops a boot in progress.** Closing a worker that was
  still reading its specifier, downloading its bundle, or waiting for its
  iframe used to reject `ready` and leave the boot running: a late resolver
  response went on to create the iframe and start the worker after the close,
  and a close during the iframe wait left the boot suspended. The boot now runs
  under the worker's lifetime: `close()` cancels the HTTP or KPS download in
  flight (the KPS dial keeps its 15-second deadline), skips the remaining
  specifier read and resolvers, and a provider, fetch or dial that completes
  after the close is ignored, with any stream it delivers closed.
- **Fixed: a fatal failure tears the worker down.** After `signalFailed()`, an
  uncaught worker error, or a failed boot, the iframe, the Web Worker inside
  it, the capability channel and the worker's KPS connections are released, as
  `close()` releases them. Previously the failed worker kept running until the
  host called `close()`. Retained log entries stay readable (§13.1).
- **Fixed: a call made just before a close or failure settles.** `fetch()`
  normalizes its request asynchronously; a close or failure in that gap used to
  leave the call pending forever. It now rejects with the failure.
- **Fixed: a response body ends with its call.** A streamed body still
  arriving when the caller aborted, or when the worker closed or failed, kept
  the caller waiting on the next chunk. It now errors with the abort reason or
  the failure, and the worker's stream is cancelled (§9.2).
- **Fixed: KPS workers run on Safari before 27 and iOS.** Safari 26 and
  earlier cannot transfer a `ReadableStream` or `WritableStream` over
  `postMessage`, so every KPS stream, and every streamed request or response
  body, failed to cross into the sandbox: Nox and tor-js never became ready.
  Stream bytes now cross as messages, a chunk per call with backpressure
  kept, in every browser. A relayed stream reads up to 16 chunks ahead of
  its reader, fewer for chunks over 64 KB (about 1 MiB, judged by the last
  chunk), so a streamed response body arrives faster than a transferred
  stream did: at 64 KB chunks, about 2.5 times as fast in Firefox and 7 times
  in WebKit. The README states the browser floor (Chrome 100, Firefox 100,
  Safari 15.4) and the versions tested.
- **Fixed: worker logs echoed to the console describe bytes at any depth.**
  Only a top-level `Uint8Array` was shown as `<n bytes>`; bytes inside an
  array or object were printed (§14).
- **Fixed: a worker's KPS dial without a signal times out again.** The kps
  client applies its 15-second dial deadline only when the caller passes no
  signal, and the bridge always passed one, so a worker dialling an
  unreachable peer without a signal of its own waited until the WebRTC
  handshake gave up. The bridge now restores the default for those dials; a
  worker that passes a signal still owns the deadline.
- **Fixed: the KPS bridge releases late connections.** A worker's `kps.dial`
  or `kps.openStream` still in flight when the worker is torn down is aborted,
  and one that completes anyway is closed instead of registered.
- **Fixed: worker bundles load on Firefox.** Firefox refuses
  `importScripts(blob:)` in a worker whose origin is opaque, which §6 makes
  the harness's worker, even for a blob the worker created itself and even
  when a CSP allows `blob:` (measured on Firefox 140 and 157). The worker
  runtime now probes with an empty blob script and, where that is refused,
  imports the verified bundle as a `data:` URL instead, with the same
  classic-script semantics. Other browsers keep using `blob:`. Probing first,
  rather than retrying after a failure, means a bundle whose top level throws
  is never run twice.
- **Integrators with a bootstrap page under a strict CSP** (`iframeUrl`): on
  Firefox, allow `data:` in that page's `script-src` wherever a policy applies
  there. Chromium needs no change.

Earlier releases are recorded in the git history.
