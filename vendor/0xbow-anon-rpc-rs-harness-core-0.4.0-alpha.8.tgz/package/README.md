# @0xbow/anon-rpc-rs-harness-core

The parts of an [anon-rpc](https://github.com/ethereum/anon-rpc) harness that
are independent of where the harness runs. The browser harness and the browser
extension harness each wrap these parts in a different transport and isolation
boundary, and sharing them keeps the harnesses in agreement. The harnesses
depend on this package; wallets and workers don't install it.

Tracks the [anon-rpc specification](../../SPEC.md)
version **0.4.0**. The package version, without its pre-release suffix, is
at least that spec version, and `npm test` checks both.

The package provides the following:

- **Spec types** (`@0xbow/anon-rpc-rs-harness-core/spec-types`): the §5 and
  §7 to §13 type surface. Worker templates carry a copy of `worker-types.ts`,
  which `cargo xtask generate` writes, so a worker builds with no harness
  dependency.
- **`readSpecifier` / `fetchAndVerifyBundle`** (§4): the specifier read
  through a bootstrap provider, the resolver fetch, and the keccak256 check.
  A harness that has a transport passes in the entry kinds that need it, such
  as `kps:`, as a `ResolverKind`. Without one, `fetchAndVerifyBundle` ignores
  those entries, as §4.1 requires. `checkSpecifierChain` and
  `normalizeWorkerHash` check `specifierChainId` and `expectedWorkerHash`
  (§5) first.
- **`CallQueue`** (§8): ordered, no-drop, one-at-a-time inbound calls.
- **`LogQueue`** (§13.1): ordered, bounded log retention.
- **`copyPlainValue`, `encodePlain` / `decodePlain`** (§9.4): copying plain
  values, and encoding them for a boundary that takes only JSON.
- **`copyForwardedEntries`** (§9.1): the fetch-init entries forwarded to the
  worker, copied at call time. Every harness calls it synchronously in its
  `fetch`, before the first `await`.
- **`RpcError` / `serializeError`** (§12): errors that keep `name` and `code`
  across a boundary.

## License

MIT
