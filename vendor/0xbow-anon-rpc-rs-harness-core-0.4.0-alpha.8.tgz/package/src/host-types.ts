// Host-facing type surface from SPEC.md (§5): what an embedder hands a
// harness, and what it collects from one.

import type { AnonOptions, LogArg, PlainValue } from "./worker-types.js";

/* §5 — Host-side harness API */

export type RpcProvider = {
  // Minimal EIP-1193-ish provider: enough to read a specifier contract.
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
};

export type WorkerInit = {
  // The specifier contract address.
  address: string;
  // Delivered to the worker as `anonRpcWorker.config` (§7.1). A plain value
  // (§9.4); opaque to the harness — its schema is defined by the worker.
  config?: PlainValue;
  // Where a browser harness loads its null-origin document from, for an
  // embedder whose CSP will not let the harness construct one inline (§6).
  // A harness that does not use an iframe MUST ignore it.
  iframeUrl?: string;
  // The chain the specifier contract is published on, which is the chain
  // `rpcProvider` must answer for. Not the chain the worker's anonymized
  // fetches reach: a worker published on a testnet can carry mainnet calls.
  // When set, the harness asks `rpcProvider` for `eth_chainId` before the §4
  // reads and fails with a SpecifierChainError on any other answer, rather
  // than reading whatever is, or is not, at that address on another chain.
  // An extension of this harness; SPEC.md §5 does not define it.
  specifierChainId?: number;
  // The bundle hash the host requires (§5), as 0x and 64 hex digits in either
  // case. When set, the harness compares it with the specifier's workerHash()
  // before obtaining any bundle and fails with a WorkerHashMismatchError when
  // they differ.
  expectedWorkerHash?: string;
  preExisting?: {
    rpcProvider?: RpcProvider;
  };
};

/** §5/§13.1: one log call, as the host collects it through `acceptLog()`. */
export type LogEntry = {
  level: "debug" | "info" | "warn" | "error";
  args: LogArg[];
};

/** §5/§9.1: the host-side fetch. Assignable to `typeof fetch`. */
export type AnonFetch = (
  input: RequestInfo | URL,
  init?: RequestInit & { anonOptions?: AnonOptions },
) => Promise<Response>;
