# @0xbow/anon-rpc-rs-harness-core changelog

Changes to this package by version. Specification changes are in the
[specification changelog](../../CHANGELOG.md). Every first-party package
shares the workspace version.

## 0.4.0-alpha.8 (2026-10-26)

No changes to this package. It is released at the workspace version.

## 0.4.0-alpha.7 (2026-10-26)

Tracks spec 0.4.0. First release: the platform-neutral code the browser
harness and the browser extension harness each carried, now in one place.

- Spec types, `CallQueue`, `LogQueue`, `readSpecifier` /
  `fetchAndVerifyBundle` with the `specifierChainId` and
  `expectedWorkerHash` checks, `copyPlainValue`, `RpcError` /
  `serializeError`.
- `fetchAndVerifyBundle` takes extra `ResolverKind` values, so a harness passes
  the `kps:` kind only where it has KPS.
- `CallQueue.rejectAll` returns the items it dropped, so the caller settles
  them.
- `copyForwardedEntries` (§9.1): one implementation of which init entries
  are forwarded and how they are copied.
- `encodePlain` / `decodePlain`: one JSON encoding of §9.4 plain values,
  with bytes as hex, for the extension's messaging hop.
