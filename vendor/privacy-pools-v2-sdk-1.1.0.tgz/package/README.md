# @0xbow/privacy-pools-v2-sdk

TypeScript SDK for Privacy Pools V2 on EVM chains.

This package is `@privacy-pools-v2/evm-sdk` with the chain-agnostic `@privacy-pools-v2/core-sdk` inlined, so a single install covers it. It handles protocol crypto, note and keystore management, Groth16 proof generation, pool sessions, viem- and LiFi-backed chain adapters, and the stealth-address module. Everything core-sdk exports is re-exported from the root entry.

For Privacy Pools V1, use [`@0xbow/privacy-pools-core-sdk`](https://www.npmjs.com/package/@0xbow/privacy-pools-core-sdk).

## Install

```bash
npm install @0xbow/privacy-pools-v2-sdk
# or
pnpm add @0xbow/privacy-pools-v2-sdk
```

Code written against the pre-release tarballs imports `@privacy-pools-v2/sdk`. It keeps working unchanged with an npm alias:

```json
{
  "dependencies": {
    "@privacy-pools-v2/sdk": "npm:@0xbow/privacy-pools-v2-sdk@1.1.0"
  }
}
```

## Entry points

| Import | Contents |
|---|---|
| `@0xbow/privacy-pools-v2-sdk` | Everything: core-sdk plus the EVM adapters, `PoolSessionBuilder`, `createEvmPoolSession`, services, ABIs and constants |
| `@0xbow/privacy-pools-v2-sdk/batch-fee` | `computeBatchFees`, `computeBatchItemFee`, `MAX_BATCH`. Free of the crypto dependencies, so CommonJS consumers can `require` it |
| `@0xbow/privacy-pools-v2-sdk/stealth` | Stealth-address derivation and scanning (canonical and FluidKey schemes) |

Every entry point ships as ESM (`.js`) and CommonJS (`.cjs`), with type declarations for both.

## Getting started

```ts
import { DEFAULT_CIRCUIT_MANIFEST, PoolSessionBuilder } from "@0xbow/privacy-pools-v2-sdk";

const session = await PoolSessionBuilder.create({
  chainId,
  rpcUrl,
  deployment, // contract addresses, see below
  // ...keys, ASP, relayers, circuit artifacts
});
```

- **Contract addresses.** `DEPLOYMENTS` (the built-in fallback for `deployment`) only lists Sepolia, and `YIELD_DEPLOYMENTS` is empty. On every other chain, pass `deployment` explicitly.
- **Circuit artifacts.** `DEFAULT_CIRCUIT_MANIFEST` pins IPFS CIDs and sha256 digests for the deposit, ragequit and `transact_NxM` circuits. Since 1.0.1 they are the trusted-setup ceremony keys; proofs built with the 1.0.0 keys no longer verify once a chain's verifiers are rotated. The SDK checks every downloaded artifact against those digests. To serve the files yourself, point `LocalCircuitArtifacts` at a directory with the same layout.

## License

MIT. See `LICENSE`. `THIRD_PARTY_NOTICES.txt` covers the third-party code bundled into `dist/`.

Runtime dependencies are installed from npm under their own licenses. These include `snarkjs` and `circomlibjs`, which are GPL-3.0.
