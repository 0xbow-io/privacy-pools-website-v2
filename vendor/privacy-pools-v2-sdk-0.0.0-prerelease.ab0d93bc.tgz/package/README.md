# @privacy-pools-v2/sdk

TypeScript SDK for [Privacy Pools V2](https://github.com/0xbow/privacy-pools-v2) — a protocol for compliant, privacy-preserving token transfers on Ethereum.

The SDK provides a single entry point (`PoolSession`) that orchestrates the full lifecycle of private deposits, transfers, withdrawals, and emergency ragequits, including ZK proof generation, witness construction, and on-chain calldata encoding.

## Table of Contents

- [Overview](#overview)
- [Key Concepts](#key-concepts)
- [Architecture](#architecture)
- [Setup](#setup)
- [Quick Start](#quick-start)
- [API Reference](#api-reference)
- [Configuration](#configuration)
- [Advanced Usage](#advanced-usage)
- [Development](#development)
- [License](#license)

## Overview

Privacy Pools V2 enables users to deposit, transfer, and withdraw tokens while maintaining privacy through zero-knowledge proofs. An Association Set Provider (ASP) ensures regulatory compliance without compromising user privacy.

The SDK handles:

- **ZK Proof Generation** — Groth16 proofs for deposit, transact, and ragequit circuits
- **Witness Construction** — Automatic building of circuit inputs from on-chain and local state
- **Calldata Encoding** — Ready-to-submit transaction data for all pool operations
- **Key Management** — Keystore registration, key derivation, and viewing key management
- **Note Lifecycle** — Tracking note states from creation through spending or exit
- **Relayer Integration** — Fee quotes and transaction submission via relayers for gas privacy
- **Account Portability** — Export and import of full account state for backup or migration

## Key Concepts

### Notes

A **note** represents a private balance inside the pool. Each note has a commitment (published on-chain) and secret metadata (known only to the owner). Notes transition through states: `INACTIVE` -> `PENDING` -> `ACTIVE` -> `SPENT` or `EXITED`.

### Labels and Lineages

Every deposit creates a unique **label** — a cryptographic identifier that ties a deposit to all its downstream notes. When a note is spent, output notes inherit the same label, forming a **lineage**. Value is conserved within each lineage.

### Association Set Provider (ASP)

The ASP maintains a set of approved labels. To spend a note, users must prove their label is in the ASP's association set. This enables compliance without revealing transaction details.

### Keystore

Users register cryptographic keys on-chain via the **keystore**: a nullifying key (for spending), a revocable key (for authorization updates), and a viewing key pair (for note discovery by third parties).

### Ragequit

An emergency escape hatch that allows withdrawing funds directly without ASP approval. The label becomes public, but funds are always recoverable.

## Architecture

The SDK follows the **Facade pattern**. `PoolSession` is the sole public-facing API, delegating to specialized internal sessions:

```
PoolSession (Public Facade)
├── PoolSessionDeposit       — Deposit preparation and proof generation
├── PoolSessionTransfer      — Private transfer preparation and relay
├── PoolSessionWithdraw      — Withdrawal preparation and relay
├── PoolSessionBatchWithdraw — Full-balance batch withdrawal (N transacts, one tx)
├── PoolSessionKeystore      — Keystore registration checks and calldata
├── PoolSessionRagequit      — Emergency exit preparation
└── PoolSessionExport        — Account state export/import
```

Supporting services:

| Service | Role |
|---|---|
| `CryptoService` | ECDH, AES encrypt/decrypt, key derivation |
| `ProofService` | Groth16 proof generation and verification |
| `WitnessPreparationService` | Builds circuit witness objects from state |
| `PoseidonHashService` | Poseidon hashing for commitments and nullifiers |
| `MerkleService` | Merkle tree operations for inclusion proofs |
| `NoteManager` | Note state, lineage tracking, balance aggregation |
| `KeystoreManager` | Private key material and registration status |
| `ContractInteractor` | On-chain reads and transaction encoding |
| `RelayerInteractor` | Relayer fee quotes and transaction relay |
| `ASPClient` | Association set data retrieval |

All dependencies are injected via interfaces, making every external interaction (RPC, wallet, storage) replaceable with custom implementations.

## Setup

### Prerequisites

- [Node.js](https://nodejs.org/) >= 18
- [pnpm](https://pnpm.io/) >= 9
- [git-lfs](https://git-lfs.com/) — required for circuit artifacts (WASM and zkey files)

### Installation

```bash
# 1. Install git-lfs and initialize it
git lfs install

# 2. Clone the repository (git-lfs will automatically pull circuit artifacts)
git clone https://github.com/0xbow/privacy-pools-v2.git
cd privacy-pools-v2

# 3. Install dependencies
pnpm install

# 4. Build the SDK
pnpm --filter @privacy-pools-v2/sdk build
```

> **Important:** Do **not** rebuild the circuits package. The pre-built circuit artifacts (WASM and zkey files) are stored via git-lfs and must be used as-is to ensure proof compatibility with the deployed contracts. Rebuilding circuits would produce different artifacts and generate incompatible proofs.

### Build Output

The build produces dual ESM/CJS output in `dist/`:

- `dist/index.js` — ES Modules
- `dist/index.cjs` — CommonJS
- `dist/index.d.ts` — TypeScript declarations

## Quick Start

### 1. Create a Pool Session

Use `PoolSessionBuilder.create()` for a one-call setup with sane defaults. Contract addresses default to `DEPLOYMENTS[chainId]` (Sepolia shipped; mainnet pending) — pass `deployment` explicitly to override for chains not in the manifest, forked deployments, or local test rigs.

```typescript
import { DEFAULT_CIRCUIT_MANIFEST, PoolSessionBuilder } from "@privacy-pools-v2/sdk";

const session = await PoolSessionBuilder.create({
  chainId: 11155111, // Sepolia — addresses resolved from DEPLOYMENTS
  rpcUrl: "https://sepolia.example.com",
  ownerAddress: "0xYourAddress",
  protocolKeys: {
    privateNullifyingKey: "0x...",
    privateRevocableKey: "0x...",
    viewingPrivateKey: "0x...",
    viewingPublicKey: "0x...",
  },
  aspUrl: "https://asp.example.com",
  // Circuit artifacts are fetched from IPFS. The manifest must be explicit:
  // DEFAULT_CIRCUIT_MANIFEST ties proof correctness to this SDK version.
  circuitGatewayUrls: ["https://gateway.pinata.cloud/ipfs"],
  circuitManifest: DEFAULT_CIRCUIT_MANIFEST,
  relayers: [
    {
      name: "0xBow Relayer",
      url: "https://relayer.example.com",
      address: "0xRelayerAddress",
      processorAddress: "0xProcessorAddress",
      chainId: 11155111,
      chainType: "evm",
      status: "active",
    },
  ],
});
```

For advanced dependency injection (custom `ICryptoService`, hardware-backed signing, etc.), seed the builder with `.fromConfig()` then chain `.withX()` overrides:

```typescript
const session = await PoolSessionBuilder.fromConfig(config)
  .withNoteManager(myNoteManager)
  .withRpcInteractor(mySharedRpc)
  .create();
```

Config is atomic — passed once to `.fromConfig()`. `.withX()` methods come after; `.create()` is terminal with no args. Overrides whose config sibling is already present in `config` are compile-time errors at the call site (e.g. calling `.withKeystoreManager()` when `config.protocolKeys` was set). `PoolSessionBuilder.create(config)` is sugar for `.fromConfig(config).create()`.

`PoolSessionFactory.create(config, deps?)` remains as the full DI escape hatch for integrators who want to supply every service manually.

### 2. Register Keystore (One-Time)

Before any pool operation, register your keys on-chain:

```typescript
const registered = await session.isKeystoreRegistered();

if (!registered) {
  const result = await session.prepareRegisterKeystore();
  // Submit result.setAuthPolicyTx and result.setViewingKeyTx on-chain
}
```

### 3. Deposit

```typescript
const deposit = await session.prepareDeposit({
  tokenAddress: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", // ETH
  amount: "0xDE0B6B3A7640000", // 1 ETH in wei (hex)
});

// For ERC-20 tokens, check if an approval transaction is needed
if (deposit.approvalTx) {
  // Submit deposit.approvalTx first
}

// Submit deposit.depositTx on-chain
```

### 4. Transfer

```typescript
const transfer = await session.prepareTransfer({
  commitment: "0xNoteCommitment",       // Note to spend
  recipientAddressHash: "0xRecipient",  // Recipient's obfuscated address
  amount: "0x6F05B59D3B20000",          // 0.5 ETH in wei (hex)
});

// Submit via relayer for gas privacy
const txHash = await session.relayTransfer({
  quote: transfer.quote,
  proof: transfer.proof,
  encryptedPayload: transfer.encryptedPayload,
});
```

### 5. Withdraw

```typescript
const withdrawal = await session.prepareWithdraw({
  commitment: "0xNoteCommitment",
  amount: "0x6F05B59D3B20000",
  recipient: "0xRecipientAddress",
});

// Submit via relayer
const txHash = await session.relayWithdraw({
  quote: withdrawal.quote,
  proof: withdrawal.proof,
  encryptedPayload: withdrawal.encryptedPayload,
  recipient: "0xRecipientAddress",
});
```

### 5b. Batch Withdraw (entire balance in one tx)

Withdraw a user's **entire** balance of an asset to a single recipient in one on-chain
transaction. The `transact` circuit spends at most 5 notes, so the SDK partitions all
active notes into ≤5-note groups and builds one proof per group; the relayer submits them
as a single `relayBatch`. Fees are quote-first and per-item (each group is priced as a
normal single-tx withdrawal). See `docs/tech-design/sdk/batch-withdraw.md` for the full API.

```typescript
// Quote-first, then relay — the session handles note selection, the aggregate
// quote, per-item proof generation, and submission.
const batch = await session.prepareBatchWithdraw({
  tokenId: "0xTokenAddress",
  recipientAddress: "0xRecipientAddress",
});

const receipt = await session.relayBatchWithdraw(batch);
```

### 6. Ragequit (Emergency Exit)

```typescript
const ragequit = await session.prepareRageQuit({
  commitment: "0xNoteCommitment",
});

// Submit ragequit.tx on-chain — funds go directly to ownerAddress
```

## API Reference

### PoolSession

| Method | Description |
|---|---|
| `prepareDeposit(params)` | Prepare a deposit with ZK proof and calldata |
| `prepareDepositFor(params)` | Prepare a deposit on behalf of a recipient (cold start) |
| `prepareTransfer(params)` | Prepare a private transfer with ZK proof |
| `relayTransfer(params)` | Submit a prepared transfer via relayer |
| `prepareWithdraw(params)` | Prepare a withdrawal with ZK proof |
| `relayWithdraw(params)` | Submit a prepared withdrawal via relayer |
| `isKeystoreRegistered()` | Check if the account keystore is registered on-chain |
| `prepareRegisterKeystore(options?)` | Prepare keystore registration calldata |
| `prepareRageQuit(params)` | Prepare an emergency exit with ZK proof |
| `exportAccount()` | Serialize full account state for backup |
| `importAccount(data)` | Restore account state from a previous export |

### Data Format

All values entering and leaving the SDK are `Hex` strings (`0x`-prefixed). This includes amounts, commitments, addresses, hashes, and keys. The SDK handles all internal conversions.

## Configuration

### PoolSessionConfig

| Field | Type | Required | Description |
|---|---|---|---|
| `ownerAddress` | `Address` | Yes | Account owner's Ethereum address |
| `chainId` | `number` | Yes | Target chain ID |
| `poolAddress` | `Address` | Yes | PoolVault contract address |
| `cryptoService` | `ICryptoService` | Yes | ECDH, encryption, key derivation |
| `witnessPreparationService` | `IWitnessPreparationService` | Yes | Circuit witness builder |
| `proofService` | `IProofService` | Yes | ZK proof generator |
| `entrypointInteractor` | `IEntrypointInteractor` | Yes | Entrypoint contract reader |
| `noteManager` | `INoteManager` | Yes | Note state manager |
| `keystoreManager` | `IKeystoreManager` | Yes | Key material provider |
| `keystoreInteractor` | `IKeystoreInteractor` | Yes | Keystore contract reader |
| `hashService` | `IHashService` | Yes | Poseidon hash function |
| `aspClient` | `IASPClient` | Yes | Association set data provider |
| `relayerInteractor` | `IRelayerInteractor` | Yes | Relayer communication |
| `poolVaultInteractor` | `IPoolVaultInteractor` | No | State tree queries (required for transfers/withdrawals) |

### PoolSessionDependencies

| Field | Type | Required | Description |
|---|---|---|---|
| `logger` | `ILogger` | No | Logger shared across all internal sessions |

## Advanced Usage

### Custom Implementations

Every external dependency is defined as an interface. You can provide custom implementations for any of them:

```typescript
import type { IRPCInteractor } from "@privacy-pools-v2/sdk";

class MyCustomRPC implements IRPCInteractor {
  // Your custom RPC implementation
}
```

### Circuit Artifacts

The SDK uses `LocalCircuitArtifacts` by default to load circuit artifacts (WASM and zkey files) from the local filesystem. These artifacts are managed via git-lfs in the monorepo.

### Account Export/Import

Back up and restore account state across sessions or devices:

```typescript
// Export
const backup = session.exportAccount();
// Persist `backup` to your storage of choice

// Import in a new session
session.importAccount(backup);
```

Keys are excluded from exports — they must always be provided at construction time.

## Development

### Commands

```bash
# Build
pnpm --filter @privacy-pools-v2/sdk build

# Run tests
pnpm --filter @privacy-pools-v2/sdk test

# Lint
pnpm --filter @privacy-pools-v2/sdk lint

# Format
pnpm --filter @privacy-pools-v2/sdk format
```

### Testing

Tests use [Vitest](https://vitest.dev/) and are organized as:

- **Unit tests** — `test/unit/services/` (one file per service)
- **Integration tests** — `test/services/` (real circuit artifacts and proving)

```bash
# Run all tests
pnpm --filter @privacy-pools-v2/sdk test

# Run a specific test file
pnpm --filter @privacy-pools-v2/sdk test -- test/unit/services/NoteManager.test.ts
```

### Project Structure

```
packages/sdk/
├── src/
│   ├── interfaces/      # Service interfaces (contracts)
│   ├── types/           # TypeScript type definitions and DTOs
│   ├── schemas/         # Zod runtime validation schemas
│   ├── services/        # Service implementations
│   ├── errors/          # Typed error classes (one per service)
│   ├── constant/        # Service class name constants
│   ├── utils/           # Logging and helper utilities
│   ├── external.ts      # Public API exports
│   └── internal.ts      # Internal barrel exports
├── test/
│   ├── unit/services/   # Unit tests
│   └── services/        # Integration tests
├── package.json
├── tsconfig.json
├── tsup.config.ts       # Build configuration (ESM + CJS)
└── vitest.config.ts     # Test configuration
```

## License

MIT
