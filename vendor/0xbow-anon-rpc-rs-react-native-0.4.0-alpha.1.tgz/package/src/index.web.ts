// The web entry: the browser harness itself, whose `AnonRpcWorker.tor` takes
// `{gateways, rpcProvider, iframeUrl?}` and runs tor-js.
export { AnonRpcWorker, RpcError } from "@0xbow/anon-rpc-rs-browser-harness";
export type { LogArg, LogEntry, RpcProvider, WorkerInit } from "@0xbow/anon-rpc-rs-browser-harness";
export { ErrorCode } from "./error-code.g";
