# @0xbow/anon-rpc-rs-react-native

Anonymized HTTP for React Native and Expo apps on iOS, Android, and web. `AnonRpcWorker` is the browser harness's [`AnonRpcWorker`](../../impl/browser-harness/) API, name for name, so viem and ethers code moves over unchanged: construct it from a specifier address, optionally await `ready`, `fetch`, pull logs with `acceptLog`, and `close()`. On iOS and Android a native module calls the [Swift](../swift/) and [Kotlin](../kotlin/) SDKs, which run the hash-pinned worker bundle in an embedded sandbox, or send every request over a native [Arti](https://gitlab.torproject.org/tpo/core/arti) Tor client with `AnonRpcWorker.tor()`. On web, the same import is the browser harness itself.

Requires React Native 0.81 or later, on the New Architecture, where the module is a TurboModule, or on React Native 0.81's legacy architecture. Expo apps need SDK 54 or later and a development build (`npx expo prebuild`); Expo Go does not include the module. React Native 0.81's `fmt` pod does not compile as C++20 under Xcode 27; [`example-legacy/fmt-cxx17.plugin.js`](example-legacy/fmt-cxx17.plugin.js) is a config plugin that builds it as C++17.

## Setup

The package and the browser harness it depends on are assets of this repository's GitHub releases. The repository is private, so downloading them with [`gh`](https://cli.github.com/) needs an account with read access to it. Download both into `vendor/`:

```sh
gh release download v0.4.0-alpha.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-react-native-0.4.0-alpha.1.tgz'
gh release download v0.4.0-alpha.1 --repo 0xbow-io/anon-rpc-rs --dir vendor --pattern '0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.1.tgz'
```

Then depend on the package's tarball, and resolve its browser harness dependency from the browser harness's tarball with the override field your package manager reads. npm and Bun read `overrides`:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-alpha.1.tgz"
  },
  "overrides": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.1.tgz"
  }
}
```

pnpm reads it under `pnpm.overrides`:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-alpha.1.tgz"
  },
  "pnpm": {
    "overrides": {
      "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.1.tgz"
    }
  }
}
```

Yarn 4, with `nodeLinker: node-modules` in `.yarnrc.yml`, reads it under `resolutions`:

```json
{
  "dependencies": {
    "@0xbow/anon-rpc-rs-react-native": "file:./vendor/0xbow-anon-rpc-rs-react-native-0.4.0-alpha.1.tgz"
  },
  "resolutions": {
    "@0xbow/anon-rpc-rs-browser-harness": "file:./vendor/0xbow-anon-rpc-rs-browser-harness-0.4.0-alpha.1.tgz"
  }
}
```

1. Add the dependency above to the app, and the package's config plugin to `app.json`: `"plugins": ["@0xbow/anon-rpc-rs-react-native"]`.
2. Run `npx expo prebuild`, then build as usual.

The package carries the Swift and Kotlin SDKs prebuilt, so an app build needs no Rust toolchain, on EAS Build as on your own machine. The config plugin adds the bundled `AnonRpc` pod to the Podfile; an app without Expo adds `pod 'AnonRpc', :path => '../node_modules/@0xbow/anon-rpc-rs-react-native/native/ios'` itself. On Android the module adds the bundled Maven repository, which holds `io.0xbow:anon-rpc-rs`, to every Gradle project of the app.

Inside this repository, build the bundled SDKs from source first with `npm --prefix packages/react-native run build:native`, which needs Xcode and the Rust iOS targets as [`packages/swift`](../swift/) describes, and the Android NDK, `cargo-ndk`, and the Rust Android targets as [`packages/kotlin`](../kotlin/) describes. `ANON_RPC_ABIS=x86_64` limits the Android build to the ABIs it names.

## Quick start

```ts
import { AnonRpcWorker } from "@0xbow/anon-rpc-rs-react-native";

const worker = new AnonRpcWorker({
  // The anonymizing network's specifier contract, on mainnet.
  address: "0x4fd77be300f31c5fe6ab266d35d27750a3478d27",
  preExisting: {
    // Reads the specifier contract once; any EIP-1193-style provider works.
    rpcProvider: {
      request: async ({ method, params }) => {
        const response = await fetch("https://ethereum-rpc.publicnode.com", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
        });
        return ((await response.json()) as { result: unknown }).result;
      },
    },
  },
});

// A standard fetch, routed through the hash-pinned worker.
const res = await worker.fetch("https://ethereum-rpc.publicnode.com", {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_blockNumber", params: [] }),
});
const { result } = (await res.json()) as { result: string };
console.log(result);

worker.close();
```

The address above is the passthrough worker, which fulfills calls with an ordinary fetch: it exercises the sandbox and hash pinning without anonymizing anything. For Tor, construct `AnonRpcWorker.tor()` instead; the sandbox has no `WebAssembly`, so the tor-js worker does not run here.

## Fetch

`fetch` takes the same arguments as the global `fetch` and is bound to its worker, so it works as a free function. React Native's `Response` has no streaming body, so `fetch` resolves once the whole body has arrived, and request bodies are buffered before they are sent. `response.url` is the final URL after redirects. Header fields pass through React Native's `Headers`, which keeps them in the order they were added and joins a repeated field's values with commas, `set-cookie` included. Aborting the request's `signal` cancels the native transfer. `https` URLs are verified inside your app against the Mozilla roots, so a Tor exit sees only ciphertext; `.onion` hosts work too.

## Embedded workers

`new AnonRpcWorker({ address, config, preExisting: { rpcProvider } })` reads the specifier's `workerHash()` and `workerResolvers()` through `rpcProvider`, fetches the bundle from the first resolver that serves bytes with that hash, and runs only those bytes. `AnonRpcWorker.bundle(bytes, { config })` runs bundle bytes you already hold, identified by their keccak256 hash.

- The specifier read and the bundle fetch are not anonymized.
- `config` is `null`, a boolean, a finite number, a string, a `Uint8Array`, an array, or a plain object of these, and reaches the worker as `anonRpcWorker.config`. Any other value throws an `RpcError` with code `unsupported`.
- `storageDir` sets where worker storage lives; it defaults to the app's own directories, as in the Swift and Kotlin SDKs.
- The worker's own `fetch` refuses loopback and private networks unless `allowPrivateNetworks` is set.

## Errors, logs, and directories

Failures are `RpcError`s whose `code` is one of the specification's error codes, listed in `ErrorCode`, or the code a worker gave its own failure. `acceptLog({ signal })` returns the worker's log entries one at a time; an aborted call consumes no entry, and entries retained before `close()` stay readable after it.

`AnonRpcWorker.tor({ stateDir, cacheDir })` names the directories the Tor client uses, by default the app's own.

## Web

On `react-native-web`, the package's `browser` entry re-exports `AnonRpcWorker` and `RpcError` from [`@0xbow/anon-rpc-rs-browser-harness`](../../impl/browser-harness/), which runs workers in a sandboxed iframe. There, `AnonRpcWorker.tor({ gateways, rpcProvider, iframeUrl })` runs the tor-js worker, whose traffic leaves through the KPS `gateways`; `gateways` is required. `config` takes any structured-cloneable value, `iframeUrl` is honored, and response bodies stream.

## Tests

```sh
npm --prefix packages/react-native install
npm --prefix packages/react-native/example install
npm --prefix packages/react-native test
```

`npm test` typechecks the package, runs its JavaScript tests over a fake native module, and checks that the example's Metro web resolution selects the web entry; that check needs the browser harness built (`npm --prefix impl/browser-harness run build`).

Two example apps run the conformance cases through the real module on a simulator or emulator and report them to `check.mjs`: `example` on the New Architecture, and `example-legacy` on the legacy architecture. To run `example-legacy`, install it with `npm --prefix packages/react-native/example-legacy install` and run the steps below from its directory, as `node ../example/check.mjs`. After `npm --prefix packages/react-native run build:native`, from `packages/react-native/example`:

```sh
npx expo prebuild --clean --no-install
(cd ios && pod install && xcodebuild -workspace AnonRpcExample.xcworkspace -scheme AnonRpcExample -configuration Debug -sdk iphonesimulator -destination 'id=<simulator id>' -derivedDataPath build/DerivedData build)
node check.mjs ios ios/build/DerivedData/Build/Products/Debug-iphonesimulator/AnonRpcExample.app <simulator id>
(cd android && ./gradlew :app:assembleDebug)
node check.mjs android android/app/build/outputs/apk/debug/app-debug.apk <emulator serial>
```

The case that fetches over the live Tor network runs only with `ANON_RPC_LIVE=1` in the environment of `check.mjs`.
