package anonrpc.reactnative

import android.util.Base64
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import anonrpc.AnonRpcException
import anonrpc.AnonRpcRequest
import anonrpc.AnonRpcValue
import anonrpc.AnonRpcWireApi
import anonrpc.AnonRpcWorker
import anonrpc.BufferedResponse
import anonrpc.ProviderResponse
import anonrpc.Redirect
import anonrpc.RequestHead
import anonrpc.RpcProvider
import anonrpc.TorConfig
import anonrpc.fromWire
import anonrpc.generated.ErrorCode
import anonrpc.toWire
import java.io.File
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONArray

/**
 * The React Native module's calls, over the anon-rpc Kotlin SDK and its wire
 * codec. Workers and calls are numbered by JavaScript; bytes cross as base64.
 */
@OptIn(AnonRpcWireApi::class)
class AnonRpcModule(private val context: ReactApplicationContext) : NativeAnonRpcSpec(context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val workers = ConcurrentHashMap<Int, AnonRpcWorker>()
    private val calls = ConcurrentHashMap<Int, Job>()
    /** Provider requests awaiting JavaScript, with the worker each belongs to. */
    private val providerRequests = ConcurrentHashMap<Int, Pair<Int, CompletableFuture<String>>>()
    private val nextRequest = AtomicInteger(1)

    override fun getName() = NAME

    override fun invalidate() {
        scope.cancel()
        workers.values.forEach { it.close() }
        super.invalidate()
    }

    /**
     * Send a provider request to JavaScript: through the codegen event
     * emitter, which only the New Architecture wires up, or else as a device
     * event, as the legacy architecture delivers module events.
     */
    private fun emitProviderRequest(request: WritableMap) {
        if (mEventEmitterCallback != null) {
            emitOnProviderRequest(request)
        } else {
            context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit("onProviderRequest", request)
        }
    }

    private fun Promise.fail(error: Throwable) = when (error) {
        is AnonRpcException -> reject(error.workerCode ?: error.code.code, error.message, error)
        is CancellationException -> reject(ErrorCode.CANCELLED.code, "operation cancelled", error)
        else -> reject(ErrorCode.INTERNAL_ERROR.code, error.toString(), error)
    }

    private fun create(id: Double, promise: Promise, make: () -> AnonRpcWorker) {
        try {
            workers[id.toInt()] = make()
            promise.resolve(null)
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    private fun worker(id: Double): AnonRpcWorker =
        workers[id.toInt()] ?: throw AnonRpcException(ErrorCode.CLOSED, "no such worker")

    /** Run [body] as the call numbered [callId], which `cancel` cancels. */
    private fun call(callId: Int, promise: Promise, body: suspend () -> Any?) {
        val job = scope.launch {
            try {
                promise.resolve(body())
            } catch (error: Throwable) {
                promise.fail(error)
            } finally {
                calls.remove(callId)
            }
        }
        calls[callId] = job
    }

    private fun storage(dir: String?) = dir?.let(::File) ?: File(context.noBackupFilesDir, "anon-rpc/worker-storage")

    override fun createTor(workerId: Double, stateDir: String?, cacheDir: String?, promise: Promise) =
        create(workerId, promise) {
            val default = TorConfig.default(context)
            AnonRpcWorker.tor(
                TorConfig(stateDir?.let(::File) ?: default.stateDir, cacheDir?.let(::File) ?: default.cacheDir),
            )
        }

    override fun createFromAddress(
        workerId: Double,
        address: String,
        configJson: String?,
        storageDir: String?,
        allowPrivateNetworks: Boolean,
        promise: Promise,
    ) = create(workerId, promise) {
        AnonRpcWorker(
            address,
            JavaScriptProvider(workerId.toInt()),
            storage(storageDir),
            configJson?.let { AnonRpcValue.fromWire(it.toByteArray()) },
            allowPrivateNetworks,
        )
    }

    override fun createFromBundle(
        workerId: Double,
        bundleBase64: String,
        configJson: String?,
        storageDir: String?,
        allowPrivateNetworks: Boolean,
        promise: Promise,
    ) = create(workerId, promise) {
        AnonRpcWorker(
            Base64.decode(bundleBase64, Base64.DEFAULT),
            storage(storageDir),
            configJson?.let { AnonRpcValue.fromWire(it.toByteArray()) },
            allowPrivateNetworks,
        )
    }

    override fun ready(workerId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(-workerId.toInt(), promise) { worker.ready().let { null } }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun fetch(workerId: Double, callId: Double, headJson: String, bodyBase64: String?, promise: Promise) {
        try {
            val worker = worker(workerId)
            val head = RequestHead.fromWire(headJson.toByteArray())
            val request = AnonRpcRequest(
                url = head.url,
                method = head.method ?: "GET",
                headers = head.headers.orEmpty(),
                body = bodyBase64?.let { AnonRpcRequest.Body.Bytes(Base64.decode(it, Base64.DEFAULT)) },
            )
            call(callId.toInt(), promise) {
                worker.fetch(request, head.redirect ?: Redirect.FOLLOW).use { response ->
                    BufferedResponse(
                        status = response.status,
                        headers = response.headers,
                        url = response.url,
                        body = Base64.encodeToString(response.body.bytes(), Base64.NO_WRAP),
                    ).toWire().decodeToString()
                }
            }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun acceptLog(workerId: Double, callId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(callId.toInt(), promise) { worker.acceptLog().toWire().decodeToString() }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun cancel(callId: Double) {
        calls[callId.toInt()]?.cancel()
    }

    override fun close(workerId: Double) {
        workers[workerId.toInt()]?.close()
        providerRequests.entries.removeIf { (_, request) ->
            val (worker, response) = request
            if (worker == workerId.toInt()) response.complete(ProviderResponse.Error("worker closed").toWire().decodeToString())
            worker == workerId.toInt()
        }
    }

    override fun respondProvider(workerId: Double, requestId: Double, responseJson: String) {
        providerRequests.remove(requestId.toInt())?.second?.complete(responseJson)
    }

    /** Reads the specifier through the JavaScript provider of a worker, blocking a native thread. */
    private inner class JavaScriptProvider(private val workerId: Int) : RpcProvider {
        override fun request(method: String, params: String): String {
            val requestId = nextRequest.getAndIncrement()
            val response = CompletableFuture<String>()
            providerRequests[requestId] = workerId to response
            emitProviderRequest(
                Arguments.createMap().apply {
                    putInt("workerId", workerId)
                    putInt("requestId", requestId)
                    putString("method", method)
                    putString("params", params)
                },
            )
            val answer = try {
                ProviderResponse.fromWire(response.get().toByteArray())
            } catch (error: ExecutionException) {
                throw AnonRpcException(ErrorCode.NETWORK_ERROR, error.cause?.message ?: "no result")
            } catch (_: AnonRpcException) {
                throw AnonRpcException(ErrorCode.NETWORK_ERROR, "invalid provider response")
            }
            return when (answer) {
                is ProviderResponse.Result -> JSONArray().put(answer.value).toString().removePrefix("[").removeSuffix("]")
                is ProviderResponse.Error -> throw AnonRpcException(ErrorCode.NETWORK_ERROR, answer.value)
            }
        }
    }

    companion object {
        const val NAME = "AnonRpc"
    }
}
