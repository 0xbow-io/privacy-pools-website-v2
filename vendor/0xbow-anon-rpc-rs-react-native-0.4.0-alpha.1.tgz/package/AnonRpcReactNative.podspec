require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name = "AnonRpcReactNative"
  s.version = package["version"]
  s.summary = package["description"]
  s.homepage = "https://github.com/0xbow-io/anon-rpc-rs"
  s.license = package["license"]
  s.authors = "anon-rpc contributors"
  s.source = { :git => "https://github.com/0xbow-io/anon-rpc-rs.git" }
  s.platform = :ios, "15.1"
  s.swift_version = "5.9"
  s.source_files = "ios/**/*.{h,m,mm,swift}"
  # The Swift SDK this package bundles in native/ios; the app's Podfile
  # points at it.
  s.dependency "AnonRpc"

  install_modules_dependencies(s)
end
