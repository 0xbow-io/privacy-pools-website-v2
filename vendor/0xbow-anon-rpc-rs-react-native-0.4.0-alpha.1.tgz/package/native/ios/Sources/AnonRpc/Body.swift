import AnonRpcC
import Foundation

extension AnonRpcWorker {
    /// A response body that streams from the network as it arrives, as
    /// chunks of `Data`.
    ///
    /// Cancelling the reading task cancels the transfer, and so does
    /// releasing the body before its end.
    public final class Body: AsyncSequence, Sendable {
        public typealias Element = Data

        let handle: UInt64

        init(handle: UInt64) {
            self.handle = handle
        }

        deinit {
            anon_rpc_body_free(handle)
        }

        public func makeAsyncIterator() -> Iterator {
            Iterator(body: self)
        }

        public struct Iterator: AsyncIteratorProtocol {
            let body: Body

            /// The next chunk, or `nil` at the end of the body.
            public mutating func next() async throws -> Data? {
                let handle = body.handle
                let chunk = try await blocking(cancel: { anon_rpc_body_cancel(handle) }) {
                    var buffer = [UInt8](repeating: 0, count: 64 * 1024)
                    var count = 0
                    var error = AnonRpcBuffer()
                    let status = anon_rpc_body_read(handle, &buffer, buffer.count, &count, &error)
                    try check(status, error)
                    return Data(buffer[..<count])
                }
                return chunk.isEmpty ? nil : chunk
            }
        }
    }
}
