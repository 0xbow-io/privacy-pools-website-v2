import AnonRpcC
import Foundation

/// An anon-rpc worker's `fetch` for Swift applications, backed by the Rust
/// `anon-rpc` crate: Tor-anonymized from `tor(config:)`, or served by a
/// sandboxed worker bundle from `init(address:...)` or `init(bundle:...)`.
///
/// Each Tor worker is its own isolation group: its requests never share a
/// Tor circuit or an HTTP connection with another worker's. Releasing the
/// worker closes it.
public final class AnonRpcWorker: Sendable {
    let handle: UInt64
    /// The RPC provider of a worker started from its specifier, or 0.
    let provider: UInt64

    private init(handle: UInt64, provider: UInt64 = 0) {
        self.handle = handle
        self.provider = provider
    }

    deinit {
        anon_rpc_worker_free(handle)
        if provider != 0 {
            anon_rpc_provider_free(provider)
        }
    }

    /// Start a worker over a native Tor client and begin bootstrapping in the
    /// background. Returns at once.
    public static func tor(config: TorConfig = .default) -> AnonRpcWorker {
        precondition(
            anon_rpc_abi_version() == UInt32(ANON_RPC_ABI_VERSION),
            "AnonRpcC.xcframework does not match the AnonRpc sources; rebuild it"
        )
        var worker: UInt64 = 0
        var error = AnonRpcBuffer()
        let json = try! TorInit(
            stateDir: config.stateDirectory?.path ?? deviceDirectory("tor-state"),
            cacheDir: config.cacheDirectory?.path
        ).wire()
        let status = withBytes(of: json) { anon_rpc_worker_tor($0, $1, &worker, &error) }
        do {
            try check(status, error)
        } catch {
            preconditionFailure("anon_rpc_worker_tor: \(error)")
        }
        return AnonRpcWorker(handle: worker)
    }

    /// Start a worker from its specifier contract and return at once, as the
    /// JavaScript `new AnonRpcWorker({ address, preExisting: { rpcProvider } })`
    /// does.
    ///
    /// The worker reads the contract's `workerHash()` and `workerResolvers()`
    /// through `rpcProvider`, fetches the bundle from the first resolver that
    /// serves bytes with that hash, and runs it in a sandbox; `ready` fails if
    /// none does. `config` reaches the worker as `anonRpcWorker.config`.
    /// Storage defaults to `Library/Application Support/anon-rpc/worker-storage`,
    /// which on iOS is excluded from backup.
    /// The worker's own `fetch` refuses loopback and private networks unless
    /// `allowPrivateNetworks` is set. Throws `unsupported` for a malformed
    /// address or config.
    public convenience init(
        address: String,
        config: AnonRpcValue? = nil,
        rpcProvider: any RpcProvider,
        storageDirectory: URL? = nil,
        allowPrivateNetworks: Bool = false
    ) throws {
        let json = try SpecifierInit(
            address: address, config: config,
            storageDir: storageDirectory?.path ?? deviceDirectory("worker-storage"),
            allowPrivateNetworks: allowPrivateNetworks
        ).wire()
        var worker: UInt64 = 0
        var provider: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: json) {
            anon_rpc_worker_new($0, $1, &worker, &provider, &error)
        }
        try check(status, error)
        self.init(handle: worker, provider: provider)
        serve(rpcProvider, handle: provider)
    }

    /// Start a worker from `bundle`, whose keccak256 hash is its identity,
    /// and return at once. The options are those of
    /// `init(address:config:rpcProvider:storageDirectory:allowPrivateNetworks:)`.
    public convenience init(
        bundle: Data,
        config: AnonRpcValue? = nil,
        storageDirectory: URL? = nil,
        allowPrivateNetworks: Bool = false
    ) throws {
        let json = try WorkerSettings(
            config: config, storageDir: storageDirectory?.path ?? deviceDirectory("worker-storage"),
            allowPrivateNetworks: allowPrivateNetworks
        ).wire()
        var worker: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: bundle) { bundle, bundleLength in
            withBytes(of: json) { settings, settingsLength in
                anon_rpc_worker_from_bundle(
                    bundle, bundleLength, settings, settingsLength, &worker, &error)
            }
        }
        try check(status, error)
        self.init(handle: worker, provider: 0)
    }

    /// Wait until the worker is ready for traffic. After a failure every caller
    /// receives the same error.
    public func ready() async throws {
        _ = try await run { try check(anon_rpc_worker_ready(handle, $0)) }
    }

    /// Send `request` over Tor and return the whole response body.
    public func data(
        for request: AnonRpcRequest,
        redirect: Redirect = .follow
    ) async throws -> (Data, HTTPResponse) {
        let (body, response) = try await bytes(for: request, redirect: redirect)
        var data = Data()
        for try await chunk in body {
            data.append(chunk)
        }
        return (data, response)
    }

    /// Send the method, URL, headers and body of `request` over Tor and return
    /// the whole response body. See `AnonRpcRequest.init(_:)` for how its
    /// header fields are sent.
    public func data(
        for request: URLRequest,
        redirect: Redirect = .follow
    ) async throws -> (Data, HTTPResponse) {
        try await data(for: AnonRpcRequest(request), redirect: redirect)
    }

    /// Send the method, URL, headers and body of `request` over Tor and
    /// return once the response headers arrive, with a body that streams the
    /// rest. See `AnonRpcRequest.init(_:)` for how its header fields are sent.
    public func bytes(
        for request: URLRequest,
        redirect: Redirect = .follow
    ) async throws -> (Body, HTTPResponse) {
        try await bytes(for: AnonRpcRequest(request), redirect: redirect)
    }

    /// Send `request` over Tor and return once the response headers arrive,
    /// with a body that streams the rest.
    ///
    /// A streamed body is read once, as it is sent. Cancelling the task
    /// cancels the transfer, and so does releasing an unread body.
    public func bytes(
        for request: AnonRpcRequest,
        redirect: Redirect = .follow
    ) async throws -> (Body, HTTPResponse) {
        let head = try RequestHead(
            method: request.method, url: request.url.absoluteString, headers: request.headers,
            redirect: redirect
        ).wire()
        nonisolated(unsafe) var stream: InputStream?
        var bytes = Data()
        let kind: Int32
        switch request.body {
        case nil:
            kind = ANON_RPC_BODY_NONE
        case .bytes(let data):
            kind = data.isEmpty ? ANON_RPC_BODY_NONE : ANON_RPC_BODY_BYTES
            bytes = data
        case .stream(let input):
            kind = ANON_RPC_BODY_STREAM
            stream = input
        }

        var writer: UInt64 = 0
        let json = try await run { operation in
            var error = AnonRpcBuffer()
            let status = withBytes(of: head) { head, headLength in
                withBytes(of: bytes) { body, bodyLength in
                    anon_rpc_worker_fetch(
                        handle, head, headLength, UInt32(kind), body, bodyLength,
                        operation, &writer, &error)
                }
            }
            try check(status, error)
            if let stream {
                upload(stream, to: writer)
            }
        }

        let decoded = try ResponseHead(wire: json)
        let body = Body(handle: decoded.body)
        guard
            let response = HTTPResponse(
                url: decoded.url.flatMap(URL.init(string:)) ?? request.url,
                statusCode: Int(decoded.status),
                headerFieldList: decoded.headers
            )
        else {
            throw AnonRpcError(code: .protocolError, message: "invalid response head")
        }
        return (body, response)
    }

    /// The next log entry, waiting for one if none is retained. Cancelling the
    /// task consumes no entry. After the worker fails or closes, retained
    /// entries are still delivered; then this throws.
    public func acceptLog() async throws -> LogEntry {
        let json = try await run { try check(anon_rpc_worker_accept_log(handle, $0)) }
        return try LogEntry(wire: json)
    }

    /// Close the worker: no new fetches are admitted, and in-flight fetches
    /// and unread response bodies fail with `closed`. Closing twice has no
    /// further effect.
    public func close() {
        anon_rpc_worker_close(handle)
    }
}

/// Copy `stream` into the request body `writer` on a thread of its own,
/// then free the writer. A stream error abandons the body, which fails the
/// fetch.
private func upload(_ stream: InputStream, to writer: UInt64) {
    nonisolated(unsafe) let stream = stream
    Thread {
        stream.open()
        defer {
            stream.close()
            anon_rpc_request_body_free(writer)
        }
        var buffer = [UInt8](repeating: 0, count: 64 * 1024)
        while true {
            let count = stream.read(&buffer, maxLength: buffer.count)
            if count < 0 {
                return
            }
            if count == 0 {
                anon_rpc_request_body_finish(writer)
                return
            }
            var error = AnonRpcBuffer()
            let status = anon_rpc_request_body_write(writer, buffer, count, &error)
            anon_rpc_buffer_free(error)
            if status != ANON_RPC_STATUS_OK {
                return
            }
        }
    }.start()
}

extension AnonRpcWorker {
    /// The response head of a fetch. Its `allHeaderFields` combines repeated
    /// fields into one value separated by commas, as Foundation does;
    /// `headerFieldList` keeps each field as the server sent it, in order.
    public final class HTTPResponse: HTTPURLResponse, @unchecked Sendable {
        /// The header fields in the order the server sent them, with repeated
        /// fields kept apart.
        public let headerFieldList: [(name: String, value: String)]

        init?(url: URL, statusCode: Int, headerFieldList: [(name: String, value: String)]) {
            self.headerFieldList = headerFieldList
            var fields: [String: String] = [:]
            for (name, value) in headerFieldList {
                fields[name] = fields[name].map { "\($0), \(value)" } ?? value
            }
            super.init(url: url, statusCode: statusCode, httpVersion: "HTTP/1.1", headerFields: fields)
        }

        /// A coded response carries no field list, so it does not decode.
        required init?(coder: NSCoder) {
            nil
        }
    }
}

#if os(iOS)
/// `name` in `Library/Application Support/anon-rpc`, which this excludes from
/// iCloud and device backups: Tor guards and worker storage belong to this
/// device, as the Kotlin SDK's no-backup directory keeps them on Android.
/// `nil`, so the library's default applies, if the directory cannot be made.
func deviceDirectory(_ name: String) -> String? {
    let manager = FileManager.default
    guard
        var root = try? manager.url(
            for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true
        ).appendingPathComponent("anon-rpc", isDirectory: true),
        (try? manager.createDirectory(at: root, withIntermediateDirectories: true)) != nil
    else { return nil }
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try? root.setResourceValues(values)
    return root.appendingPathComponent(name, isDirectory: true).path
}
#else
/// `nil`: the library's default directory applies.
func deviceDirectory(_ name: String) -> String? { nil }
#endif
