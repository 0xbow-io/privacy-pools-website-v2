import Foundation

/// An anon-rpc failure: a machine-readable code and a human-readable
/// message. A message the library writes never contains request or response
/// content; an embedded worker's message is the worker's own.
public struct AnonRpcError: Error, Sendable, Equatable, CustomStringConvertible {
    /// The reason for the failure. Branch on it; the message is diagnostic.
    public let code: ErrorCode
    public let message: String
    /// The code an embedded worker failed with, intact, when it gave one.
    public let workerCode: String?

    public init(code: ErrorCode, message: String, workerCode: String? = nil) {
        self.code = code
        self.message = message
        self.workerCode = workerCode
    }

    public var description: String { "\(code.rawValue): \(message)" }
}

/// Where the Tor client keeps its state and cache.
///
/// Workers with equal directories share one Tor client: one directory
/// download, one set of guards.
public struct TorConfig: Sendable, Equatable {
    /// Persistent state, such as the chosen guards. `nil` means
    /// `Library/Application Support/anon-rpc/tor-state` in the home directory,
    /// which on iOS is excluded from backup.
    public var stateDirectory: URL?
    /// Directory material that can be downloaded again. `nil` means
    /// `Library/Caches/anon-rpc/tor-cache` in the home directory.
    public var cacheDirectory: URL?

    public init(stateDirectory: URL? = nil, cacheDirectory: URL? = nil) {
        self.stateDirectory = stateDirectory
        self.cacheDirectory = cacheDirectory
    }

    /// The default directories.
    public static let `default` = TorConfig()
}

/// A request for `AnonRpcWorker.data(for:redirect:)` and
/// `bytes(for:redirect:)`. Its header fields keep their order, and repeated
/// fields stay apart.
public struct AnonRpcRequest: Sendable {
    public var url: URL
    public var method: String
    /// The header fields in order, with repeats kept apart.
    public var headers: [(name: String, value: String)]
    public var body: Body?

    /// A request body.
    public enum Body: @unchecked Sendable {
        /// Bytes, which a redirect can resend.
        case bytes(Data)
        /// A stream read once, as it is sent, which a redirect other than
        /// 303 cannot resend.
        case stream(InputStream)
    }

    public init(
        url: URL,
        method: String = "GET",
        headers: [(name: String, value: String)] = [],
        body: Body? = nil
    ) {
        self.url = url
        self.method = method
        self.headers = headers
        self.body = body
    }

    /// The method, URL, headers and body of `request`. `URLRequest` holds its
    /// header fields in a dictionary, so they are sent in the order of their
    /// names, and a field set twice is sent once.
    public init(_ request: URLRequest) throws {
        guard let url = request.url else {
            throw AnonRpcError(code: .unsupported, message: "the request has no URL")
        }
        let headers = (request.allHTTPHeaderFields ?? [:])
            .sorted { $0.key.lowercased() < $1.key.lowercased() }
            .map { (name: $0.key, value: $0.value) }
        let body: Body? =
            if let stream = request.httpBodyStream {
                .stream(stream)
            } else if let data = request.httpBody, !data.isEmpty {
                .bytes(data)
            } else {
                nil
            }
        self.init(url: url, method: request.httpMethod ?? "GET", headers: headers, body: body)
    }
}
