// Expo config plugin: adds the AnonRpc pod this package bundles in native/ios
// to the app's Podfile. On Android the module's Gradle build finds the
// bundled Kotlin SDK itself.
const fs = require("fs");
const path = require("path");
// The app's own copy of Expo, which this package does not install.
const { withDangerousMod } = require(
  require.resolve("expo/config-plugins", { paths: [process.cwd()] }),
);

const pod = path.join(__dirname, "native", "ios");

function withSwiftSdk(config) {
  return withDangerousMod(config, [
    "ios",
    (config) => {
      const podfile = path.join(config.modRequest.platformProjectRoot, "Podfile");
      const contents = fs.readFileSync(podfile, "utf8");
      const relative = path.relative(config.modRequest.platformProjectRoot, pod);
      const line = `  pod 'AnonRpc', :path => '${relative}'`;
      if (!contents.includes(line)) {
        fs.writeFileSync(podfile, contents.replace(/^(target '[^']+' do\n)/m, `$1${line}\n`));
      }
      return config;
    },
  ]);
}

module.exports = withSwiftSdk;
