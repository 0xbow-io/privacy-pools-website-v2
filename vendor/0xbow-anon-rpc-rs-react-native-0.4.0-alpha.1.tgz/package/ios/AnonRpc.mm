// The AnonRpc native module: forwards each call to AnonRpcBridge, which uses
// the public AnonRpc Swift SDK. On the New Architecture it is a TurboModule
// over the codegen spec; on the legacy architecture, an event emitter whose
// methods the bridge finds through RCT_EXPORT_METHOD.

#import <React/RCTBridgeModule.h>
#ifdef RCT_NEW_ARCH_ENABLED
#import <AnonRpcSpec/AnonRpcSpec.h>
#else
#import <React/RCTEventEmitter.h>
#endif

#if __has_include(<AnonRpcReactNative/AnonRpcReactNative-Swift.h>)
#import <AnonRpcReactNative/AnonRpcReactNative-Swift.h>
#else
#import "AnonRpcReactNative-Swift.h"
#endif

#ifdef RCT_NEW_ARCH_ENABLED
@interface AnonRpc : NativeAnonRpcSpecBase <NativeAnonRpcSpec>
#else
@interface AnonRpc : RCTEventEmitter <RCTBridgeModule>
#endif
@end

@implementation AnonRpc {
  AnonRpcBridge *_bridge;
}

RCT_EXPORT_MODULE(AnonRpc)

- (instancetype)init
{
  if (self = [super init]) {
    _bridge = [AnonRpcBridge new];
    __weak AnonRpc *weakSelf = self;
    _bridge.emitProviderRequest = ^(NSDictionary *request) {
#ifdef RCT_NEW_ARCH_ENABLED
      [weakSelf emitOnProviderRequest:request];
#else
      [weakSelf sendEventWithName:@"onProviderRequest" body:request];
#endif
    };
  }
  return self;
}

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

#ifndef RCT_NEW_ARCH_ENABLED
- (NSArray<NSString *> *)supportedEvents
{
  return @[ @"onProviderRequest" ];
}
#endif

static void (^Resolver(RCTPromiseResolveBlock resolve))(id)
{
  return ^(id result) { resolve(result); };
}

static void (^Rejecter(RCTPromiseRejectBlock reject))(NSString *, NSString *)
{
  return ^(NSString *code, NSString *message) { reject(code, message, nil); };
}

RCT_EXPORT_METHOD(createTor:(double)workerId
         stateDir:(NSString *)stateDir
         cacheDir:(NSString *)cacheDir
          resolve:(RCTPromiseResolveBlock)resolve
           reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge createTor:(NSInteger)workerId
            stateDir:stateDir
            cacheDir:cacheDir
             resolve:Resolver(resolve)
              reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(createFromAddress:(double)workerId
                  address:(NSString *)address
               configJson:(NSString *)configJson
               storageDir:(NSString *)storageDir
     allowPrivateNetworks:(BOOL)allowPrivateNetworks
                  resolve:(RCTPromiseResolveBlock)resolve
                   reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge createFromAddress:(NSInteger)workerId
                     address:address
                  configJson:configJson
                  storageDir:storageDir
        allowPrivateNetworks:allowPrivateNetworks
                     resolve:Resolver(resolve)
                      reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(createFromBundle:(double)workerId
            bundleBase64:(NSString *)bundleBase64
              configJson:(NSString *)configJson
              storageDir:(NSString *)storageDir
    allowPrivateNetworks:(BOOL)allowPrivateNetworks
                 resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge createFromBundle:(NSInteger)workerId
               bundleBase64:bundleBase64
                 configJson:configJson
                 storageDir:storageDir
       allowPrivateNetworks:allowPrivateNetworks
                    resolve:Resolver(resolve)
                     reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(ready:(double)workerId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge ready:(NSInteger)workerId resolve:Resolver(resolve) reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(fetch:(double)workerId
        callId:(double)callId
      headJson:(NSString *)headJson
    bodyBase64:(NSString *)bodyBase64
       resolve:(RCTPromiseResolveBlock)resolve
        reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge fetch:(NSInteger)workerId
          callId:(NSInteger)callId
        headJson:headJson
      bodyBase64:bodyBase64
         resolve:Resolver(resolve)
          reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(acceptLog:(double)workerId
           callId:(double)callId
          resolve:(RCTPromiseResolveBlock)resolve
           reject:(RCTPromiseRejectBlock)reject)
{
  [_bridge acceptLog:(NSInteger)workerId callId:(NSInteger)callId resolve:Resolver(resolve) reject:Rejecter(reject)];
}

RCT_EXPORT_METHOD(cancel:(double)callId)
{
  [_bridge cancel:(NSInteger)callId];
}

RCT_EXPORT_METHOD(close:(double)workerId)
{
  [_bridge close:(NSInteger)workerId];
}

RCT_EXPORT_METHOD(respondProvider:(double)workerId requestId:(double)requestId responseJson:(NSString *)responseJson)
{
  [_bridge respondProvider:(NSInteger)workerId requestId:(NSInteger)requestId responseJson:responseJson];
}

#ifdef RCT_NEW_ARCH_ENABLED
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeAnonRpcSpecJSI>(params);
}
#endif

@end
