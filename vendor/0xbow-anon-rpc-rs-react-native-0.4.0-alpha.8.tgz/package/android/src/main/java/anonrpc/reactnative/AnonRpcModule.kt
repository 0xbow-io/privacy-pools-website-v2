package anonrpc.reactnative

import android.util.Base64
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import anonrpc.AnonRpcException
import anonrpc.AnonRpcWireApi
import anonrpc.AnonRpcWorker
import anonrpc.Failure
import anonrpc.PoolGroup
import anonrpc.PoolInit
import anonrpc.ProviderResponse
import anonrpc.ReplacingInit
import anonrpc.SpecifierInit
import anonrpc.TorInit
import anonrpc.WorkerPool
import anonrpc.WorkerSettings
import anonrpc.WireRpcProvider
import anonrpc.WorkerStart
import anonrpc.withAppRoots
import anonrpc.fromWire
import anonrpc.generated.ErrorCode
import anonrpc.toWire
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * The React Native module's calls, over the anon-rpc Kotlin SDK and its wire
 * codec. Workers and calls are numbered by JavaScript; bytes cross as base64.
 */
@OptIn(AnonRpcWireApi::class)
class AnonRpcModule(private val context: ReactApplicationContext) : NativeAnonRpcSpec(context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val workers = ConcurrentHashMap<Int, AnonRpcWorker>()
    /** Workers JavaScript has closed, kept until their retained log entries have been read. */
    private val closedWorkers = ConcurrentHashMap.newKeySet<Int>()
    private val pools = ConcurrentHashMap<Int, WorkerPool>()
    private val calls = ConcurrentHashMap<Int, Job>()
    /** Provider requests awaiting JavaScript, with the worker each belongs to. */
    private val providerRequests = ConcurrentHashMap<Int, Pair<Int, CompletableFuture<String>>>()
    private val nextRequest = AtomicInteger(1)

    /** Whether JavaScript has gone, after which no provider request waits for it. */
    @Volatile private var invalidated = false

    override fun getName() = NAME

    /** Close every worker and pool, as when JavaScript reloads. */
    override fun invalidate() {
        invalidated = true
        scope.cancel()
        workers.values.forEach { it.close() }
        workers.clear()
        closedWorkers.clear()
        pools.values.forEach { it.close() }
        pools.clear()
        answerProviderRequests()
        super.invalidate()
    }

    /**
     * Send a provider request to JavaScript: through the codegen event
     * emitter, which only the New Architecture wires up, or else as a device
     * event, as the legacy architecture delivers module events.
     */
    private fun emitProviderRequest(request: WritableMap) {
        if (mEventEmitterCallback != null) {
            emitOnProviderRequest(request)
        } else {
            context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit("onProviderRequest", request)
        }
    }

    private fun Promise.fail(error: Throwable) = when (error) {
        is AnonRpcException -> reject(error.workerCode ?: error.code.code, error.message, error)
        is CancellationException -> reject(ErrorCode.CANCELLED.code, "operation cancelled", error)
        else -> reject(ErrorCode.INTERNAL_ERROR.code, error.toString(), error)
    }

    /** [error] as `Failure` JSON, which a synchronous call returns. */
    private fun failure(error: Throwable): String {
        val failure = when (error) {
            is AnonRpcException -> Failure(error.code.code, error.message.orEmpty(), error.workerCode)
            else -> Failure(ErrorCode.INTERNAL_ERROR.code, error.toString())
        }
        return String(failure.toWire())
    }

    /** Register the worker [make] returns as [id]: `null`, or its failure. */
    private fun create(id: Double, make: () -> AnonRpcWorker): String? =
        try {
            workers[id.toInt()] = make()
            null
        } catch (error: Throwable) {
            failure(error)
        }

    private fun worker(id: Double): AnonRpcWorker =
        workers[id.toInt()] ?: throw AnonRpcException(ErrorCode.CLOSED, "no such worker")

    /** Run [body] as the call numbered [callId], which `cancel` cancels. */
    private fun call(callId: Int, promise: Promise, body: suspend () -> Any?) {
        val job = scope.launch {
            try {
                promise.resolve(body())
            } catch (error: Throwable) {
                promise.fail(error)
            } finally {
                calls.remove(callId)
            }
        }
        calls[callId] = job
    }


    /** Bundle bytes from base64, refused as the iOS module refuses them. */
    private fun bundle(base64: String?) = base64?.let {
        try {
            Base64.decode(it, Base64.DEFAULT)
        } catch (_: IllegalArgumentException) {
            throw AnonRpcException(ErrorCode.UNSUPPORTED, "the bundle is not base64")
        }
    }

    override fun createTor(workerId: Double, initJson: String): String? =
        create(workerId) {
            val init = TorInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.tor(WorkerStart(tor = init).withAppRoots(context).tor!!)
        }

    override fun createFromAddress(workerId: Double, initJson: String): String? =
        create(workerId) {
            val init = SpecifierInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.specifier(WorkerStart(specifier = init).withAppRoots(context).specifier!!, JavaScriptProvider(workerId.toInt()))
        }

    override fun createFromBundle(workerId: Double, bundleBase64: String, settingsJson: String): String? =
        create(workerId) {
            val init = WorkerSettings.fromWire(settingsJson.toByteArray())
            AnonRpcWorker.bundle(WorkerStart(bundle = init).withAppRoots(context).bundle!!, bundle(bundleBase64)!!)
        }

    override fun createReplacing(workerId: Double, initJson: String, bundleBase64: String?): String? =
        create(workerId) {
            val init = ReplacingInit.fromWire(initJson.toByteArray())
            AnonRpcWorker.replacing(init.copy(start = init.start.withAppRoots(context)), bundle(bundleBase64), JavaScriptProvider(workerId.toInt()))
        }

    override fun createPool(poolId: Double, initJson: String, bundleBase64: String?): String? =
        try {
            val init = PoolInit.fromWire(initJson.toByteArray())
            pools[poolId.toInt()] =
                WorkerPool.fromWire(init.copy(start = init.start.withAppRoots(context)), bundle(bundleBase64), JavaScriptProvider(poolId.toInt()))
            null
        } catch (error: Throwable) {
            failure(error)
        }

    override fun poolGroup(poolId: Double, workerId: Double, groupJson: String): String? =
        create(workerId) {
            val pool = pools[poolId.toInt()] ?: throw AnonRpcException(ErrorCode.CLOSED, "no such pool")
            pool.group(PoolGroup.fromWire(groupJson.toByteArray()))
        }

    override fun closePool(poolId: Double): String? {
        pools.remove(poolId.toInt())?.close()
        answerProviderRequests(poolId.toInt())
        return null
    }

    override fun ready(workerId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(-workerId.toInt(), promise) { worker.ready().let { null } }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    /** The library decodes and validates [requestJson], a `BufferedRequest`, and resolves with a `BufferedResponse`. */
    override fun fetch(workerId: Double, callId: Double, requestJson: String, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(callId.toInt(), promise) { worker.fetchBuffered(requestJson) }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun acceptLog(workerId: Double, callId: Double, promise: Promise) {
        try {
            val worker = worker(workerId)
            call(callId.toInt(), promise) {
                try {
                    worker.acceptLog().toWire().decodeToString()
                } catch (error: AnonRpcException) {
                    // A closed worker's log is drained: forget the worker.
                    val id = workerId.toInt()
                    if (error.code == ErrorCode.CLOSED && closedWorkers.remove(id)) workers.remove(id)
                    throw error
                }
            }
        } catch (error: Throwable) {
            promise.fail(error)
        }
    }

    override fun cancel(callId: Double) {
        calls[callId.toInt()]?.cancel()
    }

    override fun close(workerId: Double): String? {
        val id = workerId.toInt()
        workers[id]?.let {
            closedWorkers.add(id)
            it.close()
        }
        answerProviderRequests(id)
        return null
    }

    /**
     * End the provider requests of the worker or pool [id], or of every one,
     * whose relay would otherwise wait for JavaScript forever; the library
     * has stopped waiting.
     */
    private fun answerProviderRequests(id: Int? = null) {
        providerRequests.entries.removeIf { (_, request) ->
            val (owner, response) = request
            (id == null || owner == id).also { if (it) response.complete(CLOSED_RESPONSE) }
        }
    }

    override fun respondProvider(workerId: Double, requestId: Double, responseJson: String) {
        providerRequests.remove(requestId.toInt())?.second?.complete(responseJson)
    }

    /**
     * Reads the specifier through the JavaScript provider of a worker, relaying
     * JavaScript's answer as it is, and blocking a native thread.
     */
    private inner class JavaScriptProvider(private val workerId: Int) : WireRpcProvider {
        override fun respond(method: String, params: String): String {
            val requestId = nextRequest.getAndIncrement()
            val response = CompletableFuture<String>()
            providerRequests[requestId] = workerId to response
            if (invalidated) providerRequests.remove(requestId)?.second?.complete(CLOSED_RESPONSE)
            emitProviderRequest(
                Arguments.createMap().apply {
                    putInt("workerId", workerId)
                    putInt("requestId", requestId)
                    putString("method", method)
                    putString("params", params)
                },
            )
            return response.get()
        }
    }

    companion object {
        const val NAME = "AnonRpc"

        /** The answer to a provider request whose worker has closed. */
        private val CLOSED_RESPONSE = ProviderResponse.Error("worker closed").toWire().decodeToString()
    }
}
