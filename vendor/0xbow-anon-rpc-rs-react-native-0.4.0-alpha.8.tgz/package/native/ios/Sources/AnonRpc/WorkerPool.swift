import AnonRpcC
import Foundation

extension AnonRpcWorker {
    /// How a replacing worker or a pool starts each worker: the options of
    /// one of `AnonRpcWorker`'s constructors.
    public enum Start: Sendable {
        /// As `tor(config:)`.
        case tor(TorConfig = .default)
        /// As `init(address:config:rpcProvider:specifierChainId:expectedWorkerHash:storageDirectory:allowPrivateNetworks:)`.
        /// Every worker reads its specifier through `rpcProvider`.
        case specifier(
            address: String, config: AnonRpcValue? = nil, rpcProvider: any RpcProvider,
            specifierChainId: UInt64? = nil, expectedWorkerHash: String? = nil,
            storageDirectory: URL? = nil, allowPrivateNetworks: Bool = false)
        /// As `init(bundle:config:storageDirectory:allowPrivateNetworks:)`.
        case bundle(
            Data, config: AnonRpcValue? = nil, storageDirectory: URL? = nil,
            allowPrivateNetworks: Bool = false)

        /// The start document, the bundle bytes, and the provider a
        /// specifier start reads through.
        func wire() -> (WorkerStart, Data, (any RpcProvider)?) {
            switch self {
            case .tor(let config):
                let tor = TorInit(stateDir: config.stateDirectory?.path, cacheDir: config.cacheDirectory?.path)
                return (WorkerStart(tor: tor).withDeviceDefaults(), Data(), nil)
            case .specifier(
                let address, let config, let rpcProvider, let specifierChainId,
                let expectedWorkerHash, let storageDirectory, let allowPrivateNetworks):
                let specifier = SpecifierInit(
                    address: address, config: config, specifierChainId: specifierChainId,
                    expectedWorkerHash: expectedWorkerHash, storageDir: storageDirectory?.path,
                    allowPrivateNetworks: allowPrivateNetworks)
                return (WorkerStart(specifier: specifier).withDeviceDefaults(), Data(), rpcProvider)
            case .bundle(let bundle, let config, let storageDirectory, let allowPrivateNetworks):
                let settings = WorkerSettings(
                    config: config, storageDir: storageDirectory?.path,
                    allowPrivateNetworks: allowPrivateNetworks)
                return (WorkerStart(bundle: settings).withDeviceDefaults(), bundle, nil)
            }
        }
    }

    /// A worker that starts a worker as `start` says at its first call, and
    /// starts a new one when that worker's route stops carrying calls, as
    /// the anon-rpc specification's `ReplacingWorker` does (§5.1). Returns at
    /// once.
    ///
    /// A worker is replaced when a call has failed or timed out with none
    /// answering since (the second such call, for a worker that has answered
    /// before), and either no call to another host is still waiting or the
    /// call timed out with no call to any host answering meanwhile.
    /// Replacing closes the old worker, which fails the calls still on it
    /// with `closed`. A call still waiting `callTimeout` seconds after the
    /// worker is ready fails with `timeout`; a worker not ready within
    /// `readyTimeout` seconds is closed, and the next call starts another.
    /// `acceptLog()` throws `unsupported`. Throws `unsupported` for a
    /// malformed start or a negative deadline.
    public static func replacing(
        _ start: Start, callTimeout: TimeInterval? = nil, readyTimeout: TimeInterval? = nil
    ) throws -> AnonRpcWorker {
        let (wire, bundle, rpcProvider) = start.wire()
        let document = ReplacingInit(
            start: wire, callTimeoutMs: milliseconds(callTimeout), readyTimeoutMs: milliseconds(readyTimeout))
        return try replacing(wire: document, bundle: bundle, rpcProvider: rpcProvider)
    }

    /// `replacing(_:callTimeout:readyTimeout:)` from its wire document, the
    /// bytes of a bundle start, and the provider a specifier start reads
    /// through. Directories the start leaves out are this device's.
    @_spi(AnonRpcWire) public static func replacing(
        wire document: ReplacingInit, bundle: Data = Data(), rpcProvider: (any RpcProvider)? = nil
    ) throws -> AnonRpcWorker {
        var document = document
        document.start = document.start.withDeviceDefaults()
        let (worker, provider) = try create(bundle, try document.wire(), anon_rpc_worker_replacing)
        if let rpcProvider, provider != 0 {
            serve(rpcProvider, handle: provider)
        }
        return AnonRpcWorker(handle: worker, provider: provider)
    }
}

/// Workers for isolation groups under one budget, as the anon-rpc
/// specification's `WorkerPool` (§5.2).
///
/// Each group is a replacing worker of its own
/// (`AnonRpcWorker.replacing(_:callTimeout:readyTimeout:)`), so calls in two
/// groups never share a worker, and the pool counts every worker alive,
/// spares included, against `maxWorkers`. A group whose worker would pass the
/// budget waits, first come first served, until a group closes, idles out or
/// retires a worker; the wait counts towards `readyTimeout`. While it waits,
/// the least recently used group gives up its worker once that worker's calls
/// and response bodies are done, or at the call deadline. Which traffic
/// shares a group is yours to decide. The pool closes once it and every
/// worker from its groups are released.
public final class WorkerPool: Sendable {
    let handle: UInt64
    /// The RPC provider of a specifier start, or 0.
    let provider: UInt64

    /// A pool whose groups start each worker as `start` says, keeping up to
    /// `spare` workers started for groups that have none and closing a
    /// group's worker after `idleClose` seconds with no call pending. Throws
    /// `unsupported` when `maxWorkers` is below 1, `spare` is negative or
    /// exceeds it, or a deadline is negative.
    public convenience init(
        start: AnonRpcWorker.Start, maxWorkers: Int, spare: Int = 0,
        idleClose: TimeInterval? = nil, callTimeout: TimeInterval? = nil,
        readyTimeout: TimeInterval? = nil
    ) throws {
        let (wire, bundle, rpcProvider) = start.wire()
        let document = PoolInit(
            start: wire, maxWorkers: Double(maxWorkers), spare: Double(spare),
            idleCloseMs: milliseconds(idleClose), callTimeoutMs: milliseconds(callTimeout),
            readyTimeoutMs: milliseconds(readyTimeout))
        try self.init(wire: document, bundle: bundle, rpcProvider: rpcProvider)
    }

    /// The pool from its wire document, the bytes of a bundle start, and the
    /// provider a specifier start reads through. Directories the start
    /// leaves out are this device's.
    @_spi(AnonRpcWire) public init(
        wire document: PoolInit, bundle: Data = Data(), rpcProvider: (any RpcProvider)? = nil
    ) throws {
        var document = document
        document.start = document.start.withDeviceDefaults()
        (handle, provider) = try create(bundle, try document.wire(), anon_rpc_pool_new)
        if let rpcProvider, provider != 0 {
            serve(rpcProvider, handle: provider)
        }
    }

    deinit {
        anon_rpc_pool_free(handle)
        if provider != 0 {
            anon_rpc_provider_free(provider)
        }
    }

    /// The group named `key`, made on first use. Every worker returned for
    /// one key serves one group until it is closed; releasing them leaves
    /// it open, and `close()` on any of them closes it and frees its place.
    /// `idleClose` replaces the pool's for a group this call makes. Throws
    /// `closed` once the pool is closed.
    public func group(_ key: String, idleClose: TimeInterval? = nil) throws -> AnonRpcWorker {
        try group(wire: PoolGroup(key: key, idleCloseMs: milliseconds(idleClose)))
    }

    /// `group(_:idleClose:)` from its wire document.
    @_spi(AnonRpcWire) public func group(wire group: PoolGroup) throws -> AnonRpcWorker {
        let json = try group.wire()
        var worker: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: json) { anon_rpc_pool_group(handle, $0, $1, &worker, &error) }
        try check(status, error)
        return AnonRpcWorker(handle: worker, pool: self)
    }

    /// Close every group and spare; calls waiting for a place and later
    /// calls fail with `closed`. Closing twice has no further effect.
    public func close() {
        anon_rpc_pool_close(handle)
    }
}

extension WorkerStart {
    /// This start under this device's data root, where the library places
    /// each directory the start names none for.
    func withDeviceDefaults() -> WorkerStart {
        var start = self
        let root = deviceDataRoot()
        if let dataRoot = start.tor?.dataRoot ?? root { start.tor?.dataRoot = dataRoot }
        if let dataRoot = start.specifier?.dataRoot ?? root { start.specifier?.dataRoot = dataRoot }
        if let dataRoot = start.bundle?.dataRoot ?? root { start.bundle?.dataRoot = dataRoot }
        return start
    }
}

/// Create a replacing worker or a pool from `bundle` and `json` with
/// `export`, returning its handle and its provider handle or 0.
private func create(
    _ bundle: Data, _ json: Data,
    _ export: (
        UnsafePointer<UInt8>?, Int, UnsafePointer<UInt8>?, Int, UnsafeMutablePointer<UInt64>?,
        UnsafeMutablePointer<UInt64>?, UnsafeMutablePointer<AnonRpcBuffer>?
    ) -> AnonRpcStatus
) throws -> (UInt64, UInt64) {
    requireMatchingLibrary()
    var handle: UInt64 = 0
    var provider: UInt64 = 0
    var error = AnonRpcBuffer()
    let status = withBytes(of: bundle) { bundle, bundleLength in
        withBytes(of: json) { json, jsonLength in
            export(bundle, bundleLength, json, jsonLength, &handle, &provider, &error)
        }
    }
    try check(status, error)
    return (handle, provider)
}

/// `seconds` in the wire's milliseconds; the library checks the deadline.
private func milliseconds(_ seconds: TimeInterval?) -> Double? {
    seconds.map { $0 * 1000 }
}
