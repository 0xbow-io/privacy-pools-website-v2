import AnonRpcC
import Foundation

/// Reads a worker's specifier contract: an EIP-1193-shaped JSON-RPC
/// provider, whose requests are not anonymized.
public protocol RpcProvider: Sendable {
    /// Send one request. `params` is the JSON array of its parameters; the
    /// result is the JSON of its `result`. A thrown error fails the read
    /// with `network-error`.
    func request(method: String, params: Data) async throws -> Data
}

/// A provider that answers in the wire's own JSON, for a host that relays
/// requests to another runtime, such as the React Native module: the answer
/// is `ProviderResponse` JSON, which the library validates. `request` is
/// never called on it.
@_spi(AnonRpcWire) public protocol WireRpcProvider: RpcProvider {
    func respond(method: String, params: Data) async -> Data
}

extension WireRpcProvider {
    public func request(method: String, params: Data) async throws -> Data {
        throw AnonRpcError(code: .unsupported, message: "a wire provider answers through respond")
    }
}

extension RpcProvider where Self == URLRpcProvider {
    /// A provider that posts JSON-RPC requests to `url`.
    public static func url(_ url: URL) -> URLRpcProvider {
        URLRpcProvider(url: url)
    }
}

/// An `RpcProvider` that posts JSON-RPC requests to a URL over the plain
/// network, through the library's own HTTP client. A JSON-RPC error, an HTTP
/// error status or an unreachable endpoint fails a request with
/// `network-error`.
public final class URLRpcProvider: RpcProvider {
    public let url: URL
    let handle: UInt64

    init(url: URL) {
        requireMatchingLibrary()
        self.url = url
        var handle: UInt64 = 0
        var error = AnonRpcBuffer()
        let json = try! HttpProviderInit(url: url.absoluteString).wire()
        let status = withBytes(of: json) { anon_rpc_http_provider_new($0, $1, &handle, &error) }
        do {
            try check(status, error)
        } catch {
            preconditionFailure("anon_rpc_http_provider_new: \(error)")
        }
        self.handle = handle
    }

    deinit {
        anon_rpc_http_provider_free(handle)
    }

    public func request(method: String, params: Data) async throws -> Data {
        let call = try RpcCall(method: method, params: Wire.parse(params, "RPC params")).wire()
        return try await run { operation in
            var error = AnonRpcBuffer()
            let status = withBytes(of: call) {
                anon_rpc_http_provider_request(handle, $0, $1, operation, &error)
            }
            try check(status, error)
        }
    }
}

/// Answer the worker's requests through `provider` until it no longer reads
/// through it, each as it arrives, so that a slow one holds up no other.
func serve(_ provider: any RpcProvider, handle: UInt64) {
    Task.detached {
        while let next = try? await run({ try check(anon_rpc_provider_next(handle, $0)) }) {
            guard let request = try? ProviderRequest(wire: next) else { return }
            Task.detached {
                // A late answer, after the worker closed, is dropped.
                var failure = AnonRpcBuffer()
                _ = withBytes(of: await answer(request, provider)) {
                    anon_rpc_provider_respond(handle, request.id, $0, $1, &failure)
                }
                _ = take(failure)
            }
        }
    }
}

/// `ProviderResponse` JSON answering `request` through `provider`.
private func answer(_ request: ProviderRequest, _ provider: any RpcProvider) async -> Data {
    guard let params = try? Wire.render(request.params) else {
        return try! ProviderResponse.error("invalid RPC params").wire()
    }
    if let wire = provider as? any WireRpcProvider {
        return await wire.respond(method: request.method, params: params)
    }
    let response: ProviderResponse
    do {
        let result = try await provider.request(method: request.method, params: params)
        response = .result(try Wire.parse(result, "RPC result"))
    } catch {
        response = .error((error as? AnonRpcError)?.message ?? "\(error)")
    }
    return try! response.wire()
}
