import AnonRpcC
import Foundation

/// Stops the process when the linked library is not the one these sources
/// were generated for, before any handle is made: every call would
/// otherwise cross a mismatched ABI.
func requireMatchingLibrary() {
    _ = libraryMatches
}

private let libraryMatches: Void = precondition(
    anon_rpc_abi_version() == UInt32(ANON_RPC_ABI_VERSION),
    "AnonRpcC.xcframework does not match the AnonRpc sources; rebuild it"
)

/// Takes the bytes of a buffer the library returned, and frees it.
func take(_ buffer: AnonRpcBuffer) -> Data {
    guard let pointer = buffer.ptr else { return Data() }
    let data = Data(bytes: pointer, count: buffer.len)
    anon_rpc_buffer_free(buffer)
    return data
}

/// Throws the failure a status reports, with the error JSON in `error`, and
/// frees `error`.
func check(_ status: AnonRpcStatus, _ error: AnonRpcBuffer = AnonRpcBuffer()) throws {
    let json = take(error)
    if status == ANON_RPC_STATUS_OK {
        return
    }
    if status == ANON_RPC_STATUS_INVALID_HANDLE {
        throw AnonRpcError(code: .internalError, message: "invalid anon-rpc handle")
    }
    if let failure = try? Failure(wire: json) {
        throw AnonRpcError(
            code: ErrorCode(rawValue: failure.code) ?? .internalError,
            message: failure.message,
            workerCode: failure.workerCode
        )
    }
    throw AnonRpcError(code: .fromStatus(status), message: "anon-rpc status \(status)")
}

/// Runs the blocking `call` on a thread of its own, never on the
/// cooperative thread pool, and runs `cancel` when the task is cancelled;
/// `cancel` must make `call` return.
func blocking<T: Sendable>(
    cancel: @escaping @Sendable () -> Void,
    _ call: @escaping @Sendable () throws -> T
) async throws -> T {
    try await withTaskCancellationHandler {
        try await withCheckedThrowingContinuation { continuation in
            Thread {
                continuation.resume(with: Result { try call() })
            }.start()
        }
    } onCancel: {
        cancel()
    }
}

/// Starts an operation with `start`, which stores its handle or throws,
/// then waits for its JSON result off the cooperative thread pool and frees
/// it. Task cancellation cancels it.
func run(_ start: (UnsafeMutablePointer<UInt64>) throws -> Void) async throws -> Data {
    var started: UInt64 = 0
    try start(&started)
    let operation = started
    defer { anon_rpc_operation_free(operation) }
    return try await blocking(cancel: { anon_rpc_operation_cancel(operation) }) {
        var json = AnonRpcBuffer()
        let status = anon_rpc_operation_wait(operation, &json)
        if status != ANON_RPC_STATUS_OK {
            try check(status, json)
        }
        return take(json)
    }
}

/// Calls `body` with the bytes of `data`, or a null pointer when it is empty.
func withBytes<T>(of data: Data, _ body: (UnsafePointer<UInt8>?, Int) -> T) -> T {
    data.withUnsafeBytes { bytes in
        body(bytes.bindMemory(to: UInt8.self).baseAddress, bytes.count)
    }
}
