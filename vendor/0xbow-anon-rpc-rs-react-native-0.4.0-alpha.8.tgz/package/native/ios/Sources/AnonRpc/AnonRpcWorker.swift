import AnonRpcC
import Foundation

/// An anon-rpc worker's `fetch` for Swift applications, backed by the Rust
/// `anon-rpc` crate: Tor-anonymized from `tor(config:)`, or served by a
/// sandboxed worker bundle from `init(address:...)` or `init(bundle:...)`.
///
/// Each Tor worker is its own isolation group: its requests never share a
/// Tor circuit or an HTTP connection with another worker's. Releasing the
/// worker closes it.
public final class AnonRpcWorker: Sendable {
    let handle: UInt64
    /// The RPC provider of a worker started from its specifier, or 0.
    let provider: UInt64
    /// The pool of a pool's group, which the group keeps open.
    let pool: WorkerPool?

    init(handle: UInt64, provider: UInt64 = 0, pool: WorkerPool? = nil) {
        self.handle = handle
        self.provider = provider
        self.pool = pool
    }

    deinit {
        anon_rpc_worker_free(handle)
        if provider != 0 {
            anon_rpc_provider_free(provider)
        }
    }

    /// Start a worker over a native Tor client and begin bootstrapping in the
    /// background. Returns at once; throws if the client cannot be made, as
    /// the Kotlin package does.
    public static func tor(config: TorConfig = .default) throws -> AnonRpcWorker {
        try tor(wire: Start.tor(config).wire().0.tor!)
    }

    /// `tor(config:)` from its wire document. Directories it leaves out are
    /// this device's.
    @_spi(AnonRpcWire) public static func tor(wire document: TorInit) throws -> AnonRpcWorker {
        requireMatchingLibrary()
        let json = try WorkerStart(tor: document).withDeviceDefaults().tor!.wire()
        var worker: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: json) { anon_rpc_worker_tor($0, $1, &worker, &error) }
        try check(status, error)
        return AnonRpcWorker(handle: worker)
    }

    /// Start a worker from its specifier contract and return at once, as the
    /// JavaScript `new AnonRpcWorker({ address, preExisting: { rpcProvider } })`
    /// does.
    ///
    /// The worker reads the contract's `workerHash()` and `workerResolvers()`
    /// through `rpcProvider`, fetches the bundle from the first resolver that
    /// serves bytes with that hash, and runs it in a sandbox; `ready` fails if
    /// none does. `config` reaches the worker as `anonRpcWorker.config`.
    /// Storage defaults to `Library/Application Support/anon-rpc/worker-storage`,
    /// which on iOS is excluded from backup.
    /// The worker's own `fetch` refuses loopback and private networks unless
    /// `allowPrivateNetworks` is set. When `specifierChainId` is set, the
    /// worker first asks `rpcProvider` for `eth_chainId`, and `ready` fails
    /// with `protocolError` on any chain but the one the specifier is
    /// published on. When `expectedWorkerHash` (`0x` and 64 hex digits) is
    /// set, `ready` fails with `protocolError`, before any bundle is fetched,
    /// when the specifier pins another hash. Throws `unsupported` for a
    /// malformed address, config or hash.
    public convenience init(
        address: String,
        config: AnonRpcValue? = nil,
        rpcProvider: any RpcProvider,
        specifierChainId: UInt64? = nil,
        expectedWorkerHash: String? = nil,
        storageDirectory: URL? = nil,
        allowPrivateNetworks: Bool = false
    ) throws {
        let start = Start.specifier(
            address: address, config: config, rpcProvider: rpcProvider,
            specifierChainId: specifierChainId, expectedWorkerHash: expectedWorkerHash,
            storageDirectory: storageDirectory, allowPrivateNetworks: allowPrivateNetworks)
        try self.init(wire: start.wire().0.specifier!, rpcProvider: rpcProvider)
    }

    /// `init(address:config:rpcProvider:specifierChainId:expectedWorkerHash:storageDirectory:allowPrivateNetworks:)`
    /// from its wire document. A storage directory it leaves out is this
    /// device's.
    @_spi(AnonRpcWire) public convenience init(wire document: SpecifierInit, rpcProvider: any RpcProvider) throws {
        requireMatchingLibrary()
        let json = try WorkerStart(specifier: document).withDeviceDefaults().specifier!.wire()
        var worker: UInt64 = 0
        var provider: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: json) {
            anon_rpc_worker_new($0, $1, &worker, &provider, &error)
        }
        try check(status, error)
        self.init(handle: worker, provider: provider)
        serve(rpcProvider, handle: provider)
    }

    /// Start a worker from `bundle`, whose keccak256 hash is its identity,
    /// and return at once. The options are those of
    /// `init(address:config:rpcProvider:specifierChainId:expectedWorkerHash:storageDirectory:allowPrivateNetworks:)`.
    public convenience init(
        bundle: Data,
        config: AnonRpcValue? = nil,
        storageDirectory: URL? = nil,
        allowPrivateNetworks: Bool = false
    ) throws {
        let start = Start.bundle(
            bundle, config: config, storageDirectory: storageDirectory,
            allowPrivateNetworks: allowPrivateNetworks)
        try self.init(wire: start.wire().0.bundle!, bundle: bundle)
    }

    /// `init(bundle:config:storageDirectory:allowPrivateNetworks:)` from its
    /// wire document. A storage directory it leaves out is this device's.
    @_spi(AnonRpcWire) public convenience init(wire settings: WorkerSettings, bundle: Data) throws {
        requireMatchingLibrary()
        let json = try WorkerStart(bundle: settings).withDeviceDefaults().bundle!.wire()
        var worker: UInt64 = 0
        var error = AnonRpcBuffer()
        let status = withBytes(of: bundle) { bundle, bundleLength in
            withBytes(of: json) { settings, settingsLength in
                anon_rpc_worker_from_bundle(
                    bundle, bundleLength, settings, settingsLength, &worker, &error)
            }
        }
        try check(status, error)
        self.init(handle: worker, provider: 0)
    }

    /// Wait until the worker is ready for traffic. After a failure every caller
    /// receives the same error.
    public func ready() async throws {
        _ = try await run { try check(anon_rpc_worker_ready(handle, $0)) }
    }

    /// Send `request` over Tor and return the whole response body.
    public func data(
        for request: AnonRpcRequest,
        redirect: Redirect = .follow
    ) async throws -> (Data, HTTPResponse) {
        let (body, response) = try await bytes(for: request, redirect: redirect)
        var data = Data()
        for try await chunk in body {
            data.append(chunk)
        }
        return (data, response)
    }

    /// Send the method, URL, headers and body of `request` over Tor and return
    /// the whole response body. See `AnonRpcRequest.init(_:)` for how its
    /// header fields are sent.
    public func data(
        for request: URLRequest,
        redirect: Redirect = .follow
    ) async throws -> (Data, HTTPResponse) {
        try await data(for: AnonRpcRequest(request), redirect: redirect)
    }

    /// Send the method, URL, headers and body of `request` over Tor and
    /// return once the response headers arrive, with a body that streams the
    /// rest. See `AnonRpcRequest.init(_:)` for how its header fields are sent.
    public func bytes(
        for request: URLRequest,
        redirect: Redirect = .follow
    ) async throws -> (Body, HTTPResponse) {
        try await bytes(for: AnonRpcRequest(request), redirect: redirect)
    }

    /// Send `request` over Tor and return once the response headers arrive,
    /// with a body that streams the rest.
    ///
    /// A streamed body is read once, as it is sent. Cancelling the task
    /// cancels the transfer, and so does releasing an unread body.
    public func bytes(
        for request: AnonRpcRequest,
        redirect: Redirect = .follow
    ) async throws -> (Body, HTTPResponse) {
        let head = try RequestHead(
            method: request.method, url: request.url.absoluteString, headers: request.headers,
            redirect: redirect,
            fields: request.fields.isEmpty
                ? nil : .map(request.fields.map { (key: $0.name, value: $0.value) })
        ).wire()
        nonisolated(unsafe) var stream: InputStream?
        var bytes = Data()
        let kind: Int32
        switch request.body {
        case nil:
            kind = ANON_RPC_BODY_NONE
        case .bytes(let data):
            kind = data.isEmpty ? ANON_RPC_BODY_NONE : ANON_RPC_BODY_BYTES
            bytes = data
        case .stream(let input):
            kind = ANON_RPC_BODY_STREAM
            stream = input
        }

        var writer: UInt64 = 0
        let json = try await run { operation in
            var error = AnonRpcBuffer()
            let status = withBytes(of: head) { head, headLength in
                withBytes(of: bytes) { body, bodyLength in
                    anon_rpc_worker_fetch(
                        handle, head, headLength, UInt32(kind), body, bodyLength,
                        operation, &writer, &error)
                }
            }
            try check(status, error)
            if let stream {
                upload(stream, to: writer)
            }
        }

        let decoded = try ResponseHead(wire: json)
        let body = Body(handle: decoded.body)
        guard
            let response = HTTPResponse(
                url: URL(string: decoded.url) ?? request.url,
                statusCode: Int(decoded.status),
                headerFieldList: decoded.headers
            )
        else {
            throw AnonRpcError(code: .protocolError, message: "invalid response head")
        }
        return (body, response)
    }

    /// A fetch whose request and response cross whole, as wire JSON:
    /// `request` is a `BufferedRequest`, and the result a `BufferedResponse`
    /// with its body in base64. For a host that cannot stream, such as the
    /// React Native module; the library validates and decodes the request.
    @_spi(AnonRpcWire) public func fetchBuffered(wire request: Data) async throws -> Data {
        try await run { operation in
            var error = AnonRpcBuffer()
            let status = withBytes(of: request) {
                anon_rpc_worker_fetch_buffered(handle, $0, $1, operation, &error)
            }
            try check(status, error)
        }
    }

    /// The next log entry, waiting for one if none is retained. Cancelling the
    /// task consumes no entry. After the worker fails or closes, retained
    /// entries are still delivered; then this throws.
    public func acceptLog() async throws -> LogEntry {
        let json = try await run { try check(anon_rpc_worker_accept_log(handle, $0)) }
        return try LogEntry(wire: json)
    }

    /// Close the worker: no new fetches are admitted, and in-flight fetches
    /// and unread response bodies fail with `closed`. Closing twice has no
    /// further effect.
    public func close() {
        anon_rpc_worker_close(handle)
    }
}

/// Copy `stream` into the request body `writer` on a thread of its own,
/// then free the writer. A stream error abandons the body, which fails the
/// fetch.
private func upload(_ stream: InputStream, to writer: UInt64) {
    nonisolated(unsafe) let stream = stream
    Thread {
        stream.open()
        defer {
            stream.close()
            anon_rpc_request_body_free(writer)
        }
        var buffer = [UInt8](repeating: 0, count: 64 * 1024)
        while true {
            let count = stream.read(&buffer, maxLength: buffer.count)
            if count < 0 {
                return
            }
            if count == 0 {
                anon_rpc_request_body_finish(writer)
                return
            }
            var error = AnonRpcBuffer()
            let status = anon_rpc_request_body_write(writer, buffer, count, &error)
            anon_rpc_buffer_free(error)
            if status != ANON_RPC_STATUS_OK {
                return
            }
        }
    }.start()
}

extension AnonRpcWorker {
    /// The response head of a fetch. Its `allHeaderFields` combines repeated
    /// fields into one value separated by commas, as Foundation does;
    /// `headerFieldList` keeps each field as the server sent it, in order.
    public final class HTTPResponse: HTTPURLResponse, @unchecked Sendable {
        /// The header fields in the order the server sent them, with repeated
        /// fields kept apart.
        public let headerFieldList: [(name: String, value: String)]

        init?(url: URL, statusCode: Int, headerFieldList: [(name: String, value: String)]) {
            self.headerFieldList = headerFieldList
            var fields: [String: String] = [:]
            for (name, value) in headerFieldList {
                fields[name] = fields[name].map { "\($0), \(value)" } ?? value
            }
            super.init(url: url, statusCode: statusCode, httpVersion: "HTTP/1.1", headerFields: fields)
        }

        /// A coded response carries no field list, so it does not decode.
        required init?(coder: NSCoder) {
            nil
        }
    }
}

#if os(iOS)
/// The data root on this device: `Library/Application Support`, whose
/// `anon-rpc` directory, where the library keeps Tor guards and worker
/// storage, this excludes from iCloud and device backups, as the Kotlin SDK's
/// no-backup directory keeps them on Android. `nil`, so the library's default
/// applies, if the directory cannot be made.
func deviceDataRoot() -> String? {
    let manager = FileManager.default
    guard
        let support = try? manager.url(
            for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true
        )
    else { return nil }
    var own = support.appendingPathComponent("anon-rpc", isDirectory: true)
    guard (try? manager.createDirectory(at: own, withIntermediateDirectories: true)) != nil else { return nil }
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try? own.setResourceValues(values)
    return support.path
}
#else
/// `nil`: the library's default directory applies.
func deviceDataRoot() -> String? { nil }
#endif
