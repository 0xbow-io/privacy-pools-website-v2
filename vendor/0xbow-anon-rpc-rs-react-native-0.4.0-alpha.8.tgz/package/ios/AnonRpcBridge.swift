@_spi(AnonRpcWire) import AnonRpc
import Foundation

/// The React Native module's calls, over the AnonRpc Swift SDK and its wire
/// codec. Workers and calls are numbered by JavaScript; bytes cross as base64.
@objc(AnonRpcBridge)
public final class AnonRpcBridge: NSObject, @unchecked Sendable {
    public typealias Resolve = (Any?) -> Void
    /// Rejects with a code: the error's code, or the worker's own code.
    public typealias Reject = (String, String) -> Void

    /// Emits a provider request to JavaScript.
    @objc public var emitProviderRequest: ((NSDictionary) -> Void)?

    private let lock = NSLock()
    private var workers: [Int: AnonRpcWorker] = [:]
    /// Workers JavaScript has closed, kept until their retained log entries
    /// have been read.
    private var closedWorkers: Set<Int> = []
    private var pools: [Int: WorkerPool] = [:]
    private var calls: [Int: Task<Void, Never>] = [:]
    /// Provider requests awaiting JavaScript's `ProviderResponse` JSON, with
    /// the worker each belongs to.
    private var providerRequests: [Int: (workerId: Int, continuation: CheckedContinuation<Data, Never>)] = [:]
    private var nextRequest = 1

    private func locked<T>(_ body: () -> T) -> T {
        lock.lock()
        defer { lock.unlock() }
        return body()
    }

    private func worker(_ id: Int) throws -> AnonRpcWorker {
        guard let worker = locked({ workers[id] }) else {
            throw AnonRpcError(code: .closed, message: "no such worker")
        }
        return worker
    }

    private static func fail(_ error: any Error, _ reject: Reject) {
        if let error = error as? AnonRpcError {
            reject(error.workerCode ?? error.code.rawValue, error.message)
        } else if error is CancellationError {
            reject(ErrorCode.cancelled.rawValue, "operation cancelled")
        } else {
            reject(ErrorCode.internalError.rawValue, "\(error)")
        }
    }

    /// `error` as `Failure` JSON, which a synchronous call returns.
    private static func failure(_ error: any Error) -> String {
        let failure = if let error = error as? AnonRpcError {
            Failure(code: error.code.rawValue, message: error.message, workerCode: error.workerCode)
        } else {
            Failure(code: ErrorCode.internalError.rawValue, message: "\(error)")
        }
        return String(decoding: (try? failure.wire()) ?? Data(), as: UTF8.self)
    }

    /// Register the worker `make` returns as `id`: `nil`, or its failure.
    private func create(_ id: Int, _ make: () throws -> AnonRpcWorker) -> String? {
        do {
            let worker = try make()
            locked { workers[id] = worker }
            return nil
        } catch {
            return Self.failure(error)
        }
    }

    /// Run `body` as the call numbered `callId`, which `cancel` cancels.
    private func call(_ callId: Int, _ resolve: @escaping Resolve, _ reject: @escaping Reject,
                      _ body: @escaping @Sendable () async throws -> Any?) {
        let task = Task {
            do {
                let result = try await body()
                resolve(result)
            } catch {
                Self.fail(error, reject)
            }
            _ = self.locked { self.calls.removeValue(forKey: callId) }
        }
        locked { calls[callId] = task }
    }

    @objc public func createTor(_ id: Int, initJson: String) -> String? {
        create(id) { try .tor(wire: TorInit(wire: Data(initJson.utf8))) }
    }

    @objc public func createFromAddress(_ id: Int, initJson: String) -> String? {
        create(id) {
            try AnonRpcWorker(
                wire: SpecifierInit(wire: Data(initJson.utf8)),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
        }
    }

    @objc public func createFromBundle(_ id: Int, bundleBase64: String, settingsJson: String) -> String? {
        create(id) {
            try AnonRpcWorker(
                wire: WorkerSettings(wire: Data(settingsJson.utf8)), bundle: try Self.bundle(bundleBase64))
        }
    }

    @objc public func createReplacing(_ id: Int, initJson: String, bundleBase64: String?) -> String? {
        create(id) {
            try AnonRpcWorker.replacing(
                wire: ReplacingInit(wire: Data(initJson.utf8)), bundle: try Self.bundle(bundleBase64),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
        }
    }

    @objc public func createPool(_ id: Int, initJson: String, bundleBase64: String?) -> String? {
        do {
            let pool = try WorkerPool(
                wire: PoolInit(wire: Data(initJson.utf8)), bundle: try Self.bundle(bundleBase64),
                rpcProvider: JavaScriptProvider(bridge: self, workerId: id))
            locked { pools[id] = pool }
            return nil
        } catch {
            return Self.failure(error)
        }
    }

    @objc public func poolGroup(_ poolId: Int, workerId: Int, groupJson: String) -> String? {
        create(workerId) {
            guard let pool = locked({ pools[poolId] }) else {
                throw AnonRpcError(code: .closed, message: "no such pool")
            }
            return try pool.group(wire: PoolGroup(wire: Data(groupJson.utf8)))
        }
    }

    @objc public func closePool(_ id: Int) -> String? {
        locked { pools.removeValue(forKey: id) }?.close()
        answerProviderRequests(of: id)
        return nil
    }

    @objc public func ready(_ id: Int, resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            call(-id, resolve, reject) {
                try await worker.ready()
                return nil
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    /// The library decodes and validates `requestJson`, a `BufferedRequest`,
    /// and resolves with a `BufferedResponse`.
    @objc public func fetch(_ id: Int, callId: Int, requestJson: String,
                            resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            call(callId, resolve, reject) {
                String(decoding: try await worker.fetchBuffered(wire: Data(requestJson.utf8)), as: UTF8.self)
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    @objc public func acceptLog(_ id: Int, callId: Int, resolve: @escaping Resolve, reject: @escaping Reject) {
        do {
            let worker = try worker(id)
            call(callId, resolve, reject) {
                do {
                    return String(decoding: try await worker.acceptLog().wire(), as: UTF8.self)
                } catch let error as AnonRpcError where error.code == .closed {
                    // A closed worker's log is drained: forget the worker.
                    self.locked {
                        if self.closedWorkers.remove(id) != nil { self.workers.removeValue(forKey: id) }
                    }
                    throw error
                }
            }
        } catch {
            Self.fail(error, reject)
        }
    }

    @objc public func cancel(_ callId: Int) {
        locked { calls[callId] }?.cancel()
    }

    @objc public func close(_ id: Int) -> String? {
        locked { () -> AnonRpcWorker? in
            guard let worker = workers[id] else { return nil }
            closedWorkers.insert(id)
            return worker
        }?.close()
        answerProviderRequests(of: id)
        return nil
    }

    /// Close every worker and pool, as when JavaScript reloads.
    @objc public func invalidate() {
        let (closing, closingPools) = locked {
            defer {
                workers.removeAll()
                closedWorkers.removeAll()
                pools.removeAll()
            }
            return (Array(workers.values), Array(pools.values))
        }
        locked { Array(calls.values) }.forEach { $0.cancel() }
        closing.forEach { $0.close() }
        closingPools.forEach { $0.close() }
        answerProviderRequests()
    }

    /// The answer to a provider request whose worker has closed; the library
    /// has stopped waiting for it.
    private static let closedResponse = providerError("worker closed")

    /// End the provider requests of the worker or pool `id`, or of every one,
    /// whose relay would otherwise wait for JavaScript forever.
    private func answerProviderRequests(of id: Int? = nil) {
        let pending = locked {
            let pending = providerRequests.filter { id == nil || $0.value.workerId == id }
            pending.keys.forEach { providerRequests.removeValue(forKey: $0) }
            return pending.values.map(\.continuation)
        }
        pending.forEach { $0.resume(returning: Self.closedResponse) }
    }

    /// Ask JavaScript, and wait for its `ProviderResponse` JSON.
    fileprivate func request(workerId: Int, method: String, params: Data) async -> Data {
        await withCheckedContinuation { continuation in
            let requestId = locked {
                defer { nextRequest += 1 }
                providerRequests[nextRequest] = (workerId, continuation)
                return nextRequest
            }
            guard let emit = emitProviderRequest else {
                _ = locked { providerRequests.removeValue(forKey: requestId) }
                continuation.resume(returning: providerError("no provider listener"))
                return
            }
            emit([
                "workerId": workerId, "requestId": requestId, "method": method,
                "params": String(decoding: params, as: UTF8.self),
            ])
        }
    }

    /// Pass JavaScript's `ProviderResponse` JSON to the library, which
    /// validates it.
    @objc public func respondProvider(_ workerId: Int, requestId: Int, responseJson: String) {
        locked({ providerRequests.removeValue(forKey: requestId)?.continuation })?
            .resume(returning: Data(responseJson.utf8))
    }

    /// Bundle bytes from base64; empty for none.
    private static func bundle(_ base64: String?) throws -> Data {
        guard let base64 else { return Data() }
        guard let bundle = Data(base64Encoded: base64) else {
            throw AnonRpcError(code: .unsupported, message: "the bundle is not base64")
        }
        return bundle
    }
}

/// Reads the specifier through the JavaScript provider of the worker,
/// relaying JavaScript's answer as it is.
private struct JavaScriptProvider: WireRpcProvider, @unchecked Sendable {
    weak var bridge: AnonRpcBridge?
    let workerId: Int

    func respond(method: String, params: Data) async -> Data {
        guard let bridge else { return providerError("the module is gone") }
        return await bridge.request(workerId: workerId, method: method, params: params)
    }
}

/// `ProviderResponse` JSON failing a provider request with `message`.
private func providerError(_ message: String) -> Data {
    try! ProviderResponse.error(message).wire()
}
