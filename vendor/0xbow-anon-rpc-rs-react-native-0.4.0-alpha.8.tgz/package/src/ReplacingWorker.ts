// ReplacingWorker and WorkerPool over the Swift and Kotlin SDKs, whose
// anon-rpc crate runs the replacement rule and the budget (SPEC §5.1, §5.2).

import native from "./NativeAnonRpc";
import {
  create,
  created,
  fetchThrough,
  forgetProvider,
  nativeStart,
  nextNativeId,
  rpcError,
} from "./AnonRpcWorker";
import type { AnonFetch } from "./plain-values";
import {
  poolInit,
  replacingInit,
  type ReplacingWorkerOptions,
  type WorkerGroup,
  type WorkerPoolOptions,
} from "./start";
import { encodePoolGroup, encodePoolInit, encodeReplacingInit } from "./wire.g";

/** Wait for native worker `id` to be ready. */
async function ready(id: number): Promise<void> {
  await native.ready(id).catch((error) => {
    throw rpcError(error);
  });
}

/** A `fetch` over a worker it starts on first use and replaces when the worker's route stops carrying calls. */
export class ReplacingWorker {
  /** A standard `fetch`, bound so that it works as a free function. */
  readonly fetch: AnonFetch;

  #id = nextNativeId();

  constructor(options: ReplacingWorkerOptions) {
    const [start, bundle, provider] = nativeStart(options.start);
    const init = JSON.stringify(encodeReplacingInit(replacingInit(start, options)));
    create(this.#id, provider, (id) => native.createReplacing(id, init, bundle));
    this.fetch = (input, init) => fetchThrough(this.#id, input, init);
  }

  /** Start a worker if none is in use, without a call, and settle when it is ready. */
  ready(): Promise<void> {
    return ready(this.#id);
  }

  /** Close the worker in use; pending and later calls fail with code `closed`. */
  close(): void {
    forgetProvider(this.#id);
    native.close(this.#id);
  }
}

/**
 * Workers for isolation groups under one budget. Each group is a replacing
 * worker of its own, and the pool counts every worker alive, spares
 * included, against `maxWorkers`. Which traffic shares a group is the host's
 * policy.
 */
export class WorkerPool {
  #id = nextNativeId();
  #groups = new Map<string, WorkerGroup>();

  constructor(options: WorkerPoolOptions) {
    const [start, bundle, provider] = nativeStart(options.start);
    const init = JSON.stringify(encodePoolInit(poolInit(start, options)));
    create(this.#id, provider, (id) => native.createPool(id, init, bundle));
  }

  /**
   * The group named `key`, made on first use; the same object until it is
   * closed. `idleCloseMs` replaces the pool's for a group this call makes.
   */
  group(key: string, options: { idleCloseMs?: number } = {}): WorkerGroup {
    const existing = this.#groups.get(key);
    if (existing) return existing;
    const id = nextNativeId();
    const request = JSON.stringify(encodePoolGroup({ key, idle_close_ms: options.idleCloseMs }));
    created(native.poolGroup(this.#id, id, request));
    const groups = this.#groups;
    const group: WorkerGroup = {
      fetch: (input, init) => fetchThrough(id, input, init),
      ready: () => ready(id),
      close: () => {
        native.close(id);
        if (groups.get(key) === group) groups.delete(key);
      },
    };
    groups.set(key, group);
    return group;
  }

  /** Close every group and spare; waiting and later calls fail with code `closed`. */
  close(): void {
    this.#groups.clear();
    forgetProvider(this.#id);
    native.closePool(this.#id);
  }
}
